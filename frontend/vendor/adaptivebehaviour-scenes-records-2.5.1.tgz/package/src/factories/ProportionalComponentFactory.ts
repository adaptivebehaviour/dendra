import { createElement, type ReactElement } from 'react';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { ContainerComponentFactory } from '@adaptivebehaviour/manifesto/src/manifesto/factories/ContainerComponentFactory';
import { ProportionalComponent } from '../components/Proportional';

/**
 * Factory `'proportional-component'` — resolves each element of a passed
 * `items` array into its own component, wrapped in a `ProportionalComponent`
 * flex container (see `components/Proportional.tsx`) rather than a plain
 * `<div>`. Registered in `instanceRegistry` (see `index.ts`), replacing the
 * generic {@link Factory} default `'proportional-component'` previously used
 * — which resolved nothing, since only a custom `instanceRegistry` entry's
 * `produce()` (inherited here from {@link ContainerComponentFactory}) walks
 * `items` into complete child records.
 *
 * Extends {@link ContainerComponentFactory} for the same reason
 * `SceneProviderFactory` does, not the same reason `SceneFactory`/`StageFactory`
 * do: `ProportionalComponent` takes `{ record, children }` — it doesn't read
 * `record.items` itself the way `Scene`/`Stage` do — so `renderComponent()`
 * below calls `renderItemComponents()` eagerly and hands the result to
 * `ProportionalComponent` as `children`, exactly like
 * `SceneProviderFactory.renderComponent()`. Each rendered child is still a
 * `<ProportionalXyz record={...} />` element (see `proportionalImageComponent`/
 * `proportionalTextComponent` in `index.ts`), which is what lets
 * `ProportionalComponent`'s own `getChildRecord()` (`Proportional.tsx`) read
 * an aspect ratio/size weight back off each one.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('proportional-component', {
 *   props: { direction: 'row' },
 *   items: ['proportional-image:crm:apple-whole', 'proportional-image:crm:user'],
 * });
 * ```
 */
export class ProportionalComponentFactory extends ContainerComponentFactory {
  renderComponent(items: RootRecord[]): ReactElement {
    return createElement(ProportionalComponent, {
      record: this.record(),
      children: this.renderItemComponents(items),
    });
  }
}
