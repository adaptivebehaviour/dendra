import { Root, type RootRecord, type RootConfig } from '@adaptivebehaviour/manifesto/src/Root';
import type { FactoryCapability, ProduceOptions } from '@adaptivebehaviour/manifesto/src/Factory';
import { Factory } from '@adaptivebehaviour/manifesto/src/Factory';
import { resolveFactoryRecord, recordRegistry } from '@adaptivebehaviour/manifesto/src/create';
import { resolveOnlyItem } from '@adaptivebehaviour/manifesto/src/ItemFactory';

/**
 * Factory `'proportional-image'` — resolves an optional single `items[0]`
 * element (e.g. a nested `'crm:...'` fetch) into this image's own `props`,
 * on top of the ordinary two-phase resolution (this factory's own declared
 * `records.json` defaults merged with a real `kind` ancestor's props) the
 * generic {@link Factory} default previously provided on its own.
 * Registered in `instanceRegistry` (see `index.ts`), replacing that generic
 * default.
 *
 * A direct port of `manifesto/factories/ImageFactory.ts`'s own approach to this
 * collection — `'proportional-image'`'s `props.url`/`props.alt` shape (see
 * `components/Proportional.tsx`'s `ProportionalImage`) is identical to
 * `'image'`'s, so the same composition (a plain {@link Factory} instance
 * built from this factory's own resolved identity, via
 * {@link resolveFactoryRecord}) and the same reasons apply: `produce()`
 * can't literally extend {@link ItemFactory} (its return type must stay
 * conditionally sync/async — synchronous when no `items` are given, to
 * preserve the overwhelmingly common no-fetch call shape; a `Promise` only
 * when an item is actually present to resolve), and `this.record()` alone
 * wouldn't correctly carry this factory's own defaults once `options.kind`
 * is given explicitly. See `manifesto/factories/ImageFactory.ts`'s own doc comment for
 * the full rationale — this class differs from it only in which factory key
 * it resolves its own identity against.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * collection.create('proportional-image', { props: { url: 'avatar.jpg' } }); // unchanged, still synchronous
 * await collection.createAsync('proportional-image', { items: ['crm:apple-whole'] }); // resolves items[0] into props
 * ```
 */
export class ProportionalImageFactory extends Root implements FactoryCapability {
  produce(
    options: ProduceOptions = {},
    cache?: Map<string, RootRecord>,
    records: Map<string, RootConfig> = recordRegistry
  ): RootRecord | Promise<RootRecord> {
    const rawItems = (options.items ?? []) as unknown[];
    const factoryRecord = resolveFactoryRecord(this.factory, records, cache);
    const factoryInstance = new Factory(factoryRecord);

    if (rawItems.length === 0) {
      return factoryInstance.produce(options, cache, records);
    }

    return resolveOnlyItem(rawItems, this.factory, cache).then((resolvedItem) => ({
      ...factoryInstance.produce(
        { ...options, props: { ...resolvedItem?.props, ...options.props } },
        cache,
        records
      ),
      items: [],
    }));
  }
}
