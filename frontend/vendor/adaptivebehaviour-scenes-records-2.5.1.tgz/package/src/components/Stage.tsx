'use client';

import { useEffect, useState, type ReactNode } from 'react';
import type { RecordPropsComponent } from '@adaptivebehaviour/manifesto/src/create';
import { componentRegistry } from '@adaptivebehaviour/manifesto/src/create';
import { getCollection } from '@adaptivebehaviour/manifesto/src/getCollection';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { useIsPortrait } from '@adaptivebehaviour/scenes/src/orientation';
import { StageFactory } from '../factories/StageFactory';

// Re-exported so existing imports of `useIsPortrait` from Stage keep working.
export { useIsPortrait };

const UI_SHORT_MIN = 320;
const UI_LONG_MIN = 640;

function readMinProp(props: Record<string, unknown>, key: string, fallback: number): number {
  const value = props[key];
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function getUiMinimums(isPortrait: boolean, shortMin: number, longMin: number) {
  if (isPortrait) {
    return {
      minWidth: shortMin,
      minHeight: longMin,
    };
  }

  return {
    minWidth: longMin,
    minHeight: shortMin,
  };
}

function useViewportLayout(minWidth: number, minHeight: number) {
  const [layout, setLayout] = useState({
    scale: 1,
    contentWidth: minWidth,
    contentHeight: minHeight,
  });

  useEffect(() => {
    // `window.visualViewport` (where supported) reports the actual visible layout
    // area — excluding an on-screen keyboard, and tracking pinch-zoomed/panned state
    // correctly — which `window.innerWidth`/`innerHeight` doesn't always do on mobile
    // Safari/Chrome. Its own `resize`/`scroll` events are listened to *in addition to*
    // `window`'s `resize` event, not instead of it: relying on `visualViewport`'s
    // events alone measures wrong — a live browser-window drag-resize can leave
    // `contentWidth`/`contentHeight` frozen at whatever they were on page load. `update()`
    // still reads its own dimensions from `visualViewport` when available; only what
    // triggers a recompute changes.
    const visualViewport = window.visualViewport;
    const update = () => {
      const viewportWidth = visualViewport ? visualViewport.width : window.innerWidth;
      const viewportHeight = visualViewport ? visualViewport.height : window.innerHeight;
      const scale = Math.min(viewportWidth / minWidth, viewportHeight / minHeight, 1);

      setLayout({
        scale,
        contentWidth: scale < 1 ? minWidth : viewportWidth,
        contentHeight: scale < 1 ? minHeight : viewportHeight,
      });
    };
    update();
    window.addEventListener('resize', update);
    visualViewport?.addEventListener('resize', update);
    visualViewport?.addEventListener('scroll', update);
    return () => {
      window.removeEventListener('resize', update);
      visualViewport?.removeEventListener('resize', update);
      visualViewport?.removeEventListener('scroll', update);
    };
  }, [minWidth, minHeight]);

  return layout;
}

/**
 * Backs factory `'stage'` — a responsive viewport frame that scales its
 * content to fit within a minimum UI size, flipping the minimum dimensions
 * with device orientation. Its purpose is to provide a single-page
 * application container: the one fixed-size viewport an app's scenes render
 * inside, rather than a document that scrolls with page content. Registered
 * indirectly (see `../index.ts`): this
 * component uses hooks and browser APIs, so the registered
 * `RecordComponent` must build a `createElement(Stage, record)` element
 * rather than calling this function directly — a direct call would execute
 * client-only code (and, from a Server Component, throw an RSC
 * cross-boundary error) at registration/dispatch time instead of deferring
 * it to React's own render.
 *
 * Same shape as `ContainerComponent`/`ItemComponent` (manifesto's own
 * generic wrappers) — a plain `RecordComponent` reading `record.items`
 * itself, rather than taking `children` as a separate prop the way it
 * previously did. Rendering those already-resolved items is delegated to
 * {@link StageFactory.renderItemComponents} (inherited from
 * `ContainerComponentFactory` — a plain, stateless instance method,
 * constructing a fresh `StageFactory` here just to call it costs nothing),
 * the same pattern `ContainerComponent` uses for `ContainerComponentFactory`.
 * `StageFactory.renderComponent(items)` is the paired, factory-side way to
 * reach this component — see its own doc comment for why that pairing can't
 * double-render or loop.
 *
 * Takes an optional `children` as a property on its one argument, alongside
 * `record`'s own fields — not a second, separate function parameter (see
 * `ContainerComponent.tsx`'s own doc comment for the full rationale). This
 * is what makes it actually reachable here despite the hooks above: a
 * second *positional parameter* could only ever be supplied by a direct
 * call bypassing React — which would execute those hooks outside of
 * React's own render and throw, per this doc comment's opening paragraph —
 * but `children` as a property on the single argument is populated by
 * React itself, before this function is ever called. `createElement(Stage,
 * record, someNode)` — or JSX like `<Stage {...record}>{someNode}
 * </Stage>` — has React automatically merge `someNode` into
 * `record.children`, then invoke `Stage` the ordinary, safe way, with that
 * one merged object. `componentRegistry` dispatch never has a `children` to
 * attach, so it stays `undefined` there — unchanged, items-only behavior.
 * Renders *after* the items rendered from `record.items`.
 *
 * If `componentRegistry` is completely empty when this runs, calls
 * `getCollection()` first to populate it (manifesto + scenes, merged).
 * Next.js (and similar bundlers) compile a `'use client'` component, and
 * everything it imports, into a separate module graph from the Server
 * Component that renders it — a page's own `getCollection()` call
 * populates *that* graph's copy of `create.ts`'s module-level registries,
 * but has no effect on this file's separate client-bundle copy, so without
 * this, `StageFactory.renderItemComponents()`'s `buildComponent()` call
 * below would find nothing registered the first time this actually runs on
 * the client side — the exact same class of bug
 * `nextjs/src/app/lib/crm/bootstrap.ts`'s own comment documents for `'crm'`
 * vs. `instrumentation.ts`/`layout.tsx`, recurring here across the
 * server/client-component boundary instead. Guarded on `size === 0` so
 * this never fires in this library's own tests (every existing test's
 * `beforeEach` registers at least one factory before rendering anything) —
 * only a genuinely unpopulated client bundle hits it. Deliberately placed
 * here rather than inside `ContainerComponentFactory.renderItemComponents()`
 * itself: that file sits underneath `StageFactory`/`SceneFactory` in the
 * `extends` chain (`StageFactory extends ContainerComponentFactory`), so
 * `ContainerComponentFactory.ts` importing `getCollection.ts` — which
 * transitively imports `scenes/index.ts` → `StageFactory.ts` → back to
 * `ContainerComponentFactory.ts` — deadlocks the module graph: `extends`
 * is evaluated immediately, not deferred, so `StageFactory` would try to
 * extend a not-yet-defined class. This file has no such eager dependency
 * on anything importing it back, so the same import here is safe.
 */
export const Stage: RecordPropsComponent = (record: RootRecord & { children?: ReactNode }) => {
  if (componentRegistry.size === 0) {
    getCollection();
  }
  const isPortrait = useIsPortrait();
  const shortMin = readMinProp(record.props, 'shortMin', UI_SHORT_MIN);
  const longMin = readMinProp(record.props, 'longMin', UI_LONG_MIN);
  const { minWidth, minHeight } = getUiMinimums(isPortrait, shortMin, longMin);
  const { scale, contentWidth, contentHeight } = useViewportLayout(minWidth, minHeight);

  // `select-none` on the stage's own root — a scenes-driven UI is built entirely from
  // pointer-driven components, not click-drag text/image selection, and stray
  // selection only ever fires by accident during ordinary interaction. Inherited by
  // every descendant, so anything that legitimately needs selectable content (e.g. a
  // portalled overlay rendered outside this subtree) sets its own override instead.
  return (
    <div data-id={record.id} data-factory="stage" className="stage select-none">
      <div
        className="stage__viewport"
        style={{
          width: `${contentWidth * scale}px`,
          height: `${contentHeight * scale}px`,
        }}
      >
        <div
          className="stage__content"
          style={{
            width: `${contentWidth}px`,
            height: `${contentHeight}px`,
            ...(scale < 1 ? { transform: `scale(${scale})` } : {}),
          }}
        >
          {new StageFactory(record).renderItemComponents(record.items as RootRecord[])}
          {record.children}
        </div>
      </div>
    </div>
  );
};
