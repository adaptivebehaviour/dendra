'use client';

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import type { RecordPropsComponent } from '@adaptivebehaviour/manifesto/src/create';
import { componentRegistry } from '@adaptivebehaviour/manifesto/src/create';
import { getCollection } from '@adaptivebehaviour/manifesto/src/getCollection';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { toCss } from '@adaptivebehaviour/manifesto/src/manifesto/schemas';
import { sceneProps } from '../schemas';
import { useScene, useSceneEvent } from '@adaptivebehaviour/scenes/src/hooks';
import { SceneFactory } from '../factories/SceneFactory';

/**
 * Broadcast on a `SceneProvider`'s event bus (via `useEmit`, see `../hooks`)
 * to activate exactly one `Scene` by id — the payload is the target
 * `record.id`. Every `Scene` mounted under the same provider scope listens
 * for this event and independently compares the payload against its own
 * `id`; the one that matches becomes visible, every other one hides. This
 * is what makes a "tabs"/"screens" navigation pattern declarative: nothing
 * needs to track which scene is currently active except the event itself —
 * each `Scene` decides its own visibility locally.
 */
export const SCENE_ACTIVATE_EVENT = 'scene:activate';

/**
 * Backs factory `'scene'` — registers a named scene state slot (the
 * record's `id` is the scene name, `record.props` its seed initial state)
 * via `useScene`, so any descendant of the *same* `SceneProvider` scope (or
 * a nested one) can reactively read or patch that state by name with
 * `useSceneState`/`useScene` (see `../hooks`), independent of this
 * component's own position within that scope. Styled via `record.props.styling`
 * when present, the same generic escape hatch `ContainerComponent`/`ItemComponent`
 * use — applied on top of the default `h-full w-full` sizing, not in place of it.
 * Reaching a *different* `SceneProvider` scope — a sibling or cousin, not a descendant — requires
 * that scope to explicitly `expose` the name; see `SceneProvider`'s own doc
 * comment in `../hooks` for the full visibility model. Registered indirectly (see
 * `../index.ts`): like `Stage`, this is a hook-based Client Component, so the
 * registered `RecordComponent` must build a `createElement(Scene, record)`
 * element rather than calling this function directly — a direct call would
 * execute client-only code (and, from a Server Component, throw an RSC
 * cross-boundary error) at registration/dispatch time instead of deferring
 * it to React's own render.
 *
 * Same shape as `ContainerComponent`/`ItemComponent` (manifesto's own
 * generic wrappers), and as `Stage` — a plain `RecordComponent` reading
 * `record.items` itself, rather than taking `children` as a separate prop
 * the way it previously did. Rendering those already-resolved items is
 * delegated to {@link SceneFactory.renderItemComponents} (inherited from
 * `ContainerComponentFactory`), the same pattern `Stage`/`ContainerComponent`
 * use for their own paired factories. `SceneFactory.renderComponent(items)`
 * is the paired, factory-side way to reach this component — see its own doc
 * comment for why that pairing can't double-render or loop.
 *
 * Takes an optional `children` as a property on its one argument, alongside
 * `record`'s own fields — not a second, separate function parameter (see
 * `ContainerComponent.tsx`'s own doc comment for the full rationale, and
 * `Stage.tsx`'s for why this is what makes it reachable despite the hooks
 * above). `createElement(Scene, record, someNode)` — or JSX like `<Scene
 * {...record}>{someNode}</Scene>` — has React automatically merge
 * `someNode` into `record.children`, then invoke `Scene` the ordinary, safe
 * way, with that one merged object. `componentRegistry` dispatch never has
 * a `children` to attach, so it stays `undefined` there — unchanged,
 * items-only behavior. Renders *after* the items rendered from
 * `record.items`.
 *
 * If `componentRegistry` is completely empty when this runs, calls
 * `getCollection()` first to populate it — see `Stage.tsx`'s own doc
 * comment for the full reasoning (the `'use client'` cross-bundle
 * registration gap this guards against, why the guard is scoped to
 * `size === 0` so it never fires in this library's own tests, and why this
 * file — unlike `ContainerComponentFactory.ts` — has no eager `extends`
 * dependency that would make the same import unsafe).
 *
 * Visible by default (`record.props.initiallyVisible !== false` — explicit
 * `false` is the only way to start hidden; unset/anything else stays
 * visible), and stays visible unless a {@link SCENE_ACTIVATE_EVENT}
 * broadcast names a *different* scene's id, at which point it hides via
 * `display: 'none'` — never unmounted, so its own `useScene` registration
 * (and any state held by its own item components) survives while hidden,
 * ready to show again the moment it's reactivated. `record.props.styling`
 * is still applied underneath the visibility toggle, exactly as before this
 * behaviour existed.
 *
 * Also publishes its own live active/inactive state back into its `useScene`
 * slot (`{ isActive }`, merged onto `record.props`), optionally fades in via
 * `record.props.fadeInMs`, and can paint `record.props.backgroundImage` as a
 * CSS background — see each block below for the reasoning.
 */
interface SceneBackgroundImage {
  url?: string;
}

export const Scene: RecordPropsComponent = (record: RootRecord & { children?: ReactNode }) => {
  if (componentRegistry.size === 0) {
    getCollection();
  }
  const [, setSceneState] = useScene(record.id, record.props);
  const [isActive, setIsActive] = useState(record.props.initiallyVisible !== false);
  useSceneEvent<string>(SCENE_ACTIVATE_EVENT, (activeId) => {
    setIsActive(activeId === record.id);
  });

  // `props.fadeInMs` fades this scene in over that many milliseconds the moment it
  // *becomes* active via `SCENE_ACTIVATE_EVENT` — left unset keeps the original
  // instant `display` swap below with no animation at all. Deliberately fade-*in*
  // only, never fade-out: the scene being left still disappears immediately (the
  // plain `display: none` branch below applies regardless of `fadeInMs`), so only
  // the incoming scene ever animates. `visible` starts equal to `isActive` so the
  // very first scene(s) shown on mount (`initiallyVisible` unset/`true`) never
  // fade — the effect below only ever *restarts* the fade on a later activation,
  // not on mount.
  const ownProps = propsOf(sceneProps, record);
  const fadeInMs = ownProps.fadeInMs;
  const [visible, setVisible] = useState(isActive);
  const mountedRef = useRef(false);
  useEffect(() => {
    if (!mountedRef.current) {
      mountedRef.current = true;
      return;
    }
    if (!fadeInMs || !isActive) {
      setVisible(isActive);
      return;
    }
    // Paint one frame at `opacity: 0` first — setting `visible` straight to `true`
    // here would change `opacity: 0` to `opacity: 1` within the same render, which
    // the browser applies immediately rather than transitioning (a CSS `transition`
    // only animates a style change *between* two painted frames).
    setVisible(false);
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, [isActive, fadeInMs]);

  // Publishes this scene's own live active/inactive state into the same scene-state
  // slot `record.props` (above) already occupies — lets something elsewhere key its
  // own behaviour off whether a specific *named* scene is the one currently showing,
  // without this component needing to know who, if anyone, is watching.
  useEffect(() => {
    setSceneState({ isActive });
  }, [isActive, setSceneState]);

  // `props.backgroundImage` paints as a CSS `background-image` on this scene's own
  // root div, `cover`/`center`/`no-repeat` — merged over `props.styling` rather than
  // replacing it, so a scene's own layout styling and its background image are set
  // independently instead of one clobbering the other. Not applied at all if the
  // asset failed to resolve (no `url`), rather than pointing `background-image` at
  // `url(undefined)`.
  const backgroundImage = ownProps.backgroundImage;
  const styling: CSSProperties | undefined = backgroundImage?.url
    ? {
        ...toCss(ownProps.styling),
        backgroundImage: `url(${backgroundImage.url})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }
    : toCss(ownProps.styling);
  const activeStyling: CSSProperties | undefined = fadeInMs
    ? { ...styling, opacity: visible ? 1 : 0, transition: `opacity ${fadeInMs}ms ease-in` }
    : styling;

  return (
    <div
      data-id={record.id}
      data-factory="scene"
      className="h-full w-full"
      style={isActive ? activeStyling : { ...styling, display: 'none' }}
    >
      {new SceneFactory(record).renderItemComponents(record.items as RootRecord[])}
      {record.children}
    </div>
  );
};
