import { z } from 'zod';
import { cssProperties } from '@adaptivebehaviour/manifesto/src/manifesto/schemas';

// Props schemas for the ui collection. The Radix wrappers share one loose props shape (an optional
// `styling`: a class name or a style map); the two that read specific props have their own.

export const uiProps = z.looseObject({
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'UiProps' });

export const avatarProps = z.looseObject({
  src: z.string().optional(),
  alt: z.string().optional(),
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'AvatarProps' });

export const directionProps = z.looseObject({
  dir: z.enum(['ltr', 'rtl']).optional(),
  styling: z.union([z.string(), cssProperties]).optional(),
}).meta({ id: 'DirectionProps' });
