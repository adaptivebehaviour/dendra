'use client';

import { Portal as PortalPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Portal'` — wraps Radix Portal with optional default styles. */
export const Portal: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <div data-id={record.id}>
      <span style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
        Portal host (content rendered into document body)
      </span>
      <PortalPrimitive.Root>
        <div
          className={styled ? 'dropdown-menu-content' : undefined}
          style={{
            position: 'fixed',
            bottom: 'var(--spacing-4)',
            left: 'var(--spacing-4)',
            padding: 'var(--spacing-3)',
            zIndex: 50,
            pointerEvents: 'none',
          }}
        >
          {(record.items[0] as string) ?? 'Portaled content'}
        </div>
      </PortalPrimitive.Root>
    </div>
  );
};
