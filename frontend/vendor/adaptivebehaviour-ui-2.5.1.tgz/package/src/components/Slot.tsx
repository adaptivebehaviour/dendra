'use client';

import { Slot as SlotPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Slot'` — wraps Radix Slot with optional default styles. */
export const Slot: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <SlotPrimitive.Root data-id={record.id} className={styled ? 'button button-outline' : undefined}>
      <button type="button">{(record.items[0] as string) ?? 'Slot as button'}</button>
    </SlotPrimitive.Root>
  );
};
