'use client';

import { NavigationMenu as NavigationMenuPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'NavigationMenu'` — wraps Radix NavigationMenu with optional default styles. */
export const NavigationMenu: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <NavigationMenuPrimitive.Root data-id={record.id}>
      <NavigationMenuPrimitive.List style={{ display: 'flex', gap: 'var(--spacing-2)', listStyle: 'none', padding: 0, margin: 0 }}>
        <NavigationMenuPrimitive.Item>
          <NavigationMenuPrimitive.Trigger className={styled ? 'button button-ghost' : undefined}>
            {(record.items[0] as string) ?? 'Products'}
          </NavigationMenuPrimitive.Trigger>
          <NavigationMenuPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined} style={{ padding: 'var(--spacing-3)' }}>
            {(record.items[1] as string) ?? 'Product links'}
          </NavigationMenuPrimitive.Content>
        </NavigationMenuPrimitive.Item>
        <NavigationMenuPrimitive.Item>
          <NavigationMenuPrimitive.Link className={styled ? 'button button-ghost' : undefined} href="#">
            {(record.items[2] as string) ?? 'About'}
          </NavigationMenuPrimitive.Link>
        </NavigationMenuPrimitive.Item>
      </NavigationMenuPrimitive.List>
      <NavigationMenuPrimitive.Viewport />
    </NavigationMenuPrimitive.Root>
  );
};
