'use client';

import { ScrollArea as ScrollAreaPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'ScrollArea'` — wraps Radix ScrollArea with optional default styles. */
export const ScrollArea: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ScrollAreaPrimitive.Root
      data-id={record.id}
      style={styled ? {
        width: '100%',
        maxWidth: 320,
        height: 120,
        borderRadius: 'var(--radius-control)',
        border: '1px solid var(--color-border)',
        overflow: 'hidden',
      } : undefined}
    >
      <ScrollAreaPrimitive.Viewport style={{ width: '100%', height: '100%', padding: 'var(--spacing-3)' }}>
        <p style={{ margin: 0, fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
          {(record.items[0] as string) ??
            'Scrollable content. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.'}
        </p>
      </ScrollAreaPrimitive.Viewport>
      <ScrollAreaPrimitive.Scrollbar orientation="vertical" style={{ width: 8, padding: 2 }}>
        <ScrollAreaPrimitive.Thumb style={{ background: 'var(--color-border-strong)', borderRadius: 'var(--radius-pill)' }} />
      </ScrollAreaPrimitive.Scrollbar>
    </ScrollAreaPrimitive.Root>
  );
};
