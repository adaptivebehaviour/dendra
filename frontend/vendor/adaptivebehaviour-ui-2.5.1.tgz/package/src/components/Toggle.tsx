'use client';

import { Toggle as TogglePrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Toggle'` — wraps Radix Toggle with optional default styles. */
export const Toggle: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <TogglePrimitive.Root
      data-id={record.id}
      aria-label={(record.items[0] as string) ?? 'Toggle italic'}
      className={styled ? 'button button-ghost' : undefined}
    >
      {(record.items[0] as string) ?? 'Italic'}
    </TogglePrimitive.Root>
  );
};
