'use client';

import { ContextMenu as ContextMenuPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'ContextMenu'` — wraps Radix ContextMenu with optional default styles. */
export const ContextMenu: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <ContextMenuPrimitive.Root data-id={record.id}>
      <ContextMenuPrimitive.Trigger
        style={styled ? {
          display: 'block',
          padding: 'var(--spacing-6)',
          border: '1px dashed var(--color-border)',
          borderRadius: 'var(--radius-control)',
          color: 'var(--color-text-muted)',
          fontSize: 'var(--text-label)',
          userSelect: 'none',
        } : undefined}
      >
        {(record.items[0] as string) ?? 'Right-click here'}
      </ContextMenuPrimitive.Trigger>
      <ContextMenuPrimitive.Portal>
        <ContextMenuPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined}>
          <ContextMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            {(record.items[1] as string) ?? 'Item one'}
          </ContextMenuPrimitive.Item>
          <ContextMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            {(record.items[2] as string) ?? 'Item two'}
          </ContextMenuPrimitive.Item>
          <ContextMenuPrimitive.Separator className={styled ? 'dropdown-menu-separator' : undefined} />
          <ContextMenuPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>
            Item three
          </ContextMenuPrimitive.Item>
        </ContextMenuPrimitive.Content>
      </ContextMenuPrimitive.Portal>
    </ContextMenuPrimitive.Root>
  );
};
