'use client';

import { unstable_OneTimePasswordField as OneTimePasswordFieldPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'OneTimePasswordField'` — wraps Radix One-Time Password Field. */
export const OneTimePasswordField: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <OneTimePasswordFieldPrimitive.Root data-id={record.id} style={{ display: 'flex', gap: 'var(--spacing-2)' }}>
      {Array.from({ length: 6 }, (_, i) => (
        <OneTimePasswordFieldPrimitive.Input
          key={i}
          className={styled ? 'input' : undefined}
          style={{ width: 40, textAlign: 'center', padding: 0 }}
        />
      ))}
      <OneTimePasswordFieldPrimitive.HiddenInput />
    </OneTimePasswordFieldPrimitive.Root>
  );
};
