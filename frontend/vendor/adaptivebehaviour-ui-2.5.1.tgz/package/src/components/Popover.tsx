'use client';

import { Popover as PopoverPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Popover'` — wraps Radix Popover with optional default styles. */
export const Popover: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <PopoverPrimitive.Root data-id={record.id}>
      <PopoverPrimitive.Trigger className={styled ? 'button button-outline' : undefined}>
        {(record.items[0] as string) ?? 'Open popover'}
      </PopoverPrimitive.Trigger>
      <PopoverPrimitive.Portal>
        <PopoverPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined} sideOffset={4} style={{ padding: 'var(--spacing-3)' }}>
          {(record.items[1] as string) ?? 'Popover content'}
          <PopoverPrimitive.Close className={styled ? 'button button-ghost' : undefined} style={{ marginTop: 'var(--spacing-2)' }}>
            Close
          </PopoverPrimitive.Close>
        </PopoverPrimitive.Content>
      </PopoverPrimitive.Portal>
    </PopoverPrimitive.Root>
  );
};
