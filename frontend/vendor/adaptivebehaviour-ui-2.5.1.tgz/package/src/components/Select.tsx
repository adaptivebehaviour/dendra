'use client';

import { Select as SelectPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Select'` — wraps Radix Select with optional default styles. */
export const Select: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <SelectPrimitive.Root data-id={record.id} defaultValue="apple">
      <SelectPrimitive.Trigger className={styled ? 'button button-outline' : undefined} style={{ minWidth: 160, justifyContent: 'space-between' }}>
        <SelectPrimitive.Value placeholder={(record.items[0] as string) ?? 'Select…'} />
        <SelectPrimitive.Icon>▾</SelectPrimitive.Icon>
      </SelectPrimitive.Trigger>
      <SelectPrimitive.Portal>
        <SelectPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined} position="popper" sideOffset={4}>
          <SelectPrimitive.Viewport>
            <SelectPrimitive.Item value="apple" className={styled ? 'dropdown-menu-item' : undefined}>
              <SelectPrimitive.ItemText>Apple</SelectPrimitive.ItemText>
            </SelectPrimitive.Item>
            <SelectPrimitive.Item value="banana" className={styled ? 'dropdown-menu-item' : undefined}>
              <SelectPrimitive.ItemText>Banana</SelectPrimitive.ItemText>
            </SelectPrimitive.Item>
            <SelectPrimitive.Item value="orange" className={styled ? 'dropdown-menu-item' : undefined}>
              <SelectPrimitive.ItemText>Orange</SelectPrimitive.ItemText>
            </SelectPrimitive.Item>
          </SelectPrimitive.Viewport>
        </SelectPrimitive.Content>
      </SelectPrimitive.Portal>
    </SelectPrimitive.Root>
  );
};
