'use client';

import { Separator as SeparatorPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Separator'` — wraps Radix Separator with optional default styles. */
export const Separator: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <SeparatorPrimitive.Root
      data-id={record.id}
      decorative
      style={styled ? {
        height: 1,
        width: '100%',
        backgroundColor: 'var(--color-border)',
        margin: 'var(--spacing-2) 0',
      } : undefined}
    />
  );
};
