'use client';

import { unstable_PasswordToggleField as PasswordToggleFieldPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'PasswordToggleField'` — wraps Radix Password Toggle Field. */
export const PasswordToggleField: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <div data-id={record.id} style={{ display: 'flex', gap: 'var(--spacing-2)', maxWidth: 320 }}>
      <PasswordToggleFieldPrimitive.Root>
        <PasswordToggleFieldPrimitive.Input
          className={styled ? 'input' : undefined}
          placeholder={(record.items[0] as string) ?? 'Password'}
        />
        <PasswordToggleFieldPrimitive.Toggle className={styled ? 'button button-ghost' : undefined}>
          <PasswordToggleFieldPrimitive.Icon
            visible={<span aria-hidden="true">Hide</span>}
            hidden={<span aria-hidden="true">Show</span>}
          />
        </PasswordToggleFieldPrimitive.Toggle>
      </PasswordToggleFieldPrimitive.Root>
    </div>
  );
};
