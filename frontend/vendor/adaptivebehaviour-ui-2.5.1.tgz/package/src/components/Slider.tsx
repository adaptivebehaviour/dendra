'use client';

import { Slider as SliderPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Slider'` — wraps Radix Slider with optional default styles. */
export const Slider: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <SliderPrimitive.Root
      data-id={record.id}
      defaultValue={[40]}
      max={100}
      step={1}
      style={styled ? {
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        width: '100%',
        maxWidth: 320,
        height: 20,
      } : undefined}
    >
      <SliderPrimitive.Track
        style={styled ? {
          backgroundColor: 'var(--color-surface-hover)',
          position: 'relative',
          flexGrow: 1,
          height: 4,
          borderRadius: 'var(--radius-pill)',
        } : undefined}
      >
        <SliderPrimitive.Range
          style={styled ? {
            position: 'absolute',
            backgroundColor: 'var(--color-solid)',
            height: '100%',
            borderRadius: 'var(--radius-pill)',
          } : undefined}
        />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb
        style={styled ? {
          display: 'block',
          width: 16,
          height: 16,
          backgroundColor: 'var(--color-app-background)',
          border: '1px solid var(--color-border-strong)',
          borderRadius: 'var(--radius-pill)',
          boxShadow: 'var(--shadow-control)',
        } : undefined}
        aria-label={(record.items[0] as string) ?? 'Volume'}
      />
    </SliderPrimitive.Root>
  );
};
