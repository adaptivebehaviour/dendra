'use client';

import { Menubar as MenubarPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Menubar'` — wraps Radix Menubar with optional default styles. */
export const Menubar: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <MenubarPrimitive.Root
      data-id={record.id}
      style={styled ? {
        display: 'flex',
        gap: 'var(--spacing-1)',
        padding: 'var(--spacing-1)',
        borderRadius: 'var(--radius-control)',
        border: '1px solid var(--color-border)',
        backgroundColor: 'var(--color-app-background)',
      } : undefined}
    >
      <MenubarPrimitive.Menu>
        <MenubarPrimitive.Trigger className={styled ? 'button button-ghost' : undefined}>
          {(record.items[0] as string) ?? 'File'}
        </MenubarPrimitive.Trigger>
        <MenubarPrimitive.Portal>
          <MenubarPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined}>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>New</MenubarPrimitive.Item>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Open</MenubarPrimitive.Item>
          </MenubarPrimitive.Content>
        </MenubarPrimitive.Portal>
      </MenubarPrimitive.Menu>
      <MenubarPrimitive.Menu>
        <MenubarPrimitive.Trigger className={styled ? 'button button-ghost' : undefined}>
          {(record.items[1] as string) ?? 'Edit'}
        </MenubarPrimitive.Trigger>
        <MenubarPrimitive.Portal>
          <MenubarPrimitive.Content className={styled ? 'dropdown-menu-content' : undefined}>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Cut</MenubarPrimitive.Item>
            <MenubarPrimitive.Item className={styled ? 'dropdown-menu-item' : undefined}>Copy</MenubarPrimitive.Item>
          </MenubarPrimitive.Content>
        </MenubarPrimitive.Portal>
      </MenubarPrimitive.Menu>
    </MenubarPrimitive.Root>
  );
};
