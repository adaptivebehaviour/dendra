'use client';

import { Collapsible as CollapsiblePrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Collapsible'` — wraps Radix Collapsible with optional default styles. */
export const Collapsible: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <CollapsiblePrimitive.Root data-id={record.id} defaultOpen>
      <CollapsiblePrimitive.Trigger className={styled ? 'button button-ghost' : undefined}>
        {(record.items[0] as string) ?? 'Toggle'}
      </CollapsiblePrimitive.Trigger>
      <CollapsiblePrimitive.Content>
        {(record.items[1] as string) ?? 'Collapsible content'}
      </CollapsiblePrimitive.Content>
    </CollapsiblePrimitive.Root>
  );
};
