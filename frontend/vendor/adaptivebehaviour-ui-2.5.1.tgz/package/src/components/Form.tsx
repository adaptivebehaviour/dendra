'use client';

import { Form as FormPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Form'` — wraps Radix Form with optional default styles. */
export const Form: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <FormPrimitive.Root data-id={record.id} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-3)', maxWidth: 320 }}>
      <FormPrimitive.Field name="email">
        <FormPrimitive.Label className={styled ? 'label' : undefined}>
          {(record.items[0] as string) ?? 'Email'}
        </FormPrimitive.Label>
        <FormPrimitive.Control asChild>
          <input className={styled ? 'input' : undefined} type="email" required placeholder="you@example.com" />
        </FormPrimitive.Control>
        <FormPrimitive.Message match="valueMissing" style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-label)' }}>
          Please enter your email
        </FormPrimitive.Message>
      </FormPrimitive.Field>
      <FormPrimitive.Submit className={styled ? 'button button-solid' : undefined}>
        {(record.items[1] as string) ?? 'Submit'}
      </FormPrimitive.Submit>
    </FormPrimitive.Root>
  );
};
