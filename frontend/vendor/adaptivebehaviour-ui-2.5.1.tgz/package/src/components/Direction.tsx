'use client';

import { Direction as DirectionPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { propsOf } from '@adaptivebehaviour/manifesto/src/schema';
import { directionProps } from '../schemas';

/** Factory `'Direction'` — wraps Radix DirectionProvider. */
export const Direction: RecordComponent = ({ record }) => (
  <DirectionPrimitive.Provider dir={propsOf(directionProps, record).dir ?? 'ltr'}>
    <div data-id={record.id} style={{ fontSize: 'var(--text-label)', color: 'var(--color-text-muted)' }}>
      {(record.items[0] as string) ?? 'Direction provider (ltr)'}
    </div>
  </DirectionPrimitive.Provider>
);
