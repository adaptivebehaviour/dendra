'use client';

import { RadioGroup as RadioGroupPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/**
 * Factory `'RadioGroup'` — wraps Radix RadioGroup with optional default styles.
 * Renders one option per element of `record.items`, not a fixed count — each
 * item's own string value (or `Option <n>` if not a string) becomes that
 * option's label, and options are valued `'option-1'`, `'option-2'`, etc. in
 * `record.items` order.
 */
export const RadioGroup: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  const itemStyle = styled ? {
    width: 20,
    height: 20,
    borderRadius: 'var(--radius-pill)',
    border: '1px solid var(--color-border)',
    backgroundColor: 'var(--color-app-background)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
  } as const : undefined;
  return (
    <RadioGroupPrimitive.Root data-id={record.id} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-2)' }}>
      {record.items.map((item, index) => {
        const value = `option-${index + 1}`;
        const id = `${record.id}-${index + 1}`;
        return (
          <div key={value} style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)' }}>
            <RadioGroupPrimitive.Item value={value} id={id} style={itemStyle}>
              <RadioGroupPrimitive.Indicator style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: 'var(--color-solid)' }} />
            </RadioGroupPrimitive.Item>
            <label htmlFor={id} className={styled ? 'label' : undefined} style={{ marginBottom: 0 }}>
              {(item as string) ?? `Option ${index + 1}`}
            </label>
          </div>
        );
      })}
    </RadioGroupPrimitive.Root>
  );
};
