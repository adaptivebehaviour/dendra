'use client';

import { Tooltip as TooltipPrimitive } from 'radix-ui';
import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDefaultStyling } from '../styling';

/** Factory `'Tooltip'` — wraps Radix Tooltip with optional default styles. */
export const Tooltip: RecordComponent = ({ record }) => {
  const styled = useDefaultStyling(record);
  return (
    <TooltipPrimitive.Provider>
      <TooltipPrimitive.Root data-id={record.id}>
        <TooltipPrimitive.Trigger className={styled ? 'button button-outline' : undefined}>
          {(record.items[0] as string) ?? 'Hover'}
        </TooltipPrimitive.Trigger>
        <TooltipPrimitive.Portal>
          <TooltipPrimitive.Content
            className={styled ? 'dropdown-menu-content' : undefined}
            sideOffset={4}
            style={{ padding: 'var(--spacing-2) var(--spacing-3)', fontSize: 'var(--text-label)' }}
          >
            {(record.items[1] as string) ?? 'Tooltip content'}
            <TooltipPrimitive.Arrow style={{ fill: 'var(--color-app-background)' }} />
          </TooltipPrimitive.Content>
        </TooltipPrimitive.Portal>
      </TooltipPrimitive.Root>
    </TooltipPrimitive.Provider>
  );
};
