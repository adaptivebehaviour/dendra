// ── Types ─────────────────────────────────────────────────────────────────────

/** The typographic role a font fills in the application. */
export type FontRole = 'sans' | 'serif' | 'mono' | 'display';

/** Configuration for a single font family. */
export interface FontConfig {
  /** The font family name as it appears in Google Fonts, e.g. `'Inter'`. */
  family: string;
  /** Numeric font weights to load, e.g. `[400, 700]`. */
  weights: number[];
}

/** Application-level configuration produced by {@link defineConfig}. */
export interface Config {
  /** Font families loaded per typographic role. */
  fonts: Partial<Record<FontRole, FontConfig>>;
}

/**
 * Recursively makes all properties of `T` optional, including nested objects.
 * Used as the input type of {@link defineConfig}.
 */
export type DeepPartial<T> = T extends object
  ? { [K in keyof T]?: DeepPartial<T[K]> }
  : T;

// ── Defaults ──────────────────────────────────────────────────────────────────

const defaultConfig: Config = {
  fonts: {
    sans:  { family: 'Poppins',     weights: [400, 500, 600, 700] },
    serif: { family: 'Merriweather', weights: [400, 700] },
    mono:  { family: 'Space Mono',   weights: [400, 700] },
  },
};

// ── Internal helpers ──────────────────────────────────────────────────────────

function isPlainObject(val: unknown): val is Record<string, unknown> {
  return val !== null && typeof val === 'object' && !Array.isArray(val);
}

/**
 * Recursively merges `override` onto `base`. Plain-object values are merged;
 * all other values (primitives, arrays) are replaced. `undefined` values in
 * `override` are ignored, so unspecified keys are inherited from `base`.
 */
function deepMerge<T extends object>(base: T, override: DeepPartial<T>): T {
  const result: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const key of Object.keys(override as object)) {
    const overVal = (override as Record<string, unknown>)[key];
    if (overVal === undefined) continue;
    const baseVal = (base as Record<string, unknown>)[key];
    if (isPlainObject(baseVal) && isPlainObject(overVal)) {
      result[key] = deepMerge(baseVal, overVal as DeepPartial<Record<string, unknown>>);
    } else {
      result[key] = overVal;
    }
  }
  return result as T;
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Define application configuration by merging caller-supplied overrides onto
 * the built-in defaults.
 *
 * Unspecified keys at any depth are inherited from the defaults, so partial
 * overrides work correctly — e.g. setting only `fonts.sans.family` keeps the
 * default `weights` for that role, and unmentioned roles (serif, mono) are
 * inherited unchanged.
 *
 * @param overrides - Partial configuration to merge over the defaults.
 * @returns The complete, merged {@link Config} object.
 *
 * @example
 * ```ts
 * // Override just the sans family; all other defaults are preserved.
 * const config = defineConfig({
 *   fonts: { sans: { family: 'Roboto' } },
 * });
 * ```
 */
export function defineConfig(overrides: DeepPartial<Config> = {}): Config {
  return deepMerge(defaultConfig, overrides);
}

/**
 * Build a Google Fonts CSS2 stylesheet URL from a {@link Config} object.
 *
 * Each font role present in `config.fonts` becomes a `family` parameter.
 * Weights are sorted ascending. The `display=swap` performance hint is always
 * appended.
 *
 * Returns an empty string when no fonts are configured.
 *
 * @param config - A config object returned by {@link defineConfig}.
 * @returns A Google Fonts CSS2 URL, or `''` if no fonts are defined.
 *
 * @example
 * ```ts
 * const url = googleFontsUrl(config);
 * // "https://fonts.googleapis.com/css2?family=Inter:wght@400;700&...&display=swap"
 * ```
 */
export function googleFontsUrl(config: Config): string {
  const families = (Object.values(config.fonts) as (FontConfig | undefined)[])
    .filter((f): f is FontConfig => f !== undefined)
    .map(({ family, weights }) => {
      const sorted = [...weights].sort((a, b) => a - b);
      return `family=${family.replace(/ /g, '+')}:wght@${sorted.join(';')}`;
    });

  if (families.length === 0) return '';

  return `https://fonts.googleapis.com/css2?${families.join('&')}&display=swap`;
}
