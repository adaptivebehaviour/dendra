import type { ReactElement } from 'react';
import {
  build, buildAsync, buildInstance, buildRecord, buildComponent, buildOperation,
  recordRegistry, instanceRegistry, componentRegistry,
  type RegistryTarget, type RecordInstance, type RecordComponent, type RecordComponentProps,
} from './create';
import { Root, rootRecord, type RootRecord, type RootConfig } from './Root';
import { warn } from './warn';

/**
 * A collection's declaration: its `id`, the collections it may import
 * (`dependsOn` — each must be registered before it), the ids it deliberately
 * overrides (`overrides` — a collision on any other id is reported), and its
 * `register` function, which writes the collection's own records/components/
 * instances into the {@link RegistryTarget} it's handed. `overrides: '*'` means
 * "may override anything" — what the legacy `registerCollection()` path uses.
 */
export interface CollectionDefinition {
  readonly id: string;
  readonly dependsOn: readonly string[];
  readonly overrides: readonly string[] | '*';
  readonly register: (target: RegistryTarget) => void;
}

/** What to do when a collection overwrites an id another collection registered and does not list it in `overrides`. */
export type CollisionMode = 'warn' | 'throw' | 'ignore';

export interface RegistryOptions {
  /** Default `'warn'`. Use `'throw'` in tests, `'warn'` in applications. */
  onCollision?: CollisionMode;
}

/** The shared creation surface returned by {@link Registry.getCollection}. */
export interface Collection {
  create: typeof build;
  createAsync: typeof buildAsync;
  createInstance: typeof buildInstance;
  createRecord: typeof buildRecord;
  /**
   * Builds a record from a factory string/options — same arguments as
   * {@link Collection.createRecord} — then renders it, always returning a
   * `ReactElement`. Throws if no component is registered for the resolved
   * record's `factory`. For rendering a record you already have in hand
   * (nothing left to build), use {@link Collection.renderComponent} instead.
   */
  createComponent: (
    arg: Parameters<typeof buildRecord>[0],
    options?: Parameters<typeof buildRecord>[1]
  ) => ReactElement<RecordComponentProps>;
  createOperation: typeof buildOperation;
  /**
   * Renders an already-built {@link RootRecord} — nothing is created or
   * resolved first, unlike {@link Collection.createComponent}.
   */
  renderComponent: typeof buildComponent;
}

/** A composed set of collections: validated once, each collection's own scope captured once. */
export interface Registry {
  /** Collection ids in load order. */
  readonly ids: readonly string[];
  /**
   * The merged view across every collection (no `collectionId`), or one
   * collection's own scope, bypassing whatever overrides it in the merged
   * view. The collections' scopes are merged into the shared `create.ts`
   * registries on every call (cheap, and idempotent), so the shared registries
   * can be reset between tests without recomposing.
   * @throws If `collectionId` is given but no collection has that id.
   */
  getCollection(collectionId?: string): Collection;
}

/**
 * Declares a collection. See {@link CollectionDefinition}.
 *
 * ```ts
 * export const scenes = defineCollection({ id: 'scenes', dependsOn: ['manifesto'], register });
 * ```
 */
export function defineCollection(definition: {
  id: string;
  dependsOn?: readonly string[];
  overrides?: readonly string[] | '*';
  register: (target: RegistryTarget) => void;
}): CollectionDefinition {
  return {
    id: definition.id,
    dependsOn: definition.dependsOn ?? [],
    overrides: definition.overrides ?? [],
    register: definition.register,
  };
}

// The baseline entries every scope is seeded with (see emptyTarget()). They are
// never collisions: a collection that merely carries them did not register them.
const OBJECT_INSTANCE: RecordInstance = (record) => new Root(record);

function emptyTarget(): RegistryTarget {
  return {
    recordRegistry: new Map<string, RootConfig>([[rootRecord.id, rootRecord]]),
    instanceRegistry: new Map<string, RecordInstance>([['object', OBJECT_INSTANCE]]),
    componentRegistry: new Map<string, RecordComponent>(),
  };
}

function validate(collections: readonly CollectionDefinition[]): void {
  const seen = new Set<string>();
  for (const { id, dependsOn } of collections) {
    if (seen.has(id)) throw new Error(`Duplicate collection id '${id}'.`);
    for (const dependency of dependsOn) {
      if (!seen.has(dependency)) {
        const registered = collections.some((c) => c.id === dependency);
        throw new Error(
          registered
            ? `Collection '${id}' depends on '${dependency}', which must be registered before it.`
            : `Collection '${id}' depends on '${dependency}', which is not registered.`
        );
      }
    }
    seen.add(id);
  }
}

/**
 * Composes `collections` — in order, which is the load order — into a
 * {@link Registry}. Validates declared dependencies (throws on a missing or
 * mis-ordered one), runs each collection's `register` once into a private
 * scope, and reports every id a collection overwrites without listing it in
 * `overrides` according to `onCollision`.
 *
 * Later collections still override earlier ones in the merged view, and the
 * shadowed entry stays reachable through `getCollection(id)` for the
 * collection that registered it.
 */
export function createRegistry(collections: readonly CollectionDefinition[], options: RegistryOptions = {}): Registry {
  const onCollision = options.onCollision ?? 'warn';
  validate(collections);

  const scopes = new Map<string, RegistryTarget>();
  const owners = new Map<string, string>();
  const seeds: Array<[string, keyof RegistryTarget, unknown]> = [
    ['root', 'recordRegistry', rootRecord],
    ['object', 'instanceRegistry', OBJECT_INSTANCE],
  ];

  for (const collection of collections) {
    const scope = emptyTarget();
    collection.register(scope);
    scopes.set(collection.id, scope);
    for (const registryName of ['recordRegistry', 'instanceRegistry', 'componentRegistry'] as const) {
      const registry = scope[registryName] as Map<string, unknown>;
      for (const [key, value] of registry) {
        if (seeds.some(([seedKey, seedRegistry, seedValue]) => seedKey === key && seedRegistry === registryName && seedValue === value)) {
          continue;
        }
        const ownerKey = `${registryName}:${key}`;
        const previous = owners.get(ownerKey);
        const declared = collection.overrides === '*' || collection.overrides.includes(key);
        if (previous !== undefined && !declared && onCollision !== 'ignore') {
          const message =
            `Collection '${collection.id}' overrides '${key}' (${registryName}) already registered by '${previous}'; ` +
            `list it in the collection's overrides to declare this on purpose.`;
          if (onCollision === 'throw') throw new Error(message);
          warn(message);
        }
        owners.set(ownerKey, collection.id);
      }
    }
  }

  function getCollection(collectionId?: string): Collection {
    for (const scope of scopes.values()) {
      for (const [key, value] of scope.recordRegistry) recordRegistry.set(key, value);
      for (const [key, value] of scope.instanceRegistry) instanceRegistry.set(key, value);
      for (const [key, value] of scope.componentRegistry) componentRegistry.set(key, value);
    }

    let target: RegistryTarget | undefined;
    if (collectionId !== undefined) {
      target = scopes.get(collectionId);
      if (!target) {
        throw new Error(`No collection registered with id '${collectionId}'.`);
      }
    }

    const recordCache = new Map<string, RootRecord>();
    const instancePropsCache = new Map<string, Record<string, unknown>>();

    return {
      create: (arg, options) => build(arg, options, recordCache, target),
      createAsync: (arg, options) => buildAsync(arg, options, recordCache, target),
      createInstance: (arg, options) => buildInstance(arg, options, instancePropsCache),
      createRecord: (arg, options) => buildRecord(arg, options, recordCache, target?.recordRegistry),
      createComponent: (arg, options) => buildComponent(
        buildRecord(arg, options, recordCache, target?.recordRegistry), target?.componentRegistry
      ),
      createOperation: (arg, args) => buildOperation(arg, args, recordCache, target),
      renderComponent: (record) => buildComponent(record, target?.componentRegistry),
    };
  }

  return { ids: collections.map((c) => c.id), getCollection };
}
