import { z } from 'zod';
import type { RootConfig, RootRecord } from './Root';
import type { RecordComponent, RecordInstance, RegistryTarget } from './create';

// ── Schemas for records ───────────────────────────────────────────────────────
// Records are plain data that crosses boundaries (records.json, a CMS, the
// database, agent output), so the record shape and each factory's `props` are
// described once, in Zod, and everything else is derived from that: TypeScript
// types by inference, JSON Schema (`contracts/schemas/`, exported by
// `scripts/export-schemas.ts`), and the Python Pydantic models generated from
// those. Internal composition stays plain TSX; schemas are for boundary data.

/** A complete record — what `build*()` return and what is stored. */
export const recordSchema = z.object({
  id: z.string(),
  kind: z.string(),
  factory: z.string(),
  props: z.record(z.string(), z.unknown()),
  items: z.array(z.unknown()),
  refs: z.array(z.string()),
}).meta({ id: 'RootRecord', title: 'RootRecord', description: 'A complete manifesto record.' });

/**
 * A `records.json` entry: every field optional (a collection declares only what is
 * unique to the record) plus `extends`. Unknown top-level keys are errors.
 */
export const recordConfigSchema = z.strictObject({
  id: z.string().optional(),
  kind: z.string().optional().describe('The structural parent. Never supplies defaults.'),
  extends: z.string().optional().describe('The id of a registered record this one takes its defaults from.'),
  factory: z.string().optional(),
  props: z.record(z.string(), z.unknown()).optional(),
  items: z.array(z.unknown()).optional(),
  refs: z.array(z.string()).optional(),
}).meta({ id: 'RecordConfig', title: 'RecordConfig', description: 'A partially declared record, as written in records.json.' });

// ── Typed access to validated props ────────────────────────────────────────────────

type PropsShape = z.ZodObject<z.ZodRawShape>;

/**
 * `record.props` with the inferred type of `schema`. A typed *view* of data that was validated at the
 * boundary (records.json at load, factory products when built) — it does not parse again. This is
 * the one place `Record<string, unknown>` is narrowed to a schema's type, replacing the per-field
 * `props.x as T` casts components used to carry.
 */
export function propsOf<P extends PropsShape>(schema: P, record: { props: Record<string, unknown> }): z.infer<P> {
  void schema; // the schema only carries the type; validation happened when the record entered the system
  return record.props as z.infer<P>;
}

// ── Errors ────────────────────────────────────────────────────────────────────

/** A validation failure whose message names the offending path, e.g. `records.json[2].props.url: …`. */
export class SchemaError extends Error {
  readonly issues: readonly string[];
  constructor(message: string, issues: readonly string[]) {
    super(message);
    this.name = 'SchemaError';
    this.issues = issues;
  }
}

function formatPath(prefix: string, path: readonly PropertyKey[]): string {
  let out = prefix;
  for (const segment of path) {
    out += typeof segment === 'number' ? `[${segment}]` : `.${String(segment)}`;
  }
  return out;
}

/** One `<path>: <message>` line per Zod issue, the path starting at `prefix`. */
export function formatIssues(prefix: string, error: z.ZodError): string[] {
  return error.issues.map((issue) => `${formatPath(prefix, issue.path)}: ${issue.message}`);
}

// ── Factory definitions ──────────────────────────────────────────────────────────

export interface FactoryDefinitionInput<P extends PropsShape> {
  /** The factory key (`'image'`, `'stage'`, …). */
  type: string;
  /** The factory's `props`, as a Zod object. Use `z.looseObject({...})`: records carry other props too. */
  props: P;
  /** Schema for `items`. Default: any array. */
  items?: z.ZodType;
  /** The React component rendering the factory's records, registered into `componentRegistry`. */
  component?: RecordComponent;
  /** The instance constructor, registered into `instanceRegistry`. */
  instance?: RecordInstance;
}

export interface FactoryDefinition<P extends PropsShape> {
  readonly type: string;
  readonly props: P;
  readonly items: z.ZodType;
  readonly component?: RecordComponent;
  readonly instance?: RecordInstance;
  /** The record's props with this factory's inferred type — a typed view of the already-validated data, not a parse. */
  propsOf(record: Pick<RootRecord, 'props'>): z.infer<P>;
  /** Validates `record` against this factory's schema, throwing a path-qualified {@link SchemaError}. */
  parse(record: RootRecord): InferNode<FactoryDefinition<P>>;
  /** Registers the component/instance (when given) into `target` and the schema into {@link factorySchemas}. */
  register(target: RegistryTarget): void;
}

/** The inferred props type of a defined factory. */
export type InferProps<F extends { props: z.ZodType }> = z.infer<F['props']>;

/** A record for a defined factory, with `props` (and `factory`) typed from its schema. */
export type InferNode<F extends { type: string; props: z.ZodType }> =
  Omit<RootRecord, 'factory' | 'props'> & { factory: F['type']; props: InferProps<F> };

/** Every defined factory's schema, by factory key — consulted when a product is built and when records.json is loaded. */
export const factorySchemas = new Map<string, FactoryDefinition<PropsShape>>();

export function defineFactory<P extends PropsShape>(input: FactoryDefinitionInput<P>): FactoryDefinition<P> {
  const items = input.items ?? z.array(z.unknown());
  const definition: FactoryDefinition<P> = {
    type: input.type,
    props: input.props,
    items,
    component: input.component,
    instance: input.instance,
    propsOf(record) {
      return record.props as z.infer<P>;
    },
    parse(record) {
      validateProduct(record, definition as unknown as FactoryDefinition<PropsShape>);
      return record as unknown as InferNode<FactoryDefinition<P>>;
    },
    register(target) {
      if (input.component) target.componentRegistry.set(input.type, input.component);
      if (input.instance) target.instanceRegistry.set(input.type, input.instance);
      factorySchemas.set(input.type, definition as unknown as FactoryDefinition<PropsShape>);
    },
  };
  return definition;
}

// ── Validation ────────────────────────────────────────────────────────────────────

/**
 * Validates a built product's props and items against its factory's schema, if one is
 * defined for `record.factory` (an undefined factory is untyped and always passes).
 * @throws {SchemaError} naming the factory, the record id and every offending path.
 */
export function validateProduct(record: RootRecord, definition: FactoryDefinition<PropsShape> | undefined = factorySchemas.get(record.factory)): void {
  if (!definition) return;
  const issues: string[] = [];
  const props = definition.props.safeParse(record.props);
  if (!props.success) issues.push(...formatIssues('props', props.error));
  const items = definition.items.safeParse(record.items);
  if (!items.success) issues.push(...formatIssues('items', items.error));
  if (issues.length > 0) {
    throw new SchemaError(`Invalid record '${record.id}' for factory '${record.factory}':\n  ${issues.join('\n  ')}`, issues);
  }
}

/**
 * Validates the entries of a collection's `records.json` as it is loaded at registrar time:
 * each entry must match {@link recordConfigSchema}, and — when its factory has a defined
 * schema — its (partial) `props` must match that too. Returns the entries typed.
 * @param source - How the file is named in errors, e.g. `'manifesto/records.json'`.
 * @throws {SchemaError} listing every problem with its `source[index].path`.
 */
export function validateRecordsJson(source: string, entries: unknown): RootConfig[] {
  const issues: string[] = [];
  if (!Array.isArray(entries)) {
    throw new SchemaError(`${source}: expected an array of records.`, [`${source}: expected an array of records.`]);
  }
  entries.forEach((entry, index) => {
    const at = `${source}[${index}]`;
    const parsed = recordConfigSchema.safeParse(entry);
    if (!parsed.success) {
      issues.push(...formatIssues(at, parsed.error));
      return;
    }
    const definition = factorySchemas.get(parsed.data.factory ?? parsed.data.id ?? '');
    if (definition && parsed.data.props) {
      const props = definition.props.partial().safeParse(parsed.data.props);
      if (!props.success) issues.push(...formatIssues(`${at}.props`, props.error));
    }
  });
  if (issues.length > 0) {
    throw new SchemaError(`Invalid records in ${source}:\n  ${issues.join('\n  ')}`, issues);
  }
  return entries as RootConfig[];
}
