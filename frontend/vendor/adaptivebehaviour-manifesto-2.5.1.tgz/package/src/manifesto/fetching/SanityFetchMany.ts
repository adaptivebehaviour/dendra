import { Operation, OperationResult, type ArgSpec } from '../../Runnable';
import type { RootConfig } from '../../Root';
import { toItems } from '../../items';
import type { SecretResolver } from './Fetch';
import { formatIssues } from '../../schema';
import { sanityDocumentsSchema } from '../schemas';
import { fetchSanityGroq } from './sanityGroq';

/**
 * Factory `sanity-fetch-many` — fetches multiple Sanity documents by their
 * document-defined `id` fields in a single GROQ query, for callers that need
 * many documents at once (e.g. a game/SPA resolving an asset manifest)
 * rather than one authenticated round trip per document — see
 * {@link ../manifesto/SanityFetch.ts}'s own doc comment for the
 * single-document version this parallels; `props`/auth handling are
 * identical.
 *
 * Uses `*[id in $ids]`, so the result is an array — documents whose `id`
 * isn't in `ids` are simply absent from it, no per-id error. Order of the
 * returned array is not guaranteed to match the order of `ids`; a caller
 * that needs to preserve order should re-index by `id` itself.
 *
 * `ids` (the documents to fetch) is the one run-time argument — see
 * `argSpecs` — so the same configured operation can fetch different
 * document sets across calls.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const record = (collection.create('sanity-fetch-many', {
 *   props: { projectId: 'myprojectid' },
 * }) as SanityFetchMany).record();
 *
 * // Later, from that same record — construct again and fetch documents:
 * const result = await new SanityFetchMany(record).run({ ids: ['a', 'b'] }, (name) => process.env[name]);
 * ```
 */
export class SanityFetchMany extends Operation {
  static argSpecs: ArgSpec[] = [
    { id: 'ids', type: 'json', help: 'Ids of the Sanity documents to fetch', required: true },
  ];

  constructor(config: RootConfig = {}) {
    super(config);
  }

  /**
   * Fetch the Sanity documents identified by `args.ids`.
   *
   * @param args - Coerced arguments, per `argSpecs` — just `ids`.
   * @param resolveSecret - Resolves `props.tokenEnvVar` to the real token;
   *   required since every Sanity document fetch is authenticated.
   * @returns An {@link OperationResult} whose `.payload.documents` is the
   *   fetched array — an error result if `props.projectId` is missing, the
   *   token can't be resolved, `ids` is missing/empty, or the request fails.
   *   Never errors solely because some `ids` didn't match a document — that
   *   just shrinks the returned array.
   */
  async execute(args: Record<string, unknown>, resolveSecret?: SecretResolver): Promise<OperationResult> {
    const documentIds = args.ids as string[] | undefined;
    if (!Array.isArray(documentIds) || documentIds.length === 0) {
      return OperationResult.error(`'${this.factory}' requires a non-empty 'ids' array argument.`);
    }

    const response = await fetchSanityGroq({
      props: this.props,
      factory: this.factory,
      query: '*[id in $ids]',
      params: { $ids: JSON.stringify(documentIds) },
      describe: `documents [${documentIds.join(', ')}]`,
      errorPayload: { ids: documentIds },
      resolveSecret,
    });
    if (!response.ok) {
      return response.error;
    }

    const documents = toItems(response.result);
    // The response body is data from outside the system: check its shape before handing it on.
    const checked = sanityDocumentsSchema.safeParse(documents);
    if (!checked.success) {
      return OperationResult.error(
        `Sanity documents [${documentIds.join(', ')}] have an unexpected shape:\n  ${formatIssues('result', checked.error).join('\n  ')}`,
        1,
        { ids: documentIds }
      );
    }
    return OperationResult.ok(JSON.stringify(documents), { ids: documentIds, documents });
  }

  /**
   * Entry point for import and instance-method use. Overrides
   * {@link Operation.run} to thread an optional {@link SecretResolver}
   * through to {@link execute}, same pattern as {@link SanityFetch.run}.
   *
   * @param args - `{ ids }` — the documents to fetch.
   * @param resolveSecret - Forwarded to {@link execute}.
   */
  async run(args?: unknown, resolveSecret?: SecretResolver): Promise<string> {
    const coerced = (args ?? {}) as Record<string, unknown>;
    const result = await this.execute(coerced, resolveSecret);
    return result.text;
  }
}

/**
 * Import entry point. `config` is treated as `{ props, ids }` — `props`
 * configures the operation (`projectId`/`dataset`/...) at construction time,
 * same split as `SanityFetch.ts`'s own module-level `run()`; `ids` is passed
 * through as the run-time argument. `resolveSecret` is forwarded unchanged.
 */
export function run(config?: unknown, resolveSecret?: SecretResolver): Promise<string> {
  const { props, ...args } = (config ?? {}) as RootConfig & Record<string, unknown>;
  return new SanityFetchMany({ factory: 'sanity-fetch-many', props }).run(args, resolveSecret);
}
