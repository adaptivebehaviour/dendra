import { OperationResult } from '../../Runnable';
import { propsOf } from '../../schema';
import { sanityProps } from '../schemas';
import type { SecretResolver } from './Fetch';

/**
 * Shared GROQ-query plumbing for `SanityFetch` and `SanityFetchMany` — both
 * resolve the same `props` (`projectId`/`dataset`/`apiVersion`/
 * `tokenEnvVar`), resolve the same secret, and perform the same
 * authenticated GET against Sanity's `/data/query/` endpoint; only the query
 * string/params, and what a caller does with a found-vs-missing result,
 * differ between "one document" and "many documents". That difference is
 * kept as two separate `Operation` subclasses (see each file's own doc
 * comment for why merging them, or making one extend the other, isn't a
 * good fit) — this module exists so the identical parts aren't duplicated
 * between them.
 *
 * Not itself an `Operation` — a plain function both classes' `execute()`
 * calls, each still owning its own arg validation, query construction, and
 * found/not-found policy on top of this shared result.
 */

/** Everything {@link fetchSanityGroq} needs beyond an `Operation`'s own `props`. */
export interface SanityGroqRequest {
  /** The Operation's own `props` — `projectId`/`dataset`/`apiVersion`/`tokenEnvVar`. */
  props: Record<string, unknown>;
  /** The Operation's own `factory` — used only to name it in error messages. */
  factory: string;
  /** The GROQ query string, e.g. `'*[id == $id][0]'` or `'*[id in $ids]'`. */
  query: string;
  /** Query parameters beyond `query` itself — e.g. `{ $id: JSON.stringify(id) }`. */
  params: Record<string, string>;
  /** Folded into a fetch-failure error message, e.g. `"document with id 'apple-whole'"` or `"documents [a, b]"`. */
  describe: string;
  /** Folded into a fetch-failure error's `.payload` — e.g. `{ id }` or `{ ids }`. */
  errorPayload?: Record<string, unknown>;
  resolveSecret?: SecretResolver;
}

/** Either the raw, untyped GROQ `result` value, or an {@link OperationResult} describing why the request failed. */
export type SanityGroqResponse = { ok: true; result: unknown } | { ok: false; error: OperationResult };

/**
 * Resolves `props`/secret, performs the authenticated GROQ query, and
 * returns either its raw `result` or an error `OperationResult` — the
 * caller decides what "found nothing" means for its own case (an error for
 * a single document, an empty array for many).
 */
export async function fetchSanityGroq({
  props,
  factory,
  query,
  params,
  describe,
  errorPayload,
  resolveSecret,
}: SanityGroqRequest): Promise<SanityGroqResponse> {
  const typed = propsOf(sanityProps, { props });
  const projectId = typed.projectId;
  if (!projectId) {
    return { ok: false, error: OperationResult.error(`'${factory}' has no props.projectId set.`) };
  }

  const dataset = typed.dataset ?? 'production';
  const apiVersion = typed.apiVersion ?? '2024-01-01';

  const tokenEnvVar = typed.tokenEnvVar ?? 'SANITY_TOKEN_READ';
  const token = resolveSecret?.(tokenEnvVar);
  if (!token) {
    return {
      ok: false,
      error: OperationResult.error(
        `'${factory}' could not resolve secret '${tokenEnvVar}' — is it set, and was a resolveSecret provided?`
      ),
    };
  }

  const searchParams = new URLSearchParams({ query, ...params });
  const url = `https://${projectId}.api.sanity.io/v${apiVersion}/data/query/${dataset}?${searchParams.toString()}`;

  let response: Response;
  try {
    response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  } catch (err) {
    return {
      ok: false,
      error: OperationResult.error(`Fetch of Sanity ${describe} failed: ${(err as Error).message}`, 1, errorPayload),
    };
  }
  if (!response.ok) {
    return {
      ok: false,
      error: OperationResult.error(
        `Fetch of Sanity ${describe} failed: ${response.status} ${response.statusText}`,
        1,
        { ...errorPayload, status: response.status }
      ),
    };
  }

  const body = (await response.json()) as { result?: unknown };
  return { ok: true, result: body.result };
}
