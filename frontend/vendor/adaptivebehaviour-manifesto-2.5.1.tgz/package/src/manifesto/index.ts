import { defineCollection } from '../registry';
import { fromRecordProps, type RegistryTarget } from '../create';
import { defineFactory, validateRecordsJson } from '../schema';
import { fetchProps, helloWorldProps, imageProps, rootProps, sanityProps, styledProps } from './schemas';
import { Root } from './components/Root';
import { ContainerComponent } from './components/ContainerComponent';
import { Text } from './components/Text';
import { Image } from './components/Image';
import { ItemComponent } from './components/ItemComponent';
import { HelloWorld } from './HelloWorld';
import { ContainerComponentFactory } from './factories/ContainerComponentFactory';
import { ItemComponentFactory } from './factories/ItemComponentFactory';
import { ImageFactory } from './factories/ImageFactory';
import { Fetch } from './fetching/Fetch';
import { SanityFetch } from './fetching/SanityFetch';
import { SanityFetchMany } from './fetching/SanityFetchMany';
import records from './records.json' with { type: 'json' };

/**
 * Registers this collection's records, then its factories, into the
 * {@link RegistryTarget} it's handed — `records.json` entries (`recordRegistry`
 * — e.g. `sanity-fetch`'s `projectId`/`dataset`, `image`'s default
 * `url`/`width`/`height`/`alt`, so a consumer can reference either by `kind`
 * or by factory name instead of repeating their defaults at every call
 * site), plus `root`/`component`/`item-component`/`text`/`image`
 * (`componentRegistry`) and
 * `hello-world`/`fetch`/`sanity-fetch`/`sanity-fetch-many`/`component`/
 * `item-component`/`image` (`instanceRegistry` — the last three
 * Factory-capable classes, the rest Runnables; see Nomenclature's "Runnable
 * objects"/"Factory objects"). `component` ({@link ContainerComponentFactory}),
 * `item-component` ({@link ItemComponentFactory}), and `image`
 * ({@link ImageFactory}) all have custom `instanceRegistry` entries rather
 * than going through the generic {@link Factory} default — each needs to
 * resolve `items` into a component/props in its own way, which the generic
 * default can't provide (see each class's own doc comment). `component`/
 * `item-component` are the two generic, purpose-free wrappers — differing
 * only in whether every element of `items` is rendered as a child or only
 * the first — while `image` resolves at most one item into `props` instead
 * of rendering it as a child at all.
 *
 * Writes into `target` rather than `create.ts`'s module-level registries
 * directly — `getCollection.ts` calls this against a fresh, empty target to
 * capture exactly what this collection declares (for `getCollection('manifesto')`'s
 * own-scope resolution) before merging it into the shared global registries
 * — see `getCollection.ts`'s own module comment for the full mechanism.
 */
export function register(target: RegistryTarget): void {
  // Each factory is defined with its props schema; registering it also records the schema, which
  // is checked against the factory's records as they are built and against records.json below.
  const factories = [
    defineFactory({ type: 'root', props: rootProps, component: Root }),
    defineFactory({ type: 'component', props: styledProps, component: fromRecordProps(ContainerComponent, 'ContainerComponent'), instance: (record) => new ContainerComponentFactory(record) }),
    defineFactory({ type: 'item-component', props: styledProps, component: fromRecordProps(ItemComponent, 'ItemComponent'), instance: (record) => new ItemComponentFactory(record) }),
    defineFactory({ type: 'text', props: styledProps, component: Text }),
    defineFactory({ type: 'image', props: imageProps, component: Image, instance: (record) => new ImageFactory(record) }),
    defineFactory({ type: 'hello-world', props: helloWorldProps, instance: (record) => new HelloWorld(record) }),
    defineFactory({ type: 'fetch', props: fetchProps, instance: (record) => new Fetch(record) }),
    defineFactory({ type: 'sanity-fetch', props: sanityProps, instance: (record) => new SanityFetch(record) }),
    defineFactory({ type: 'sanity-fetch-many', props: sanityProps, instance: (record) => new SanityFetchMany(record) }),
  ];
  for (const factory of factories) factory.register(target);

  for (const record of validateRecordsJson('manifesto/records.json', records)) {
    target.recordRegistry.set(record.id as string, record);
  }
}

/** This collection's declaration, for composing into a registry (see registry.ts's createRegistry()). */
export const manifesto = defineCollection({ id: 'manifesto', register });
