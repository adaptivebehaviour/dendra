import type { ReactNode } from 'react';
import type { RecordPropsComponent } from '../../create';
import type { RootRecord } from '../../Root';
import { propsOf } from '../../schema';
import { styledProps, toCss } from '../schemas';
import { ContainerComponentFactory } from '../factories/ContainerComponentFactory';

/**
 * Factory `'component'` — renders a generic record wrapper, styled via
 * `record.props.styling` when present, with each element of `record.items`
 * rendered as a child. `items` is expected to already be plain, complete
 * {@link RootRecord}s by the time this runs — see `../factories/ContainerComponentFactory.ts`'s
 * inherited `produce()` (from `ContainerFactory`), which resolves each raw item spec (a factory string or
 * options object) into one before this component ever renders, rather than
 * this component doing any further creation/resolution itself. Rendering
 * those already-resolved items is delegated to {@link ContainerComponentFactory.renderItemComponents}
 * (a plain, stateless instance method — constructing a fresh `ContainerComponentFactory`
 * here just to call it costs nothing) rather than inlined here, so any other
 * component built on `ContainerComponentFactory` can reuse the same
 * per-item render loop instead of duplicating it — it throws if a given
 * item's own factory has no registered component, the same as it would for
 * any other unrenderable record, not specially handled here.
 *
 * `ContainerComponent` is one half of a deliberate name pairing with
 * `ContainerComponentFactory` — its own `renderComponent(items)` builds a
 * record and renders it through this exact function, rather than
 * duplicating this render body. This function is the single place
 * `renderItemComponents()` ever actually runs, which is what keeps that
 * pairing from double-rendering or looping — see
 * `ContainerComponentFactory.renderComponent()`'s own doc comment for the
 * full reasoning.
 *
 * The sibling of `ItemComponent` (`ItemComponent.tsx`) — same generic,
 * purpose-free wrapper shape, differing only in rendering *every* element
 * of `items` (this one) rather than only the first.
 *
 * Takes an optional `children` as a property on its one argument, alongside
 * `record`'s own fields — not a second, separate function parameter.
 * React never calls a function component with more than one argument
 * (whether dispatched via `componentRegistry`/`buildComponent()` — through
 * the `fromRecordProps()` adapter `index.ts` registers it with — or via
 * `createElement()`/JSX), so a second
 * positional parameter could only ever be reached by a caller bypassing
 * React and calling this function directly — a real but narrow capability
 * (see the git history of this file for that earlier, rejected design).
 * Folding `children` into the single argument instead means the ordinary,
 * React-mediated paths work too: `createElement(ContainerComponent, record,
 * someNode)` — or, equivalently, JSX like `<ContainerComponent {...record}>
 * {someNode}</ContainerComponent>` — has React itself merge `someNode` into
 * `record.children` before calling this function with that one merged
 * object, exactly the same auto-merging JSX has always done for ordinary
 * `{ record, children }`-shaped components. `componentRegistry` dispatch
 * never has a `children` to attach, so it stays `undefined` there —
 * unchanged, items-only behavior. Renders *after* the items rendered from
 * `record.items` — content resolved through the record/factory system
 * first, then anything hand-composed on top of it.
 */
export const ContainerComponent: RecordPropsComponent = (record: RootRecord & { children?: ReactNode }) => (
  <div data-id={record.id} data-factory="component" style={toCss(propsOf(styledProps, record).styling)}>
    {new ContainerComponentFactory(record).renderItemComponents(record.items as RootRecord[])}
    {record.children}
  </div>
);
