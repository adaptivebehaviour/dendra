import type { RecordPropsComponent } from '../../create';
import type { RootRecord } from '../../Root';
import { propsOf } from '../../schema';
import { styledProps, toCss } from '../schemas';
import { ItemComponentFactory } from '../factories/ItemComponentFactory';

/**
 * Factory `'item-component'` — renders a generic record wrapper, styled via
 * `record.props.styling` when present, with only the first element of
 * `record.items` rendered as a child. `items` is expected to already be
 * plain, complete {@link RootRecord}s by the time this runs — see
 * `../factories/ItemComponentFactory.ts`'s `produce()` (inherited, unmodified, from
 * `ItemFactory`), which resolves at most one raw item spec into one before
 * this component ever renders, rather than this component doing any further
 * creation/resolution itself. Rendering that already-resolved item is
 * delegated to {@link ItemComponentFactory.renderItemComponent} (a plain,
 * stateless instance method — constructing a fresh `ItemComponentFactory`
 * here just to call it costs nothing) rather than inlined here, so any other
 * `RecordComponent` built on `ItemComponentFactory` can reuse the same
 * single-item render step instead of duplicating it — it throws if that
 * item's own factory has no registered component, the same as it would for
 * any other unrenderable record, not specially handled here.
 *
 * `ItemComponent` is one half of a deliberate name pairing with
 * `ItemComponentFactory` — its own `renderComponent(items)` builds a record
 * and renders it through this exact function, rather than duplicating this
 * render body. This function is the single place `renderItemComponent()`
 * ever actually runs, which is what keeps that pairing from double-rendering
 * or looping — see `ItemComponentFactory.renderComponent()`'s own doc
 * comment for the full reasoning.
 *
 * The sibling of `ContainerComponent` (`ContainerComponent.tsx`) — same
 * generic, purpose-free wrapper shape, differing only in rendering just the
 * first element of `items` (this one) rather than every element.
 */
export const ItemComponent: RecordPropsComponent = (record) => (
  <div data-id={record.id} data-factory="item-component" style={toCss(propsOf(styledProps, record).styling)}>
    {new ItemComponentFactory(record).renderItemComponent(record.items as RootRecord[])}
  </div>
);
