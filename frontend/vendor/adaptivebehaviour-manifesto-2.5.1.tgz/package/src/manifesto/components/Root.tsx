import type { RecordComponent } from '../../create';

/** Factory `'root'` — renders a record's top-level container. */
export const Root: RecordComponent = ({ record }) => <div data-id={record.id} data-factory="root" />;
