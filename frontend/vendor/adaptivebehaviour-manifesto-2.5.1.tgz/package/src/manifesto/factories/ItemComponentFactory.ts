import { createElement, type ReactElement } from 'react';
import type { RootRecord } from '../../Root';
import { buildComponent } from '../../create';
import { ItemFactory } from '../../ItemFactory';
import { ItemComponent } from '../components/ItemComponent';

/**
 * Factory `'item-component'` — resolves an `items` array down to at most one
 * element (see {@link ItemFactory}), wrapped in the base `item-component`
 * factory's own generic `<div>` (see `components/ItemComponent.tsx`).
 * Registered in `instanceRegistry` (see `index.ts`), replacing the generic
 * {@link Factory} default `'item-component'` previously used.
 *
 * The item-shaped sibling of {@link ContainerComponentFactory}/
 * `ContainerComponent` — both are the same generic, purpose-free wrapper,
 * differing only in how much of `items` gets rendered: `ContainerComponent`
 * renders every element, `ItemComponent` renders only the first (see
 * `ItemComponent.tsx`'s own doc comment). Everything else about the pairing
 * — the `renderComponent()` laziness that keeps the two ways of reaching a
 * rendered `'item-component'` from double-rendering or looping — is
 * identical between the two; see
 * `ContainerComponentFactory.renderComponent()`'s own doc comment for the
 * full reasoning, which applies here unchanged.
 *
 * A thin subclass of {@link ItemFactory} — `'item-component'` has no
 * declared defaults of its own and no record-assembly needs beyond
 * resolving at most one `items` element, so `ItemFactory`'s own `produce()`
 * covers everything this factory's own record production needs (including
 * why it's unconditionally `async` — `createAsync('item-component', ...)`,
 * never a plain `create()` — and the "extra items beyond items[0] are
 * dropped, with a warning" behavior; see `ItemFactory.ts`'s own doc comment
 * for both).
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('item-component', {
 *   items: ['text:Hello'],
 * });
 * // <div data-factory="item-component"><p>Hello</p></div>
 * ```
 */
export class ItemComponentFactory extends ItemFactory {
  /**
   * Renders a container's already-resolved item — at most one, per
   * `ItemFactory.produce()`'s own resolution — as a React element. The
   * item-shaped counterpart of {@link ContainerComponentFactory.renderItemComponents}:
   * that one maps every element of `items` to its own keyed `Fragment`, this
   * one only ever renders `items[0]` and needs no key (a lone child has
   * nothing to be reconciled against).
   *
   * @param items - Already-resolved item records — the shape
   *   `ItemFactory.produce()` (inherited, unmodified) produces: zero or one
   *   element, never more.
   * @returns The rendered first item, or `null` if `items` is empty.
   */
  renderItemComponent(items: RootRecord[]): ReactElement | null {
    const item = items[0];
    return item ? buildComponent(item) : null;
  }

  /**
   * Renders `ItemComponent` (`components/ItemComponent.tsx`) from this
   * factory's own resolved record plus the given, already-resolved `items`
   * — the `ItemComponentFactory` side of this class's pairing with
   * `ItemComponent`, exactly mirroring
   * {@link ContainerComponentFactory.renderComponent}: it assembles a
   * complete record and hands it to `ItemComponent` via `createElement()`
   * rather than calling `renderItemComponent()` itself, so rendering stays
   * lazy and happens exactly once, in `ItemComponent`'s own body, regardless
   * of which of the two paths (`factory.renderComponent(items)` or calling
   * `ItemComponent(record)` directly) a caller takes.
   *
   * @param items - Already-resolved item records, same as
   *   {@link renderItemComponent}'s own parameter.
   */
  renderComponent(items: RootRecord[]): ReactElement {
    return createElement(ItemComponent, { ...this.record(), items });
  }
}
