import {
  createRegistry, defineCollection,
  type Collection, type CollectionDefinition, type Registry,
} from './registry';
import type { RegistryTarget } from './create';
import { manifesto } from './manifesto/index';

export type { Collection } from './registry';

// The default registry: the base `manifesto` collection, plus whatever application
// code adds through registerCollection(). `scenes-records`, `ui`, `data` and an
// application's own collections are separate packages that depend on this one, so
// they are composed by the application (see a shell's src/registry.ts, using
// registry.ts's createRegistry()) rather than listed here. This file only keeps
// the one-line call sites (`getCollection()`, `create()`, `registerCollection()`)
// working.
const collections: CollectionDefinition[] = [manifesto];

let cached: { key: string; registry: Registry } | undefined;

function defaultRegistry(): Registry {
  const key = collections.map((c) => c.id).join(',');
  if (!cached || cached.key !== key) {
    cached = { key, registry: createRegistry(collections) };
  }
  return cached.registry;
}

/**
 * Add a collection to the default registry, under a name callers can later use
 * to resolve that specific collection's own scope via `getCollection(id)`.
 * Idempotent by `id`. A collection added this way may override any earlier
 * one's ids without a collision warning (it declares `overrides: '*'`); use
 * `defineCollection()` + `createRegistry()` to declare overrides precisely.
 */
export function registerCollection(id: string, register: (target: RegistryTarget) => void): void {
  if (!collections.some((entry) => entry.id === id)) {
    collections.push(defineCollection({ id, overrides: '*', register }));
  }
}

/**
 * The merged view across the default registry's collections, or — with a
 * `collectionId` — one collection's own scope, bypassing whatever overrides it
 * in the merged view. See {@link Registry.getCollection}. Each call returns a
 * `Collection` with fresh inheritance caches, so call it sparingly and reuse the
 * result when creating several related objects. Call it lazily (inside a
 * function or component body), never at the top level of a collection's module.
 *
 * @throws If `collectionId` is given but no collection has that id.
 */
export function getCollection(collectionId?: string): Collection {
  return defaultRegistry().getCollection(collectionId);
}

/**
 * Top-level convenience wrappers around {@link getCollection}'s merged
 * (no-`collectionId`) view — for the common case where a caller just wants
 * to create something without calling `getCollection()` itself first. Each
 * one takes exactly the arguments its `Collection` counterpart of the same
 * name does (see {@link Collection}), and returns exactly what that
 * counterpart returns.
 *
 * Each call here calls `getCollection()` fresh, so — unlike a `Collection`
 * obtained once and reused — consecutive calls do not share inheritance
 * caches with each other. Prefer calling `getCollection()` yourself and
 * reusing the returned `Collection` when creating several related objects
 * in the same place; reach for these instead for one-off creations, or
 * anywhere the extra `getCollection()` call would just be ceremony.
 */

/** Convenience wrapper for `getCollection().create(...)` — see {@link Collection.create}. */
export function create(
  arg: Parameters<Collection['create']>[0],
  options?: Parameters<Collection['create']>[1]
): ReturnType<Collection['create']> {
  return getCollection().create(arg, options);
}

/** Convenience wrapper for `getCollection().createAsync(...)` — see {@link Collection.createAsync}. */
export function createAsync(
  arg: Parameters<Collection['createAsync']>[0],
  options?: Parameters<Collection['createAsync']>[1]
): ReturnType<Collection['createAsync']> {
  return getCollection().createAsync(arg, options);
}

/** Convenience wrapper for `getCollection().createInstance(...)` — see {@link Collection.createInstance}. */
export function createInstance(
  arg: Parameters<Collection['createInstance']>[0],
  options?: Parameters<Collection['createInstance']>[1]
): ReturnType<Collection['createInstance']> {
  return getCollection().createInstance(arg, options);
}

/** Convenience wrapper for `getCollection().createRecord(...)` — see {@link Collection.createRecord}. */
export function createRecord(
  arg: Parameters<Collection['createRecord']>[0],
  options?: Parameters<Collection['createRecord']>[1]
): ReturnType<Collection['createRecord']> {
  return getCollection().createRecord(arg, options);
}

/** Convenience wrapper for `getCollection().createComponent(...)` — see {@link Collection.createComponent}. */
export function createComponent(
  arg: Parameters<Collection['createComponent']>[0],
  options?: Parameters<Collection['createComponent']>[1]
): ReturnType<Collection['createComponent']> {
  return getCollection().createComponent(arg, options);
}

/** Convenience wrapper for `getCollection().createOperation(...)` — see {@link Collection.createOperation}. */
export function createOperation(
  arg: Parameters<Collection['createOperation']>[0],
  args?: Parameters<Collection['createOperation']>[1]
): ReturnType<Collection['createOperation']> {
  return getCollection().createOperation(arg, args);
}

/** Convenience wrapper for `getCollection().renderComponent(...)` — see {@link Collection.renderComponent}. */
export function renderComponent(
  record: Parameters<Collection['renderComponent']>[0]
): ReturnType<Collection['renderComponent']> {
  return getCollection().renderComponent(record);
}
