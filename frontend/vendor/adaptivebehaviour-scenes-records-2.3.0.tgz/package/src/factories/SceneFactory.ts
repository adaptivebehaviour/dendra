import { createElement, type ReactElement } from 'react';
import type { RootRecord } from '@adaptivebehaviour/manifesto/src/Root';
import { ContainerComponentFactory } from '@adaptivebehaviour/manifesto/src/manifesto/factories/ContainerComponentFactory';
import { Scene } from '../components/Scene';

/**
 * Factory `'scene'` — resolves each element of a passed `items` array into
 * its own component, wrapped in the base `scene` factory's own named state
 * slot (see `components/Scene.tsx`). Registered in `instanceRegistry` (see
 * `index.ts`), replacing the generic {@link Factory} default `'scene'`
 * previously used.
 *
 * Extends {@link ContainerComponentFactory}, exactly like `StageFactory` —
 * see its own doc comment for the full rationale, which applies here
 * unchanged: `produce()` inherited unmodified; `renderComponent()`
 * overridden only to point at `Scene` instead of `ContainerComponent`, now
 * that `Scene` has the same `RecordComponent` shape as `ContainerComponent`
 * (reads `record.items` itself, rather than taking `children` as a separate
 * prop) — so this stays lazy, the same as `ContainerComponentFactory`'s own
 * `renderComponent()`.
 *
 * @example
 * ```ts
 * const collection = getCollection();
 * const element = await collection.createAsync('scene', {
 *   id: 'anchor',
 *   items: ['proportional-image:crm:anchor'],
 * });
 * // <div data-id="anchor" data-factory="scene">...</div>
 * ```
 */
export class SceneFactory extends ContainerComponentFactory {
  renderComponent(items: RootRecord[]): ReactElement {
    return createElement(Scene, { ...this.record(), items });
  }
}
