import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

/** What the application remembers between sessions. */
export interface SettingsData {
  /** The workspace that was open when the application last changed workspace. */
  lastWorkspace?: string;
  /** The workspace location path: where new workspaces are created and where the open-workspace picker starts. */
  workspaceLocation?: string;
}

/** The part of `Settings` the workspace manager uses. */
export interface SettingsStore {
  load(): Promise<SettingsData>;
  save(changes: SettingsData): Promise<void>;
}

const text = (value: unknown): string | undefined => (typeof value === 'string' && value !== '' ? value : undefined);

/**
 * The application's settings, kept in one JSON file (in the application's user-data folder). The file is created by the
 * first change. A missing or unreadable file is the same as no settings, and unknown keys are dropped.
 */
export class Settings implements SettingsStore {
  constructor(private readonly file: string) {}

  async load(): Promise<SettingsData> {
    try {
      const data: unknown = JSON.parse(await readFile(this.file, 'utf8'));
      if (typeof data !== 'object' || data === null) return {};
      const { lastWorkspace, workspaceLocation } = data as Record<string, unknown>;
      return { lastWorkspace: text(lastWorkspace), workspaceLocation: text(workspaceLocation) };
    } catch {
      return {};
    }
  }

  /** Merges `changes` into the settings and writes the file (beside it, then renamed over it, so a crash never leaves half a file). */
  async save(changes: SettingsData): Promise<void> {
    const merged = { ...(await this.load()), ...changes };
    await mkdir(dirname(this.file), { recursive: true });
    const temporary = `${this.file}.${process.pid}.tmp`;
    await writeFile(temporary, `${JSON.stringify(merged, null, 2)}\n`, 'utf8');
    await rename(temporary, this.file);
  }
}
