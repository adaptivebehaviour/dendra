import { mkdir, stat } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { DesktopError } from '../ipc/errors';
import { workspaceNameProblem } from '../workspace/names';
import type { SettingsData, SettingsStore } from './settings';

export interface WorkspaceInfo {
  name: string;
  path: string;
}

export interface WorkspaceDeps {
  /** The system folder applications use by default (Documents on Windows): where workspaces go until the user chooses elsewhere. */
  defaultLocation: string;
  /** Shows the folder picker, opened at `defaultPath`. `null` if the user cancels. */
  pickFolder(options: { title: string; defaultPath: string }): Promise<string | null>;
  /** What is remembered between sessions: the last workspace and the workspace location path. Without it nothing is remembered. */
  settings?: SettingsStore;
}

async function isFolder(path: string): Promise<boolean> {
  try {
    return (await stat(path)).isDirectory();
  } catch {
    return false;
  }
}

/**
 * The open workspace and the ways of changing it.
 *
 * The *workspace location path* is the folder that workspaces are created in, and the folder the picker opens at when
 * a workspace is opened. It starts as the system default and becomes the location of each workspace that is created.
 * The workspace path is the location path plus the workspace's name.
 *
 * The renderer never supplies a folder: it asks for one to be picked, the main process remembers the choice, and
 * `create` uses it. `chosen` is that choice until the workspace is created; abandoning the dialog discards it.
 */
export class WorkspaceManager {
  private locationPath: string;
  private chosen: string | null = null;
  private current: WorkspaceInfo | null = null;

  constructor(private readonly deps: WorkspaceDeps) {
    this.locationPath = deps.defaultLocation;
  }

  /** The open workspace, if any. */
  get workspace(): WorkspaceInfo | null {
    return this.current;
  }

  /** The workspace location path. */
  get location(): string {
    return this.locationPath;
  }

  /**
   * Called once at start-up: takes the workspace location path from the settings and opens the workspace that was open
   * last time. A remembered folder that no longer exists is ignored (the location falls back to the system default,
   * and no workspace is opened).
   */
  async restore(): Promise<void> {
    const { workspaceLocation, lastWorkspace }: SettingsData = (await this.deps.settings?.load().catch(() => undefined)) ?? {};
    if (workspaceLocation && (await isFolder(workspaceLocation))) this.locationPath = workspaceLocation;
    if (lastWorkspace && (await isFolder(lastWorkspace))) this.current = { name: basename(lastWorkspace), path: lastWorkspace };
  }

  /** Starts the "new workspace" dialog: forgets any folder chosen earlier and returns the location it starts with. */
  beginNew(): { location: string } {
    this.chosen = null;
    return { location: this.locationPath };
  }

  /** Shows the folder picker for the new workspace's location. `null` if cancelled (the location is unchanged). */
  async chooseLocation(): Promise<{ location: string } | null> {
    const picked = await this.deps.pickFolder({ title: 'Choose where to create the workspace', defaultPath: this.chosen ?? this.locationPath });
    if (picked === null) return null;
    this.chosen = picked;
    return { location: picked };
  }

  /** Creates the folder `<location>/<name>`, makes its location the workspace location path, and opens it as the workspace. */
  async create(name: string): Promise<WorkspaceInfo> {
    const problem = workspaceNameProblem(name);
    if (problem) throw new DesktopError('invalid_name', problem);
    const location = this.chosen ?? this.locationPath;
    const path = join(location, name);
    try {
      await mkdir(path);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'EEXIST') {
        throw new DesktopError('exists', `A folder named "${name}" already exists in "${location}".`);
      }
      throw new DesktopError('create_failed', `The workspace could not be created: ${error instanceof Error ? error.message : String(error)}`);
    }
    this.locationPath = location;
    this.chosen = null;
    this.current = { name, path };
    await this.remember({ lastWorkspace: path, workspaceLocation: location });
    return this.current;
  }

  /** Shows the folder picker, opened at the workspace location path, and opens the chosen folder as the workspace. `null` if cancelled. */
  async open(): Promise<WorkspaceInfo | null> {
    const picked = await this.deps.pickFolder({ title: 'Open a workspace', defaultPath: this.locationPath });
    if (picked === null) return null;
    this.current = { name: basename(picked), path: picked };
    await this.remember({ lastWorkspace: picked });
    return this.current;
  }

  /** A setting that cannot be saved is not worth failing the user's action for; it is simply not remembered. */
  private async remember(changes: SettingsData): Promise<void> {
    await this.deps.settings?.save(changes).catch(() => undefined);
  }
}
