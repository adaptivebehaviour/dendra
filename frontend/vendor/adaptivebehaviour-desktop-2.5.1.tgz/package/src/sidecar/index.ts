export { SidecarError, type SidecarErrorCode } from './errors';
export { SidecarManager, assertSidecarRequest, type SidecarLaunch, type SidecarOptions, type SidecarState, type SidecarStatus } from './manager';
