import { contract, type ChannelInput, type ChannelName, type ChannelOutput, type IpcResult } from './contract';
import { toErrorShape } from './errors';

/** The part of Electron's `ipcMain` this module needs, so it can be tested without Electron. */
export interface IpcMainLike {
  handle(channel: string, listener: (event: IpcEventLike, payload: unknown) => unknown): void;
  removeHandler(channel: string): void;
}

/** The part of Electron's `IpcMainInvokeEvent` this module needs. */
export interface IpcEventLike {
  senderFrame?: { url: string } | null;
}

/** One handler per channel in the contract: the compiler fails if a channel has none. */
export type Handlers = {
  [N in ChannelName]: (input: ChannelInput<N>, event: IpcEventLike) => Promise<ChannelOutput<N>> | ChannelOutput<N>;
};

export interface RegisterOptions {
  /** True when a message came from a frame the app itself loaded. Messages from anywhere else are refused. */
  isTrustedSender: (event: IpcEventLike) => boolean;
  /** Called with the original error whenever a handler throws, before it is reduced to the renderer-safe shape. */
  onError?: (channel: string, error: unknown) => void;
}

/**
 * Registers every channel of the contract on `ipcMain`. For each message: check the sender, validate the payload with
 * the channel's Zod schema, run the handler, and return a plain `IpcResult`. Handlers never see unvalidated input.
 * Returns a function that removes every handler again.
 */
export function registerHandlers(ipc: IpcMainLike, handlers: Handlers, options: RegisterOptions): () => void {
  const names = Object.keys(contract) as ChannelName[];
  for (const name of names) {
    ipc.handle(name, async (event, payload): Promise<IpcResult<unknown>> => {
      try {
        if (!options.isTrustedSender(event)) {
          return { ok: false, error: { code: 'forbidden', message: 'Message refused: untrusted sender' } };
        }
        const input = contract[name].input.parse(payload);
        const handler = handlers[name] as (input: unknown, event: IpcEventLike) => unknown;
        return { ok: true, value: await handler(input, event) };
      } catch (error) {
        options.onError?.(name, error);
        return { ok: false, error: toErrorShape(error) };
      }
    });
  }
  return () => names.forEach((name) => ipc.removeHandler(name));
}
