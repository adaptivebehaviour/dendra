'use client';

import type { RecordComponent } from '@adaptivebehaviour/manifesto/src/create';
import { useDesktop } from '../api';

/** Factory `'backend-status'` — the state of the optional Python backend; renders nothing when the application has none. */
export const BackendStatus: RecordComponent = ({ record }) => {
  const { backend } = useDesktop();
  if (backend.state === 'absent') return null;
  const className = typeof record.props.className === 'string' ? record.props.className : 'mt-2 text-sm text-slate-600';
  return (
    <p className={className} data-testid="backend" data-state={backend.state} data-id={record.id}>
      Python backend: {backend.state}
      {backend.reason ? ` (${backend.reason})` : ''}
    </p>
  );
};
