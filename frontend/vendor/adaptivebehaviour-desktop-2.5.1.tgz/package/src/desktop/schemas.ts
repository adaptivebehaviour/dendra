import { z } from 'zod';

// Props schemas for the desktop collection's factories (checked as records are built and when records.json loads).
// `z.looseObject`: a record may carry props a schema does not name.

/** `backend-status`: purely presentational, optionally given a class name. */
export const desktopViewProps = z.looseObject({
  className: z.string().optional(),
}).meta({ id: 'DesktopViewProps' });
