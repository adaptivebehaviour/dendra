import type { RegistryTarget } from '@adaptivebehaviour/manifesto/src/create';
import { defineCollection } from '@adaptivebehaviour/manifesto/src/registry';
import { defineFactory, validateRecordsJson } from '@adaptivebehaviour/manifesto/src/schema';
import { BackendStatus } from './components/BackendStatus';
import { desktopViewProps } from './schemas';
import records from './records.json' with { type: 'json' };

/**
 * Registers the desktop collection into the {@link RegistryTarget} it is handed:
 *  - `backend-status` — a component that reads the state of the optional Python backend from a `DesktopProvider`;
 *  - its `records.json` defaults.
 */
export function register(target: RegistryTarget): void {
  defineFactory({ type: 'backend-status', props: desktopViewProps, component: BackendStatus }).register(target);
  for (const record of validateRecordsJson('desktop/records.json', records)) {
    target.recordRegistry.set(record.id as string, record);
  }
}

/** This collection's declaration, for composing into a registry (see an application's `registry.ts`). */
export const desktop = defineCollection({ id: 'desktop', dependsOn: ['manifesto'], register });

export { DesktopProvider, describeError, useDesktop } from './api';
export type { BackendStatus as BackendStatusValue, Desktop } from './api';
