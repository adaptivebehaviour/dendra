import type { ServiceDeclaration } from './declaration';

export interface CredentialStatus {
  available: boolean;
  source: 'environment' | 'none';
  /** The variable to set, when a credential is declared but absent. */
  variable?: string;
}

/**
 * Where credentials come from. Version 1 has one implementation, `EnvironmentCredentials`. Moving to OS-protected
 * storage (Electron `safeStorage`) before distribution means adding a second provider behind this interface and
 * trying it first; no caller changes (decision D8).
 */
export interface CredentialProvider {
  get(service: ServiceDeclaration): string | undefined;
  status(service: ServiceDeclaration): CredentialStatus;
}

/** Reads the environment variable named by each service's `credential.env`, from the real process environment. */
export class EnvironmentCredentials implements CredentialProvider {
  private readonly env: NodeJS.ProcessEnv;

  constructor(env: NodeJS.ProcessEnv = process.env) {
    this.env = env;
  }

  get(service: ServiceDeclaration): string | undefined {
    if (!service.credential) return undefined;
    const value = this.env[service.credential.env];
    return value && value.length > 0 ? value : undefined;
  }

  status(service: ServiceDeclaration): CredentialStatus {
    if (!service.credential) return { available: true, source: 'none' };
    const available = this.get(service) !== undefined;
    return available
      ? { available: true, source: 'environment', variable: service.credential.env }
      : { available: false, source: 'none', variable: service.credential.env };
  }
}

/** Replaces every occurrence of `secret` in `text`, for logging. */
export function redact(text: string, secret: string | undefined): string {
  return secret ? text.split(secret).join('[redacted]') : text;
}
