import type { z } from 'zod';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

/** One thing an application may do with an external service. Anything not declared cannot be requested. */
export interface ServiceOperation {
  method: HttpMethod;
  /** Path under the service's origin; `{name}` segments are filled from the call's `path` argument (each value is URL-encoded). */
  path: string;
  /** Validates the request body before anything is sent. */
  request?: z.ZodType;
  /** Validates the response body; without it the parsed JSON (or text) is returned as is. */
  response?: z.ZodType;
  timeoutMs?: number;
}

/** How a credential is obtained and attached. The value itself is never part of a declaration. */
export interface CredentialSpec {
  /** Environment variable holding the credential (v1; see D8 in the plan). */
  env: string;
  /** Header to put it in. Default `Authorization`. */
  header?: string;
  /** Text placed before the value. Default `Bearer ` for `Authorization`, empty for any other header. */
  prefix?: string;
}

/**
 * An external service an application is allowed to use, declared once by the application. The set of declared
 * services is the application's network allow-list: it drives the main process's network layer and the CSP.
 */
export interface ServiceDeclaration {
  id: string;
  /** Scheme + host (+ port) only, e.g. `https://api.anthropic.com`. */
  origin: string;
  /** Static headers sent with every request (never credentials). */
  headers?: Record<string, string>;
  credential?: CredentialSpec;
  /** Permit a loopback/private-network target. Off by default; only tests and genuinely local services set it. */
  allowPrivateNetwork?: boolean;
  operations: Record<string, ServiceOperation>;
  /** Extra origins from which the renderer may load passive content (images, media) for this service. Added to the CSP only. */
  contentOrigins?: string[];
}

export interface CallArgs {
  path?: Record<string, string>;
  query?: Record<string, string | number | boolean>;
  body?: unknown;
}
