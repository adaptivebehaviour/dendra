import type { ServiceDeclaration } from './declaration';

export interface CspOptions {
  /** Extra origins the renderer may load images/media from, beyond the services' own `contentOrigins`. */
  contentOrigins?: string[];
  /** Development only: allow the Vite dev server's websocket and inline styles. */
  dev?: { origin: string };
}

/**
 * Builds the Content-Security-Policy for the renderer from the application's declared services. The policy is strict
 * by default: scripts and styles come only from the app itself, `connect-src` is `'self'` (external calls go through
 * the main process, not the renderer), and the only outside origins are the declared passive-content origins
 * (typically `img-src` for Sanity-hosted images).
 */
export function buildCsp(services: ServiceDeclaration[], options: CspOptions = {}): string {
  const content = [...new Set([...services.flatMap((s) => s.contentOrigins ?? []), ...(options.contentOrigins ?? [])])].sort();
  for (const origin of content) {
    if (new URL(origin).origin !== origin) throw new Error(`CSP content origin must be scheme + host only: ${origin}`);
  }
  const self = ["'self'", 'app:'];
  const dev = options.dev;
  const directives: Record<string, string[]> = {
    'default-src': self,
    'script-src': dev ? [...self, "'unsafe-inline'"] : self,
    'style-src': dev ? [...self, "'unsafe-inline'"] : self,
    'img-src': [...self, 'data:', 'blob:', ...content],
    'media-src': [...self, 'blob:', ...content],
    'font-src': [...self, 'data:'],
    'connect-src': dev ? [...self, dev.origin, dev.origin.replace(/^http/, 'ws')] : ["'self'"],
    'object-src': ["'none'"],
    'base-uri': ["'none'"],
    'form-action': ["'none'"],
    'frame-ancestors': ["'none'"],
  };
  return Object.entries(directives).map(([name, values]) => `${name} ${values.join(' ')}`).join('; ');
}
