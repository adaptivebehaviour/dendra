import type {
  Destination,
  ErrorLogRecord,
  EventBatch,
  EventRow,
  ResultRecord,
  SessionRecord,
  StoredSession,
} from '@adaptivebehaviour/data/src/destinations/types';
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export const LOCAL_FILE_KIND = 'local-file';
export const DEFAULT_DATA_FILE_NAME = 'data.json';

export interface LocalFileOptions {
  /** The folder the file lives in, chosen by the main process (for example Electron's `userData`); never by the renderer. */
  directory: string;
  /** Defaults to `data.json`. */
  fileName?: string;
}

interface StoredEvent {
  id: string;
  session_id: string;
  user_id: string;
  index: number;
  kind: string | null;
  props: Record<string, unknown>;
  browser_timestamp: string;
}

/** The layout of the file: one table per kind of record, each keyed by id, so storing the same id twice is a no-op. */
interface DataFile {
  version: 1;
  users: Record<string, { id: string }>;
  sessions: Record<string, { id: string; user_id: string; extra_props: Record<string, unknown>; created_at: string }>;
  events: Record<string, StoredEvent>;
  results: Record<string, ResultRecord>;
  errorLogs: Array<ErrorLogRecord & { id: string; created_at: string }>;
}

function emptyFile(): DataFile {
  return { version: 1, users: {}, sessions: {}, events: {}, results: {}, errorLogs: [] };
}

function isDataFile(value: unknown): value is DataFile {
  if (typeof value !== 'object' || value === null) return false;
  const file = value as Record<string, unknown>;
  return (
    file['version'] === 1 &&
    ['users', 'sessions', 'events', 'results'].every((table) => typeof file[table] === 'object' && file[table] !== null) &&
    Array.isArray(file['errorLogs'])
  );
}

/**
 * The user's local file system as the data destination (desktop applications only): everything is kept in one `.json` file.
 * The whole file is held in memory and rewritten after each change, atomically (written beside it, then renamed over it), so
 * a crash never leaves a half-written file; changes are applied one at a time, in the order they arrive. An existing file
 * that cannot be read as this layout is an error rather than being overwritten.
 */
export class LocalFileDestination implements Destination {
  readonly kind = LOCAL_FILE_KIND;
  readonly path: string;
  private readonly directory: string;
  private data: DataFile | undefined;
  private queue: Promise<unknown> = Promise.resolve();

  constructor(options: LocalFileOptions) {
    this.directory = options.directory;
    this.path = join(options.directory, options.fileName ?? DEFAULT_DATA_FILE_NAME);
  }

  async start(): Promise<void> {
    await this.exclusive(async () => {
      await this.load();
    });
  }

  async stop(): Promise<void> {
    await this.queue.catch(() => undefined);
  }

  createSession(session: SessionRecord): Promise<StoredSession> {
    return this.change((data, changed) => {
      const sessionId = session.id ?? randomUUID();
      const userId = session.user_id ?? randomUUID();
      // A repeat of the same session (a retried request) returns what is stored rather than creating another.
      let stored = data.sessions[sessionId];
      if (!stored) {
        data.users[userId] ??= { id: userId };
        stored = data.sessions[sessionId] = {
          id: sessionId,
          user_id: userId,
          extra_props: session.extra_props ?? {},
          created_at: new Date().toISOString(),
        };
        changed();
      }
      return { user_id: stored.user_id, session_id: stored.id };
    });
  }

  async writeEvents(batch: EventBatch): Promise<void> {
    await this.change((data, changed) => {
      for (const event of batch.events) {
        // Each event id is stored once: a retried batch changes nothing.
        if (data.events[event.id]) continue;
        data.events[event.id] = {
          id: event.id,
          session_id: batch.session_id,
          user_id: batch.user_id,
          index: event.index,
          kind: event.kind ?? null,
          props: event.props ?? {},
          browser_timestamp: event.browser_timestamp,
        };
        changed();
      }
    });
  }

  async writeResult(record: ResultRecord): Promise<void> {
    await this.change((data, changed) => {
      data.results[record.id] = record;
      changed();
    });
  }

  async writeErrorLog(report: ErrorLogRecord): Promise<void> {
    await this.change((data, changed) => {
      data.errorLogs.push({ ...report, id: randomUUID(), created_at: new Date().toISOString() });
      changed();
    });
  }

  readEvents(sessionId: string): Promise<EventRow[]> {
    return this.exclusive(async () => {
      const data = await this.load();
      return Object.values(data.events)
        .filter((event) => event.session_id === sessionId)
        .sort((a, b) => a.index - b.index)
        // A missing kind reads back as 'event', the same default the Supabase destination applies.
        .map((event) => ({ kind: event.kind ?? 'event', props: event.props }));
    });
  }

  /** Runs `body` after every earlier change has finished, and keeps the chain going even if it throws. */
  private exclusive<T>(body: () => Promise<T>): Promise<T> {
    const result = this.queue.then(body, body);
    this.queue = result.catch(() => undefined);
    return result;
  }

  /** Applies `mutate` to the data and writes the file, unless `mutate` never called `changed()` (a repeat of something stored). */
  private change<T = void>(mutate: (data: DataFile, changed: () => void) => T): Promise<T> {
    return this.exclusive(async () => {
      const data = await this.load();
      let dirty = false;
      const result = mutate(data, () => {
        dirty = true;
      });
      if (dirty) await this.save(data);
      return result;
    });
  }

  private async load(): Promise<DataFile> {
    if (this.data) return this.data;
    let text: string | undefined;
    try {
      text = await readFile(this.path, 'utf8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    }
    if (text === undefined) {
      this.data = emptyFile();
      return this.data;
    }
    const parsed: unknown = JSON.parse(text);
    if (!isDataFile(parsed)) throw new Error(`${this.path} is not a data file this application can read; it was left unchanged.`);
    this.data = parsed;
    return this.data;
  }

  private async save(data: DataFile): Promise<void> {
    await mkdir(this.directory, { recursive: true });
    const temporary = `${this.path}.${process.pid}.tmp`;
    await writeFile(temporary, JSON.stringify(data, null, 2), 'utf8');
    await rename(temporary, this.path);
  }
}
