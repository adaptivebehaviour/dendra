'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

import { getBufferedCount, recordEvent as recordEventInternal } from './eventBuffer';
import { ensureSession, type SessionPropsConfig } from './session';

export interface UseEventBufferResult {
  /** Records an event to the local buffer; never blocks on the network. */
  recordEvent: (kind?: string, props?: Record<string, unknown>) => void;
  /** True once the session is established and the buffer is ready to record events. */
  ready: boolean;
  /** Number of events currently buffered and not yet acknowledged by the server. */
  pendingCount: number;
  /** The session id the data destination stored (the one this page minted, unless the
   *  destination assigns its own), once `ready` — `undefined` until then. */
  sessionId?: string;
  /** The user id the data destination stored (the `id` query parameter's value, or a fresh
   *  one this page minted when that was absent), once `ready` — `undefined` until then. */
  userId?: string;
}

const PENDING_COUNT_POLL_MS = 1_000;

/**
 * Game components call this to record an event and, if the UI wants a "saving…" indicator,
 * to read buffer/flush status (implementation.md Section 4). `appId`/`sessionPropsConfig`
 * are passed straight through to `ensureSession()` — see that function's own doc comment
 * for why one's required and the other's merged over `./records.json`'s defaults; only the
 * first call within a page load actually matters, the same way `ensureSession()` itself is
 * idempotent.
 */
export function useEventBuffer(
  appId: string,
  sessionPropsConfig?: Partial<SessionPropsConfig>
): UseEventBufferResult {
  const [ready, setReady] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [sessionInfo, setSessionInfo] = useState<{ sessionId: string; userId: string } | undefined>(undefined);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    void ensureSession(appId, sessionPropsConfig).then((info) => {
      if (mountedRef.current) {
        setSessionInfo(info);
        setReady(true);
      }
    });
    return () => {
      mountedRef.current = false;
    };
    // Neither `appId` nor `sessionPropsConfig` is a dependency — `ensureSession()` is
    // only ever meaningfully called once per page load (its own doc comment), so this
    // effect only needs to run once too, on mount, with whatever the caller passed that
    // first time.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!ready) return undefined;
    const interval = setInterval(() => {
      void getBufferedCount().then((count) => {
        if (mountedRef.current) setPendingCount(count);
      });
    }, PENDING_COUNT_POLL_MS);
    return () => clearInterval(interval);
  }, [ready]);

  const recordEvent = useCallback((kind?: string, props: Record<string, unknown> = {}) => {
    void recordEventInternal(kind, props);
  }, []);

  return { recordEvent, ready, pendingCount, sessionId: sessionInfo?.sessionId, userId: sessionInfo?.userId };
}
