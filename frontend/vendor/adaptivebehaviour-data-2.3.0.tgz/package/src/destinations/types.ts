import type { components } from '../wire';

/**
 * The canonical record shapes, generated from the Python models (`ab_data.shapes`, via the OpenAPI contract): what a
 * destination receives, whichever language it is written in.
 */
export type SessionRecord = Partial<components['schemas']['SessionRecord']>;
export type StoredSession = components['schemas']['StoredSession'];
export type EventRecord = components['schemas']['EventRecord'];
export type EventBatch = components['schemas']['EventBatch'];
export type EventRow = components['schemas']['EventRow'];
export type ResultRecord = components['schemas']['ResultRecord'];
export type ErrorLogRecord = components['schemas']['ErrorLogRecord'];

/**
 * Everything the data collection needs from wherever the data ends up (the TypeScript twin of `ab_data.destinations.base`,
 * for destinations that run in the Electron main process; destinations that run in the Python backend implement the
 * Python one). An application sends to exactly one destination. Every destination meets the same rules, which the shared
 * contract tests (`tests/destinationContract.ts`) check:
 *
 * - Writing the same event id twice is harmless (events are stored once per id, so a retried batch is safe).
 * - `readEvents()` returns a session's events ordered by their `index`, whatever order they were written in.
 * - `createSession()` accepts the ids the caller minted and returns the ids actually stored. Today those are the same; a
 *   destination that assigns ids itself would return its own, which is why callers use the returned ids.
 * - Events keep their caller-minted ids; a destination never replaces them.
 */
export interface Destination {
  /** The kind this destination is declared as (see `./config`). */
  readonly kind: string;
  /** Called once when the application starts, before any write. */
  start?(): Promise<void>;
  /** Called once when the application stops. */
  stop?(): Promise<void>;
  /** Registers the session's user (if new) and the session itself, and returns the ids actually stored. */
  createSession(session: SessionRecord): Promise<StoredSession>;
  /** Stores a batch of one session's events, idempotently on each event id. */
  writeEvents(batch: EventBatch): Promise<void>;
  /** Stores one result record verbatim. */
  writeResult(record: ResultRecord): Promise<void>;
  /** Stores one error report. */
  writeErrorLog(report: ErrorLogRecord): Promise<void>;
  /**
   * Every event stored under `sessionId`, oldest first by `index`. Resolves `[]` for a session with no events, or an
   * unknown one.
   */
  readEvents(sessionId: string): Promise<EventRow[]>;
}
