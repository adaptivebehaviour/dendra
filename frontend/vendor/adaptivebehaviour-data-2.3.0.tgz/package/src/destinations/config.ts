/**
 * Which destination an application sends its data to: a `kind` plus that kind's own `settings`, as plain data read when the
 * application starts. Something that lets an end user choose a destination later only has to produce one in the same form.
 * Credentials never appear in it: a destination reads them from its environment (or, on the desktop, `safeStorage`).
 */
export interface DestinationConfig {
  kind: string;
  settings?: Record<string, unknown>;
}

/** The two desktop application types: the only ones that may write to the user's local file system. */
export const DESKTOP_APPLICATION_TYPES = ['electron', 'electron-fastapi'] as const;

/**
 * The kinds of destination, and where each may be used. `applicationTypes` omitted means any application type.
 * `supabase` runs in the Python backend (`ab_data.destinations`); `local-file` runs in the Electron main process
 * (`@adaptivebehaviour/desktop`). A new kind is added here, and its implementation next to wherever it runs.
 */
export const DESTINATION_KINDS: Record<string, { applicationTypes?: readonly string[] }> = {
  supabase: {},
  'local-file': { applicationTypes: DESKTOP_APPLICATION_TYPES },
};

/** The destination each application type starts with. */
export const DEFAULT_DESTINATIONS: Record<string, DestinationConfig> = {
  'nextjs-fastapi': { kind: 'supabase' },
  electron: { kind: 'local-file' },
  'electron-fastapi': { kind: 'local-file' },
};

export class DestinationConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DestinationConfigError';
  }
}

export function defaultDestinationConfig(applicationType: string): DestinationConfig {
  const config = DEFAULT_DESTINATIONS[applicationType];
  if (!config) throw new DestinationConfigError(`No default data destination for application type '${applicationType}'.`);
  return config;
}

/** Returns `config` when its kind exists and may be used in `applicationType`; otherwise throws. */
export function resolveDestinationConfig(config: DestinationConfig, applicationType: string): DestinationConfig {
  const kind = DESTINATION_KINDS[config.kind];
  if (!kind) {
    throw new DestinationConfigError(
      `Unknown data destination kind '${config.kind}' (known: ${Object.keys(DESTINATION_KINDS).join(', ')}).`,
    );
  }
  if (kind.applicationTypes && !kind.applicationTypes.includes(applicationType)) {
    throw new DestinationConfigError(
      `The '${config.kind}' data destination is not available in '${applicationType}' applications ` +
        `(only in: ${kind.applicationTypes.join(', ')}).`,
    );
  }
  return config;
}
