/**
 * How the browser gets data out to the application's destination. The IndexedDB buffer (eventBuffer.ts), the session call
 * (session.ts) and error reporting (reportError.ts) all go through the one sender an application installs, so only this
 * seam knows the route: by default the web routes of the FastAPI backend (`httpSender`), and in a desktop application the
 * main process through the IPC contract (`@adaptivebehaviour/desktop`'s `createIpcSender`).
 *
 * Browser-only, like eventBuffer.ts — it never goes through the Operation/Runnable/registry machinery.
 */

import type { components } from './wire';

export type SessionCreateRequest = components['schemas']['SessionCreateRequest'];
export type SessionCreateResponse = components['schemas']['SessionCreateResponse'];
export type EventBatchRequest = components['schemas']['EventBatch'];
export type ErrorReportRequest = components['schemas']['ErrorReportRequest'];

export interface DataSender {
  /** Registers the session; resolves the ids the destination actually stored (the caller's own, unless it assigns its own). */
  createSession(request: SessionCreateRequest): Promise<SessionCreateResponse>;
  /** Sends a batch of events; resolves `true` only once the destination has acknowledged it (the buffer then drops them). */
  sendEvents(batch: EventBatchRequest): Promise<boolean>;
  /**
   * Final send while the page is unloading, where the route supports one. It gives no acknowledgement, so the events stay
   * buffered and a later successful flush removes them (a duplicate in the meantime is harmless: writes are idempotent).
   */
  sendEventsOnUnload?(batch: EventBatchRequest): void;
  /** Best-effort: reports a caught error; must not throw. */
  reportError(report: ErrorReportRequest): Promise<void>;
}

/** The web routes of the application's FastAPI backend (`ab_data.ingestion`, `ab_data.errors`). */
export const httpSender: DataSender = {
  async createSession(request) {
    const response = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
    });
    if (!response.ok) {
      throw new Error(`POST /api/sessions failed: ${response.status} ${response.statusText}`);
    }
    return (await response.json()) as SessionCreateResponse;
  },

  async sendEvents(batch) {
    try {
      const response = await fetch('/api/events/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(batch),
      });
      return response.ok;
    } catch {
      // Network failure: not acknowledged, retried on the next tick.
      return false;
    }
  },

  // sendBeacon is designed to survive the page unloading mid-request (Section 8).
  sendEventsOnUnload(batch) {
    if (typeof navigator === 'undefined' || !navigator.sendBeacon) return;
    navigator.sendBeacon('/api/events/batch', new Blob([JSON.stringify(batch)], { type: 'application/json' }));
  },

  async reportError(report) {
    try {
      await fetch('/api/errors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(report),
      });
    } catch {
      // Best-effort: a failed error report must not itself throw.
    }
  },
};

let sender: DataSender = httpSender;

/** Installs the sender for this page load; call it once at startup, before the first session is created. */
export function setDataSender(next: DataSender): void {
  sender = next;
}

export function getDataSender(): DataSender {
  return sender;
}
