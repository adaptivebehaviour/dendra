/**
 * Establishes a session once per page load (implementation.md Section 4/5): reads a
 * user id from the URL query string if one is present (else mints one), mints the session id,
 * registers both with the application's data destination through its `DataSender`
 * (./sender.ts), and stores the returned user_id/session_id for eventBuffer.ts to stamp onto
 * every event. No non-UUID id from any external service is ever accepted here (Section 11) —
 * the query parameter, when present, must already be a UUID; the destination side validates
 * this and refuses otherwise.
 *
 * The ids are minted here, client-side, but the ids used afterwards are the ones the
 * destination returns: today those are the very same ids, and a destination that assigns its
 * own ids would simply return different ones.
 */

import { getDataSender, type SessionCreateRequest } from './sender';
import defaultSessionPropsConfig from './config.json' with { type: 'json' };
import { initEventBuffer } from './eventBuffer';

export interface SessionInfo {
  userId: string;
  sessionId: string;
}

// Which of the fields `collectSessionProps()` (below) knows how to gather actually get
// included in a session's own `props` — `./records.json` is the `data` collection's own
// defaults (all `false`: collecting nothing beyond `user_id`/`started_at`/`ended_at` is
// the safe, non-identifying-by-default starting point), and a caller (`ensureSession()`'s
// own `configOverride` parameter) can flip any of them on. A page opts in by keeping its
// own `records.json` with a `data` override — see this module's own `ensureSession()` doc
// comment for how that override reaches here.
export interface SessionPropsConfig {
  timezone: boolean;
  userAgent: boolean;
  screen: boolean;
}

let sessionPromise: Promise<SessionInfo> | null = null;

// The URL's own query parameter naming — distinct from `ab_data/ingestion.py`'s
// `SessionCreateRequest.user_id`, the wire field this value is sent under (`createSession()`,
// below); the two names only need to agree at this one boundary, not throughout.
const USER_ID_QUERY_PARAM = 'id';

function readUserIdFromQuery(): string | undefined {
  if (typeof window === 'undefined') return undefined;
  const params = new URLSearchParams(window.location.search);
  return params.get(USER_ID_QUERY_PARAM) ?? undefined;
}

// Every other query-string field (i.e. everything except `id`, above) — a visiting URL's
// own extra fields land as direct siblings of `app_id`/`timezone`/... in the new session's
// own `props` (`createSession()`, below), the same flat, no-wrapper placement
// `collectSessionProps()` (below) already uses for its own fields.
function collectQueryProps(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  const params = new URLSearchParams(window.location.search);
  const props: Record<string, string> = {};
  params.forEach((value, key) => {
    if (key === USER_ID_QUERY_PARAM) return;
    props[key] = value;
  });
  return props;
}

// Gathers exactly the fields `config` flags `true`, each keyed by its own name — no
// `device_info` (or any other) wrapper: every field this returns lands as a direct
// sibling of `user_id`/`started_at`/`ended_at` in a session's own `props`
// (`backend/src/data/db.py`'s own `create_session()`, which merges this object in via
// Postgres's `||` rather than nesting it under a key of its own). `screen` is the one
// field with any structure of its own (`{ width, height }`) rather than a bare scalar —
// still just an ordinary value under its own key, not a wrapper around the *other*
// fields here.
function collectSessionProps(config: SessionPropsConfig): Record<string, unknown> {
  if (typeof window === 'undefined') return {};
  const props: Record<string, unknown> = {};
  if (config.timezone) {
    props.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  if (config.userAgent) {
    props.userAgent = navigator.userAgent;
  }
  if (config.screen) {
    props.screen = { width: window.screen?.width, height: window.screen?.height };
  }
  return props;
}

export async function createSession(appId: string, config: SessionPropsConfig): Promise<SessionInfo> {
  const request: SessionCreateRequest = {
    user_id: readUserIdFromQuery() ?? crypto.randomUUID(),
    session_id: crypto.randomUUID(),
    // `collectQueryProps()` first, so an arbitrary query-string field can never shadow
    // one of this layer's own reserved names below (e.g. a URL crafted with its own
    // `?app_id=...`) — `app_id` is never gated by `SessionPropsConfig` the way
    // `collectSessionProps()`'s own fields are: every session gets one, always, straight
    // from the calling page's own app id, since a session being attributable to which
    // app produced it isn't an opt-in concern the way `timezone`/`userAgent`/`screen` are.
    extra_props: { ...collectQueryProps(), app_id: appId, ...collectSessionProps(config) },
  };
  const stored = await getDataSender().createSession(request);
  return { userId: stored.user_id, sessionId: stored.session_id };
}

/**
 * Idempotent within a single page load: the first call creates the session and
 * initialises the event buffer; subsequent calls return the same in-flight/resolved
 * promise, so components can call this freely without coordinating who "owns" session
 * creation. `appId` (a calling page's own app id) is required — see `createSession()`'s
 * own doc comment for why it's never optional the way `configOverride` (shallow-merged
 * over `./records.json`'s defaults — see `SessionPropsConfig`'s own doc comment) is. Both
 * only matter on the call that actually wins the race to create `sessionPromise`; later
 * callers within the same page load just get the already-resolved session back, either
 * argument ignored.
 */
export function ensureSession(
  appId: string,
  configOverride?: Partial<SessionPropsConfig>
): Promise<SessionInfo> {
  if (!sessionPromise) {
    const config: SessionPropsConfig = { ...defaultSessionPropsConfig, ...configOverride };
    sessionPromise = createSession(appId, config).then((info) => {
      initEventBuffer(info.sessionId, info.userId);
      return info;
    });
  }
  return sessionPromise;
}
