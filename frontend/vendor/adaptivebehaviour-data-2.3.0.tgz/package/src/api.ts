// `base` is passed explicitly rather than read from a module-level default — an embedded
// collection's own base path differs per collection, and a mutable module-level global
// doesn't reliably cross the client/server component module-graph split Next.js App Router
// uses (see `embed-app`'s own step 8 note on why runtime `registerCollection()` calls have
// the same failure mode).
export function apiUrl(base: string, path: string): string {
  const trimmedBase = base.replace(/\/+$/, '');
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `/api${trimmedBase}${normalizedPath}`;
}

export async function callBackend<T = unknown>(base: string, path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(apiUrl(base, path), init);
  if (!response.ok) {
    throw new Error(`Backend request to ${path} failed: ${response.status} ${response.statusText}`);
  }
  return response.json() as Promise<T>;
}
