/**
 * Best-effort report of a caught error through the application's `DataSender` (./sender.ts), which
 * delivers it to the data destination's error log (by default POST /errors, backend/src/errors.py).
 * Not callBackend()/apiUrl() (./api.ts) — those are for an embedded collection's own prefixed
 * routes, while this, like sessions and event batches, goes through the sender.
 *
 * Sibling to `frontend/src/app/lib/reportError.ts` (the app-level version `error.tsx`/
 * `global-error.tsx` use for a whole-page render crash) rather than a reuse of it — this one
 * lives in the shared `psymetri-frontend-lib` package (not the app layer, which a collection
 * component must never import from) and optionally attaches the caller's own pbe
 * `session_id`/`user_id` — see the embedded rfrt collection's `useOptionsSubmit.ts` (its own
 * fatal `/pbe/start`/`/tutorial/start` failure path), its one caller.
 */
import { getDataSender } from './sender';

export interface ErrorReportContext {
  sessionId?: string;
  userId?: string;
  context?: Record<string, unknown>;
  severity?: string;
}

export async function reportError(
  error: { message: string; stack?: string },
  { sessionId, userId, context, severity = 'error' }: ErrorReportContext = {}
): Promise<void> {
  try {
    await getDataSender().reportError({
      message: error.message,
      stack: error.stack,
      severity,
      session_id: sessionId,
      user_id: userId,
      context,
    });
  } catch {
    // Best-effort: a failed error report must not itself throw.
  }
}
