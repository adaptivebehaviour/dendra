'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';

type SceneRegistry = Record<string, Record<string, unknown>>;
type EventHandler = (payload: unknown) => void;
type SetScene<T> = (patch: Partial<T> | ((prev: T) => Partial<T>)) => void;

/**
 * Local scene names a `SceneProvider` forwards to its nearest ancestor
 * provider. Two forms:
 * - `string[]` — each name is auto-prefixed as `${scope}.${name}` at the
 *   parent (e.g. `['score']` with `scope="a"` publishes `a.score`).
 *   Collision-safe by construction, at the cost of consumers needing to know
 *   the exposing scope's id to read the value.
 * - `Record<string, string>` — explicit `localName -> exposedName` mapping,
 *   publishing under a stable, scope-independent name instead of the
 *   auto-prefixed one. Still checked for collisions (see `SceneProvider`'s
 *   own doc comment), since the author is opting out of automatic
 *   uniqueness.
 */
export type SceneExpose = Record<string, string> | string[];

interface SceneContextValue {
  scenes: SceneRegistry;
  patchScene: (name: string, patch: Record<string, unknown>) => void;
  emit: (event: string, payload?: unknown) => void;
  subscribe: (event: string, handler: EventHandler) => () => void;
  /** Lets a nested SceneProvider forward one of its own exposed values up
   *  into this provider's registry. `sourceId` is the exposing scope's own
   *  `scope` id — carried through unchanged across multiple hops (see
   *  `SceneProvider`'s doc comment) so collision detection always attributes
   *  a name to its true origin, not to whichever intermediate scope last
   *  forwarded it. */
  receiveExposed: (sourceId: string, exposedName: string, value: Record<string, unknown>) => void;
}

const SceneContext = createContext<SceneContextValue | null>(null);

function useSceneContext(): SceneContextValue {
  const ctx = useContext(SceneContext);
  if (!ctx) {
    throw new Error('Scene hooks must be used within a <SceneProvider>.');
  }
  return ctx;
}

interface ExposeEntry {
  localName: string;
  exposedName: string;
}

function normalizeExpose(expose: SceneExpose | undefined, scope: string): ExposeEntry[] {
  if (!expose) {
    return [];
  }
  if (Array.isArray(expose)) {
    return expose.map((localName) => ({ localName, exposedName: `${scope}.${localName}` }));
  }
  return Object.entries(expose).map(([localName, exposedName]) => ({ localName, exposedName }));
}

/**
 * Pure infrastructure: a scene registry (published state per scene) and an
 * event bus, scoped to whatever subtree this provider wraps. No business
 * logic lives here — that belongs in the hooks below.
 *
 * Providers may be nested to form a scope tree rather than isolated
 * universes:
 * - **Downward visibility is automatic.** A value registered in an outer
 *   provider is visible to every provider nested inside it (`useSceneState`
 *   resolves against the merge of this provider's own registry over its
 *   parent's), the same way a nested scope naturally inherits from its
 *   enclosing one.
 * - **Upward/lateral visibility is opt-in and per-key**, via `expose` (and
 *   `exposeEvents` for the event bus). A scope's own registrations do not
 *   automatically become visible outside itself — reaching a sibling or
 *   cousin scope through a shared ancestor requires the source scope to
 *   explicitly name that value in `expose`. Anything not listed stays
 *   private to the scope that registered it and its own descendants.
 *
 * `scope` is required whenever `expose` (or `exposeEvents`) is passed — it's
 * both the automatic namespace prefix for the `string[]` form of `expose`,
 * and the id collision errors are reported against.
 */
export function SceneProvider({
  children,
  scope,
  expose,
  exposeEvents,
}: {
  children?: ReactNode;
  scope?: string;
  expose?: SceneExpose;
  exposeEvents?: string[];
}) {
  if ((expose !== undefined || exposeEvents !== undefined) && !scope) {
    throw new Error('SceneProvider: `scope` is required whenever `expose`/`exposeEvents` is provided.');
  }

  const parent = useContext(SceneContext);
  const [scenes, setScenes] = useState<SceneRegistry>({});
  const listenersRef = useRef<Map<string, Set<EventHandler>>>(new Map());

  // Tracks, for collision detection only, which source currently owns each
  // key held in this provider's own `scenes` — 'local' for a Scene mounted
  // directly here (via patchScene), or a descendant scope's own `scope` id
  // for a value received via receiveExposed. Never read for rendering.
  const sourceOfRef = useRef<Map<string, string>>(new Map());

  const patchScene = useCallback((name: string, patch: Record<string, unknown>) => {
    const existingSource = sourceOfRef.current.get(name);
    if (existingSource !== undefined && existingSource !== 'local') {
      throw new Error(
        `SceneProvider: scene "${name}" collides with a value already exposed here by scope "${existingSource}".`
      );
    }
    sourceOfRef.current.set(name, 'local');
    setScenes((prev) => ({
      ...prev,
      [name]: { ...prev[name], ...patch },
    }));
  }, []);

  const receiveExposed = useCallback(
    (sourceId: string, exposedName: string, value: Record<string, unknown>) => {
      const existingSource = sourceOfRef.current.get(exposedName);
      if (existingSource !== undefined && existingSource !== sourceId) {
        throw new Error(
          `SceneProvider: two scopes are exposing the same name "${exposedName}" to the same ` +
            `parent — "${existingSource}" and "${sourceId}". Rename one side's exposed key.`
        );
      }
      sourceOfRef.current.set(exposedName, sourceId);
      setScenes((prev) => {
        // Bail out (same reference back) when nothing actually changed —
        // the forwarding effect below re-runs whenever `parent` changes
        // identity, which this very setState causes one level up; without
        // this guard, an unchanged value would re-trigger itself forever.
        // React skips the re-render entirely when a state updater returns
        // the same reference it was given.
        if (prev[exposedName] === value) {
          return prev;
        }
        return { ...prev, [exposedName]: value };
      });
    },
    []
  );

  const subscribe = useCallback(
    (event: string, handler: EventHandler) => {
      const listeners = listenersRef.current;
      let handlers = listeners.get(event);
      if (!handlers) {
        handlers = new Set<EventHandler>();
        listeners.set(event, handlers);
      }
      const handlerSet = handlers;
      handlerSet.add(handler);

      // Downward visibility for events, mirroring state's automatic
      // inheritance (resolvedScenes below): also subscribe on every
      // ancestor scope's own bus (recursively, since the parent's own
      // subscribe does the same), so this handler still fires when an
      // ancestor emits directly, or when a sibling scope forwards an event
      // up into that ancestor via its own exposeEvents.
      const unsubscribeFromParent = parent?.subscribe(event, handler);

      return () => {
        handlerSet.delete(handler);
        if (handlerSet.size === 0) {
          listeners.delete(event);
        }
        unsubscribeFromParent?.();
      };
    },
    [parent]
  );

  const emit = useCallback(
    (event: string, payload?: unknown) => {
      listenersRef.current.get(event)?.forEach((handler) => handler(payload));
      if (parent && exposeEvents?.includes(event)) {
        parent.emit(event, payload);
      }
    },
    [parent, exposeEvents]
  );

  // Forwards this provider's own exposed local scenes to its parent whenever
  // any of them change. Re-derives the full expose list on every run rather
  // than diffing — simple and correct; see hooks.tsx's own module comment
  // in the implementation plan for the perf follow-up if this ever matters.
  useEffect(() => {
    if (!parent || !scope) {
      return;
    }
    for (const { localName, exposedName } of normalizeExpose(expose, scope)) {
      const value = scenes[localName];
      if (value !== undefined) {
        parent.receiveExposed(scope, exposedName, value);
      }
    }
  }, [parent, scenes, expose, scope]);

  // This provider's own visible surface: its parent's resolved view as the
  // base (nested scopes inherit automatically), with this scope's own local
  // registrations — including anything received via receiveExposed from its
  // own children — layered on top and taking precedence on a name clash.
  const resolvedScenes = useMemo<SceneRegistry>(
    () => (parent ? { ...parent.scenes, ...scenes } : scenes),
    [parent?.scenes, scenes]
  );

  const value = useMemo<SceneContextValue>(
    () => ({ scenes: resolvedScenes, patchScene, emit, subscribe, receiveExposed }),
    [resolvedScenes, patchScene, emit, subscribe, receiveExposed]
  );

  return <SceneContext.Provider value={value}>{children}</SceneContext.Provider>;
}

/**
 * Registers a named scene slot, seeded once with initialState, in the
 * *nearest* provider's own local registry. Returns the scene's live
 * published state (read from that provider's resolved, inheritance-aware
 * view — see `SceneProvider`) and a setter that patches the local
 * registration.
 */
export function useScene<T extends object>(name: string, initialState: T): [T, SetScene<T>] {
  const { scenes, patchScene } = useSceneContext();

  // Captured once: lets the mount effect below stay independent of identity
  // changes to the initialState object literal callers tend to pass inline.
  const initialRef = useRef(initialState);

  // Mirrors `scenes` after every commit (never during render — refs must
  // only be touched in effects/handlers) so setScene can read current state
  // without depending on `scenes` — that keeps setScene's identity stable.
  const scenesRef = useRef(scenes);
  useEffect(() => {
    scenesRef.current = scenes;
  }, [scenes]);

  useEffect(() => {
    patchScene(name, initialRef.current as unknown as Record<string, unknown>);
    // Intentionally mount-only: name/patchScene are stable for this slot's
    // lifetime, and re-running this would stomp on later patches.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setScene = useCallback<SetScene<T>>(
    (patch) => {
      const current = (scenesRef.current[name] as unknown as T | undefined) ?? initialRef.current;
      const partial = typeof patch === 'function' ? patch(current) : patch;
      patchScene(name, partial as unknown as Record<string, unknown>);
    },
    [name, patchScene]
  );

  const state = (scenes[name] as unknown as T | undefined) ?? initialState;

  return [state, setScene];
}

/**
 * Reactively reads a scene's published state from the calling component's
 * nearest provider's resolved (inheritance-aware) view — the scene may have
 * registered in the nearest provider itself, an ancestor provider, or been
 * forwarded up into one via `expose` from an unrelated sibling scope. Does
 * not distinguish between these — `SceneProvider` is what makes that
 * distinction meaningful, this hook just reads whatever is currently
 * visible. Re-renders the caller whenever that name's value changes.
 */
export function useSceneState<T extends object>(name: string, fallback?: T): T | undefined {
  const { scenes } = useSceneContext();
  const value = scenes[name];
  return value === undefined ? fallback : (value as unknown as T);
}

/**
 * Subscribes to a named event for the lifetime of the component, on the
 * calling component's nearest provider. The handler must be captured in a
 * ref so the subscription is created once and does not re-subscribe on
 * every render — callers can pass inline functions safely.
 */
export function useSceneEvent<T = unknown>(event: string, handler: (payload: T) => void): void {
  const { subscribe } = useSceneContext();
  const handlerRef = useRef(handler);

  useEffect(() => {
    handlerRef.current = handler;
  }, [handler]);

  useEffect(() => {
    return subscribe(event, (payload) => handlerRef.current(payload as T));
  }, [event, subscribe]);
}

/**
 * Returns the stable emit function for broadcasting named events on the
 * calling component's nearest provider. If that provider's own
 * `exposeEvents` names the emitted event, it also forwards to the parent
 * provider's own `emit` — continuing on to the grandparent in turn only if
 * *that* provider also lists the event in its own `exposeEvents`, and so on.
 */
export function useEmit(): (event: string, payload?: unknown) => void {
  const { emit } = useSceneContext();
  return emit;
}

// Emitted (via `useEmit()`) by a gated `RfrtGameScene` descendant the moment a
// specific user interaction happens (e.g. `RfrtGameOptions` selecting its first
// option), payload `{ id }` — a `TutorialCard` whose own `props.advanceOn` names
// that same `id` (see TutorialCard.tsx) advances its tutorial step on receiving
// it, instead of waiting for its own "Next" button.
export const TUTORIAL_INTERACT_EVENT = 'tutorial:interact';

export interface AnchorRect {
  top: number;
  left: number;
  right: number;
  bottom: number;
  width: number;
  height: number;
}

function measureAnchor(element: Element): AnchorRect {
  const rect = element.getBoundingClientRect();
  return { top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom, width: rect.width, height: rect.height };
}

// Tracks the live `getBoundingClientRect()` of the element carrying
// `data-id={dataId}` (every rendered item already carries this — see
// `Scene.tsx`/`ContainerComponent.tsx`) so a caller can position a fixed-position
// overlay (e.g. TutorialCard.tsx's own `placement.anchorTo`) relative to it.
// Returns `null` until the target is found (including "not mounted yet" — a
// `MutationObserver` keeps watching rather than requiring callers to coordinate
// mount order) *and* actually laid out — a target that exists but is currently
// `display: none` (e.g. still behind a gate's own `hideWhenInactive`, about to
// be revealed by a state update this hook has no way to wait for) reports an
// all-zero `getBoundingClientRect()`, which `update()` below treats the same as
// "not found yet" rather than a real (0, 0)-sized, (0, 0)-positioned anchor —
// no legitimate anchor is ever actually that, so trusting it would hand a
// caller nonsense coordinates to position against instead of just waiting for
// the same `ResizeObserver` to report the target's real size the moment it's
// actually revealed.
//
// `useLayoutEffect`, not `useEffect` — deliberately: on the very first render
// where a caller starts tracking a new `dataId` (e.g. a tutorial card's own
// anchored placement becoming active), `rect` is still `null` from the
// previous render, so whatever a caller falls back to without one (a centered
// placement) is what actually gets committed to the DOM first. A plain
// `useEffect` only queries and calls `setRect()` *after* the browser has
// already painted that first, wrong frame — visible as a brief flash of the
// centered fallback before the card snaps to its real anchored position.
// `useLayoutEffect` runs synchronously after the DOM update but before the
// browser paints anything, so when the target already exists, `setRect()`
// inside it triggers React's own guaranteed pre-paint re-render, and the
// anchored position is what the user actually sees from the very first frame
// instead.
export function useAnchorRect(dataId: string | undefined): AnchorRect | null {
  const [rect, setRect] = useState<AnchorRect | null>(null);

  useLayoutEffect(() => {
    if (!dataId) {
      setRect(null);
      return;
    }

    let resizeObserver: ResizeObserver | undefined;
    let observedElement: Element | null = null;

    const update = () => {
      if (!observedElement) return;
      const measured = measureAnchor(observedElement);
      const isRendered = measured.width !== 0 || measured.height !== 0 || measured.top !== 0 || measured.left !== 0;
      if (isRendered) setRect(measured);
    };

    const attach = (element: Element) => {
      observedElement = element;
      resizeObserver = new ResizeObserver(update);
      resizeObserver.observe(element);
      update();
    };

    const existing = document.querySelector(`[data-id="${dataId}"]`);
    if (existing) attach(existing);

    const mutationObserver = new MutationObserver(() => {
      if (observedElement) return;
      const found = document.querySelector(`[data-id="${dataId}"]`);
      if (found) attach(found);
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);

    return () => {
      resizeObserver?.disconnect();
      mutationObserver.disconnect();
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update, true);
      setRect(null);
    };
  }, [dataId]);

  return rect;
}
