'use client';

import { useLayoutEffect, useRef, useState, type CSSProperties } from 'react';

const MIN_FONT_SIZE = 8;

interface FitTextProps {
  children: string;
  style: CSSProperties;
  'data-id'?: string;
  'data-factory'?: string;
}

/**
 * Renders `children` in a `<p>` sized by `style`, shrinking its own
 * `font-size` until the full text fits without clipping — measured via a
 * `ResizeObserver` comparing `scrollHeight`/`scrollWidth` (the text's actual
 * rendered size) against `clientHeight`/`clientWidth` (the box's size) at
 * each candidate size, starting from `style`'s own `fontSize` (or the
 * inherited default) and stepping down to `MIN_FONT_SIZE`.
 *
 * `style` must give the box a definite height that doesn't depend on its
 * own content (e.g. `height: '100%'` of a sized ancestor, not `'auto'`) —
 * otherwise clientHeight would itself shift as the search changes
 * font-size/content-height, and the search couldn't converge.
 *
 * Deliberately its own `'use client'` component rather than logic inlined
 * into a `RecordComponent` (e.g. `GameDescription`): `RecordComponent`s are
 * invoked as plain functions (see `buildComponent` in `create.ts`), not
 * instantiated via JSX, so they never get a React Fiber to hang hooks off.
 * Only a component actually reached through JSX — like this one, used as
 * `<FitText>` — does.
 */
export function FitText({ children, style, ...rest }: FitTextProps) {
  const ref = useRef<HTMLParagraphElement>(null);
  const [fontSize, setFontSize] = useState<number>();

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;

    const maxFontSize = parseFloat(getComputedStyle(el).fontSize);
    let frame: number | null = null;

    const fit = () => {
      frame = null;
      let size = maxFontSize;
      el.style.fontSize = `${size}px`;
      while (
        size > MIN_FONT_SIZE &&
        (el.scrollHeight > el.clientHeight || el.scrollWidth > el.clientWidth)
      ) {
        size -= 1;
        el.style.fontSize = `${size}px`;
      }
      setFontSize(size);
    };

    const observer = new ResizeObserver(() => {
      if (frame === null) frame = requestAnimationFrame(fit);
    });
    observer.observe(el);

    return () => {
      observer.disconnect();
      if (frame !== null) cancelAnimationFrame(frame);
    };
  }, [children]);

  return (
    <p
      ref={ref}
      {...rest}
      style={{ ...style, ...(fontSize !== undefined ? { fontSize } : undefined) }}
    >
      {children}
    </p>
  );
}
