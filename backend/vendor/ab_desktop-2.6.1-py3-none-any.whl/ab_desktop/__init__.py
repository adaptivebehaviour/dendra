"""Manifesto desktop support for Python: the sidecar bootstrap."""
