"""The Python sidecar: a FastAPI app that the Electron main process starts, supervises and stops.

The contract with the main process (see `.notes/desktop-application-plan.md`, section 6.2):

* It listens on 127.0.0.1 only, on a port it chooses itself (it binds port 0, so there is no port-picking race).
* When it is ready it prints one line to stdout: ``AB_SIDECAR_READY {"port": N, "pid": P, "version": "x.y.z"}``.
* Every request needs ``Authorization: Bearer <token>``; the token is generated per launch by the main process and
  passed in the environment (``AB_SIDECAR_TOKEN``), never on the command line. Requests whose ``Host`` header is not
  this server's own loopback address are refused (a DNS-rebinding guard). There is no CORS: a browser never calls it.
* It exits when its stdin reaches end-of-file, i.e. when the parent process has gone, even if the parent crashed.
* ``POST /shutdown`` asks it to stop cleanly.
"""

from __future__ import annotations

import hmac
import json
import os
import socket
import sys
import threading
from collections.abc import AsyncIterator, Callable, Sequence
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version as package_version
from typing import Any

from fastapi import APIRouter, FastAPI, Request
from fastapi.responses import JSONResponse

TOKEN_ENV = 'AB_SIDECAR_TOKEN'
READY_PREFIX = 'AB_SIDECAR_READY'


def _sidecar_version() -> str:
    try:
        return package_version('ab-desktop')
    except PackageNotFoundError:
        return '0.0.0'


class _State:
    """What the lifespan and the request guard share: the expected token, the allowed Host values, the server handle."""

    def __init__(self, token: str) -> None:
        self.token = token
        self.hosts: set[str] = set()
        self.server: Any = None


def create_app(
    *,
    token: str,
    title: str = 'Manifesto sidecar',
    routers: Sequence[APIRouter] = (),
    on_ready: Callable[[], None] | None = None,
) -> FastAPI:
    """Build the sidecar app. `routers` are the project's own routes; every route is behind the token check."""
    state = _State(token)

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        if on_ready:
            on_ready()
        yield

    app = FastAPI(title=title, lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.sidecar = state

    @app.middleware('http')
    async def guard(request: Request, call_next: Callable[..., Any]) -> Any:
        # Host check first: it needs no secret and stops DNS rebinding before anything else runs.
        if state.hosts and request.headers.get('host', '') not in state.hosts:
            return JSONResponse({'detail': 'Bad host'}, status_code=400)
        header = request.headers.get('authorization', '')
        supplied = header[7:] if header.lower().startswith('bearer ') else ''
        if not hmac.compare_digest(supplied.encode('utf-8'), state.token.encode('utf-8')):
            return JSONResponse({'detail': 'Unauthorised'}, status_code=401)
        return await call_next(request)

    @app.get('/health')
    def health() -> dict[str, Any]:
        return {'status': 'ok', 'pid': os.getpid(), 'version': _sidecar_version()}

    @app.post('/shutdown')
    def shutdown() -> dict[str, str]:
        if state.server is not None:
            state.server.should_exit = True
        return {'status': 'stopping'}

    for router in routers:
        app.include_router(router)
    return app


def _watch_stdin(stop: Callable[[], None]) -> None:
    """Block until stdin closes (the parent is gone), then stop. Runs in a daemon thread."""
    try:
        while sys.stdin.buffer.read(4096):
            pass
    except (OSError, ValueError):
        pass
    stop()


def serve(
    routers: Sequence[APIRouter] = (),
    *,
    title: str = 'Manifesto sidecar',
    app_factory: Callable[..., FastAPI] = create_app,
) -> None:
    """Run the sidecar until it is told to stop or its parent goes away. Used by the project's `main.py`."""
    import uvicorn

    token = os.environ.get(TOKEN_ENV, '')
    if len(token) < 32:
        sys.exit(f'{TOKEN_ENV} must be set to a random token of at least 32 characters (the Electron app sets it)')

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(('127.0.0.1', 0))
    # Listen now, not when uvicorn starts accepting: a client that connects as soon as it reads the ready line then
    # waits in the backlog instead of being refused.
    listener.listen(128)
    port = listener.getsockname()[1]

    def announce() -> None:
        line = {'port': port, 'pid': os.getpid(), 'version': _sidecar_version()}
        sys.stdout.write(f'{READY_PREFIX} {json.dumps(line)}\n')
        sys.stdout.flush()

    app = app_factory(token=token, title=title, routers=routers, on_ready=announce)
    state: _State = app.state.sidecar
    state.hosts = {f'127.0.0.1:{port}', f'localhost:{port}'}

    config = uvicorn.Config(app, log_level='warning', access_log=False, lifespan='on')
    server = uvicorn.Server(config)
    state.server = server

    def stop() -> None:
        server.should_exit = True

    threading.Thread(target=_watch_stdin, args=(stop,), name='stdin-watchdog', daemon=True).start()
    server.run(sockets=[listener])
    # The watchdog thread may still be blocked reading stdin; leaving it to interpreter shutdown can abort the
    # process with a non-zero status. This is the process's entry point, so exit directly once output is flushed.
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)
