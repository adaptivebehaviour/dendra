from __future__ import annotations

import sys


def warn(message: str) -> None:
    """The single place a "something unexpected happened, but execution
    should continue" signal goes out — e.g. a factory choosing to ignore an
    extra caller-supplied value rather than reject it (see the single-item
    factory kind in `item_factory.py`).

    Deliberately just a thin wrapper around printing to stderr for now —
    nothing about *how* a warning is surfaced (log level, deduping,
    telemetry) is decided yet. Every caller goes through this one function
    so that decision can be made once, later, without touching every call
    site that currently wants to warn. Mirrors the JS port's `warn.ts`.
    """
    print(f'Warning: {message}', file=sys.stderr)
