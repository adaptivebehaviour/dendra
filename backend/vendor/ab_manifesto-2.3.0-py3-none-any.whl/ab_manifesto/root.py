import re as _re
import uuid
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, NotRequired, TypedDict


class Instance(ABC):
    """The contract every object built via instance_registry must satisfy: a
    record() method returning its plain-data record form. Root implements
    this; a custom instance type registered into instance_registry must too.
    """

    @abstractmethod
    def record(self) -> 'RootRecord':
        ...


@dataclass
class Root(Instance):
    """Base object in the kind/factory hierarchy.

    `kind` defaults to `'root'` — every object is a direct child of root
    unless a caller positions it elsewhere in the hierarchy. `'root'` is
    always a resolvable ancestor (pre-registered in
    `instances_by_id`/`record_registry`), unlike the old `'object'` default
    this replaced, which was never itself a registered id. `'object'` is
    reserved for `root_record`/`root_instance` themselves — the only object
    allowed to have it.
    """

    # `kind` is never set by which factory built an object, and never carries
    # "where do my default props come from" information — that's a separate
    # concern, resolved by Factory.produce() (see factory.py) by merging a
    # factory's own resolved `props` directly, without ever touching `kind`.
    # A record's `kind` always means, and only ever means, "who is my real
    # structural parent" — do not reintroduce an id-matches-factory shortcut
    # that sets `kind` as a side effect of resolving defaults.
    id: str = ''
    kind: str = 'root'
    factory: str = 'object'
    props: dict[str, Any] = field(default_factory=dict)
    items: list[Any] = field(default_factory=list)
    refs: list[str] = field(default_factory=list)

    def record(self) -> 'RootRecord':
        """Return this instance's plain-data record form — a copy, not a reference."""
        return {
            'id': self.id,
            'kind': self.kind,
            'factory': self.factory,
            'props': dict(self.props),
            'items': list(self.items),
            'refs': list(self.refs),
        }


# Explicit kind='object' — root is the one record allowed to have it; every
# other object's kind defaults to 'root' (see the dataclass field above),
# since 'root' is always resolvable as an ancestor and 'object' never is.
root_instance = Root(id='root', kind='object')


# Plain data form — a TypedDict is a plain dict at runtime with no class behaviour.
# Use this when a lightweight structure is needed, e.g. for JSON serialisation,
# inter-process messaging, or passing data across boundaries that expect plain dicts.
class RootRecord(TypedDict):
    id: str
    # The structural parent's id ('root' unless positioned elsewhere). Only ever structural: it never supplies defaults.
    kind: str
    factory: str
    props: dict[str, Any]
    items: list[Any]
    refs: list[str]
    # Optional, on registry entries (records.json): the id of a registered record this one takes its defaults from,
    # transitively. Not kept on a resolved product — the defaults are merged in.
    extends: NotRequired[str]


root_record: RootRecord = {
    'id': 'root',
    'kind': 'object',
    'factory': 'object',
    'props': {},
    'items': [],
    'refs': [],
}


# ── Id generation ─────────────────────────────────────────────────────────────
#
# Every auto-generated id is prefixed with the object's own `factory` —
# f'{factory}-{uuid}' — rather than a bare uuid, so an id is self-describing
# about what built it (e.g. 'image-3f2b...'). The hyphen delimiter matches
# this repo's Slug convention and keeps the prefix unambiguous to split back
# out, unlike a bare concatenation.

def generate_id(factory: str) -> str:
    """Build an auto-generated id for a new object of the given `factory`."""
    return f'{factory}-{uuid.uuid4()}'


# ── Child creation ────────────────────────────────────────────────────────────
#
# Rules applied by both functions:
#   • kind     — always set to parent.id (records the parent; caller cannot override)
#   • id       — auto-generated UUID when not supplied; must differ from parent.id
#   • factory  — inherited from parent when the caller omits it
#   • props    — merged with parent's props; child's own fields take precedence
#   • items    — never inherited from parent; defaults to an empty list when omitted
#   • refs     — inherited from parent when the caller omits them
#
# Deliberately single-level: these take an already-resolved parent object
# directly rather than looking one up by id, so there is no registry here to
# walk further ancestors through. Contrast create.py's create_instance() /
# create_record(), which resolve `kind` against instances_by_id /
# record_registry and merge props all the way up to 'root', not just the
# immediate parent — use those when full multi-level inheritance matters.


def create_child_instance(
    parent: Root,
    id: str | None = None,
    factory: str | None = None,
    props: dict[str, Any] | None = None,
    items: list[Any] | None = None,
    refs: list[str] | None = None,
) -> Root:
    """Build a Root instance as a child of an already-resolved parent instance.

    Single-level only — see this module's own comment above for why, and
    when to use `create_instance()` (in create.py) instead.

    Args:
        parent: The parent instance to inherit from.
        id: Child id. Auto-generated when omitted; must differ from `parent.id`.
        factory: Child factory. Inherited from `parent` when omitted.
        props: Merged with `parent.props`; these take precedence on conflicts.
        items: Never inherited from `parent`; defaults to an empty list.
        refs: Inherited from `parent` when omitted.

    Returns:
        The new child Root instance.

    Raises:
        ValueError: If `id` equals `parent.id`.
    """
    resolved_factory = factory if factory is not None else parent.factory
    child_id = id if id is not None else generate_id(resolved_factory)
    if child_id == parent.id:
        raise ValueError(
            f"Child id '{child_id}' must differ from parent id '{parent.id}'."
        )
    return Root(
        id=child_id,
        kind=parent.id,
        factory=resolved_factory,
        props={**parent.props, **(props if props is not None else {})},
        items=list(items) if items is not None else [],
        refs=list(refs)   if refs  is not None else list(parent.refs),
    )


def create_child_record(
    parent: RootRecord,
    id: str | None = None,
    factory: str | None = None,
    props: dict[str, Any] | None = None,
    items: list[Any] | None = None,
    refs: list[str] | None = None,
) -> RootRecord:
    """Build a RootRecord as a child of an already-resolved parent record.

    Single-level only — see this module's own comment above for why, and
    when to use `create_record()` (in create.py) instead.

    Args:
        parent: The parent record to inherit from.
        id: Child id. Auto-generated when omitted; must differ from `parent['id']`.
        factory: Child factory. Inherited from `parent` when omitted.
        props: Merged with `parent['props']`; these take precedence on conflicts.
        items: Never inherited from `parent`; defaults to an empty list.
        refs: Inherited from `parent` when omitted.

    Returns:
        The new child RootRecord.

    Raises:
        ValueError: If `id` equals `parent['id']`.
    """
    resolved_factory = factory if factory is not None else parent['factory']
    child_id = id if id is not None else generate_id(resolved_factory)
    if child_id == parent['id']:
        raise ValueError(
            f"Child id '{child_id}' must differ from parent id '{parent['id']}'."
        )
    return {
        'id':      child_id,
        'kind':    parent['id'],
        'factory': resolved_factory,
        'props':   {**parent['props'], **(props if props is not None else {})},
        'items':   list(items) if items is not None else [],
        'refs':    list(refs)  if refs  is not None else list(parent['refs']),
    }


# ── Ref parsing ───────────────────────────────────────────────────────────────
#
# parse_ref converts a single ref string into a key-value dict.
#
# A ref string starts with a key: one or more lowercase alphabetical
# characters. What follows the key determines the value:
#   • Number  (e.g. 'size12', 'ratio1.5')  ->  {'size': 12} / {'ratio': 1.5}
#   • Capital (e.g. 'colorRed')            ->  {'color': 'red'}
#   • Other patterns — append a handler to ref_handlers to support them.
#
# ref_handlers is the extension point: append a RefHandler to it to support
# additional patterns without modifying this file.

# The result of a successful ref parse: a single key mapped to its value.
ParsedRef = dict[str, Any]

# A handler receives the extracted key and the remainder of the ref string.
# It returns a ParsedRef if it recognises the pattern, or None to pass
# control to the next handler.
RefHandler = Callable[[str, str], ParsedRef | None]


def _number_handler(key: str, remainder: str) -> ParsedRef | None:
    """Handle key followed by an integer or decimal number (e.g. 'foo12', 'foo1.5')."""
    if not _re.fullmatch(r'\d+(\.\d+)?', remainder):
        return None
    value: int | float = float(remainder) if '.' in remainder else int(remainder)
    return {key: value}


def _capital_handler(key: str, remainder: str) -> ParsedRef | None:
    """Handle key followed by a capital letter — camelCase split (e.g. 'fooBar' -> {'foo': 'bar'})."""
    if not remainder or not remainder[0].isupper():
        return None
    return {key: remainder[0].lower() + remainder[1:]}


# Ordered list of handlers applied by parse_ref. Append additional handlers
# here to support new ref string patterns.
ref_handlers: list[RefHandler] = [_number_handler, _capital_handler]


def parse_ref(ref: str) -> ParsedRef | None:
    """Parse a single ref string into a key-value dict.

    The key is the leading run of lowercase alphabetical characters. Handlers
    in ref_handlers are tried in order; the first match wins. Returns None if
    the string has no valid key or no handler recognises the remainder.

    Args:
        ref: A ref string from a Root object's refs list.
    """
    match = _re.match(r'^([a-z]+)(.*)', ref)
    if not match:
        return None
    key, remainder = match.group(1), match.group(2)
    for handler in ref_handlers:
        result = handler(key, remainder)
        if result is not None:
            return result
    return None


# ── Record registry & ancestor resolution ─────────────────────────────────────
#
# A single registry, keyed by id, holding RootRecord — every named record any
# collection declares, factory configuration (e.g. a declarative factory's
# default props) included. This is what a product's requested `kind` (see
# factory.py) resolves against, and what create()'s "resolve the factory's
# own identity" step (create.py) also resolves against.
#
# Shared globally across every collection (see get_collection.py's
# registry's collection list): if two collections declare a record under the same id,
# whichever collection is registered later overwrites the earlier one's
# entry here — this is deliberate, not a bug (see get_collection.py's own
# docstring on registration order). The earlier, shadowed entry is never
# lost — it remains retrievable via get_collection(collection_id), which
# resolves against that specific collection's own scoped registry instead of
# this shared, merged one. See get_collection.py's module docstring for the
# full mechanism.
#
# Pre-registered with root's own entry so 'root' is always a resolvable
# ancestor with no setup call required.

record_registry: dict[str, RootRecord] = {root_record['id']: root_record}


def resolve_inherited_record_props(
    parent: RootRecord,
    registry: dict[str, RootRecord],
    cache: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Merge `parent`'s props with those of every record it `extends`, transitively, cache permitting.

    `kind` is never consulted: it is the structural parent only. Defaults come from
    the `extends` chain (an optional record id on each registry entry). The chain's
    root-most record is merged first and `parent` last, so nearer records win.

    Every entry in `registry` is assumed to already be a complete RootRecord
    (records.json entries and create_record()'s own output both guarantee
    this in this codebase) — so no partial-record completion step is needed here.

    Args:
        parent: The record whose resolved props are wanted (the one an `extends` names, or a factory's own record).
        registry: The registry `extends` ids are looked up against.
        cache: Optional, keyed by record id. A hit skips the walk entirely.

    Raises:
        ValueError: If the `extends` chain contains a cycle.
        KeyError: If a record's `extends` names an id that is not registered.
    """
    if cache is not None and parent['id'] in cache:
        return cache[parent['id']]

    chain: list[dict[str, Any]] = []
    visited: list[str] = []
    current: RootRecord | None = parent
    while current is not None:
        if current['id'] in visited:
            raise ValueError(
                f"Record '{current['id']}' extends itself through a cycle ({' -> '.join([*visited, current['id']])})."
            )
        visited.append(current['id'])
        chain.insert(0, current['props'])
        next_id = current.get('extends')
        if next_id is None:
            break
        current = registry.get(next_id)
        if current is None:
            raise KeyError(f"Record '{visited[-1]}' extends '{next_id}', which is not registered.")
    result: dict[str, Any] = {}
    for props in chain:
        result.update(props)
    if cache is not None:
        cache[parent['id']] = result
    return result
