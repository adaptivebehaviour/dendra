from typing import Callable

from ab_manifesto.create import RegistryTarget
from ab_manifesto.collections.manifesto import register_manifesto_collection
from ab_manifesto.registry import Collection, CollectionDefinition, Registry, create_registry, define_collection

# The default registry: `manifesto` (see manifesto/__init__.py), plus whatever
# application code adds through register_collection() — e.g. the Streamlit
# package's `ui`/`test` collections (python/workshop/streamlit/app.py). An
# application that wants explicit control composes its own registry with
# registry.create_registry() instead; this module keeps the one-line call sites
# (`get_collection()`, `register_collection()`) working. This shared module must
# stay framework-free, so a collection needing a UI framework belongs in the app.
_registrars: list[tuple[str, Callable[[RegistryTarget], None]]] = [
    ('manifesto', register_manifesto_collection),
]

_cached: tuple[tuple[str, ...], Registry] | None = None


def register_collection(id: str, register: Callable[[RegistryTarget], None]) -> None:
    """Add a collection to the default registry, under a name callers can later
    use to resolve that specific collection's own scope via get_collection(id).

    Idempotent by id — registering the same id twice is a no-op (e.g. because a
    Streamlit rerun re-executes the whole app script). A collection added this
    way may override any earlier one's ids without a collision warning (it
    declares `overrides='*'`); use define_collection() + create_registry() to
    declare overrides precisely.
    """
    if not any(existing_id == id for existing_id, _ in _registrars):
        _registrars.append((id, register))


def _default_registry() -> Registry:
    global _cached
    key = tuple(id_ for id_, _ in _registrars)
    if _cached is None or _cached[0] != key:
        definitions: list[CollectionDefinition] = [
            define_collection(id_, register, overrides=() if id_ == 'manifesto' else '*')
            for id_, register in _registrars
        ]
        _cached = (key, create_registry(definitions))
    return _cached[1]


def get_collection(collection_id: str | None = None) -> Collection:
    """The merged view across the default registry's collections, or — with a
    `collection_id` — one collection's own scope, bypassing whatever overrides it
    in the merged view. See Registry.get_collection().

    Raises:
        KeyError: If `collection_id` is given but no collection has that id.
    """
    return _default_registry().get_collection(collection_id)
