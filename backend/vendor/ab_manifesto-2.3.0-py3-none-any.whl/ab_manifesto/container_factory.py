from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ab_manifesto.root import Root, RootRecord
from ab_manifesto.create import resolve_product


def _is_arg_options_pair(item: Any) -> bool:
    """True when `item` is an explicit `[arg, options]` pair rather than a
    bare create-arg — a 2-element *list* (not a Python `tuple` — see below)
    whose first element is a `str` and whose second element is a plain
    `dict`.

    A `list`, specifically, not a `tuple`: `create()`'s own array-shorthand
    (`isinstance(arg, list)` in `resolve_product()`) only ever recognises
    `list` as its "bare array" concept, mirroring the single array type the
    JS port's own array-shorthand and this pair form both draw on. Using a
    `tuple` here instead would fall through to that shorthand and crash (a
    `tuple` has no `.get()`), rather than degrading gracefully the way a
    non-matching `list` item does.

    Restricted to a *string* first element on purpose, not "string or plain
    dict" — when `arg` is a dict, `create()`'s own dispatch uses that dict
    directly as its produce options and silently ignores a separate
    `options` argument entirely. Allowing `[dict_arg, options]` as a pair
    would mean the `options` half is quietly dropped — exactly the kind of
    silent misbehaviour this codebase avoids elsewhere. A caller with a dict
    `arg` should fold any extra options directly into that dict instead
    (e.g. `{'factory': 'text', 'items': ['Hi!'], 'props': {...}}`), which
    already works via the ordinary bare-dict item form. Mirrors the JS
    port's `isArgOptionsTuple()` in `ContainerFactory.ts`.
    """
    if not isinstance(item, list) or len(item) != 2:
        return False
    arg, options = item
    return isinstance(arg, str) and isinstance(options, dict)


def resolve_item_record(item: Any, props_cache: dict[str, dict[str, Any]] | None = None) -> RootRecord:
    """Resolves one raw `items` entry into a plain, complete `RootRecord` —
    never a rendered component. Uses `resolve_product()` rather than the
    friendlier `create()` specifically because that one auto-renders into a
    component when its resolved factory has one registered; storing an
    already-rendered component back onto a record's `items` would break the
    "items is plain content" convention everywhere else in this codebase
    relies on. An `Instance` result is normalised via its own `.record()` so
    every stored item is uniformly record-shaped; rendering happens later,
    at actual render time.

    `item` may be a bare create-arg (a factory string, optionally
    `'factory:bar'` shorthand, or an options dict) or an explicit
    `[arg, options]` pair (a `list`, not a `tuple`) — see
    `_is_arg_options_pair()`.
    """
    if _is_arg_options_pair(item):
        arg, options = item
    else:
        arg, options = item, None
    resolved = resolve_product(arg, options, props_cache)
    record_method = getattr(resolved, 'record', None)
    return resolved.record() if callable(record_method) else resolved


@dataclass
class ContainerFactory(Root):
    """Factory-capable base class for "my `items` are always create-args" —
    the general form `manifesto/factories/component_factory.py` (factory `'component'`)
    is built on. Resolves every element of `items` into its own resolved
    child record (see `resolve_item_record()`), replacing the caller's raw
    items with the resolved ones on the returned product.

    Preserves the two-phase resolution the generic `Factory` default
    provides (a real `kind` ancestor's props merged with this factory's own
    declared defaults) via `self.record()`, which already reflects that same
    merge by the time `produce()` runs (see `create_record()` in
    `create.py`) — only `items` needs further resolution. This works for a
    factory with no declared defaults of its own (like `'component'`); a
    factory that *does* have real declared defaults and also needs `items`
    resolution should use `item_factory.py`'s `resolve_only_item()` directly
    and compose with `Factory` instead — see `manifesto/factories/image_factory.py`'s
    own comment for why.

    Unlike the JS port's own `ContainerFactory`, `produce()` here stays
    ordinary, synchronous — Python's whole `create()` pipeline has no async
    story to begin with (see `fetch.py`'s own comment on why `FetchOperation`
    is synchronous), so there's no "commit to async unconditionally"
    decision to make; every item resolves through the same synchronous
    `create()`/`resolve_product()` path everything else in this codebase
    already uses.
    """

    def produce(
        self,
        options: dict[str, Any] | None = None,
        cache: dict[str, dict[str, Any]] | None = None,
        records: dict[str, RootRecord] | None = None,
    ) -> RootRecord:
        base = self.record()
        items = [resolve_item_record(item, cache) for item in base['items']]
        return {**base, 'items': items}
