from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from typing import Any, ClassVar

import httpx

from ab_manifesto.runnable import ArgSpec, Operation, OperationResult


@dataclass
class FetchOperation(Operation):
    """Factory `fetch` — resolves the `baseUrl` prop and `items` (path
    segments) into a `url` prop at construction time, then fetches that
    url on `run()`.

    Construction is synchronous and side-effect-free: `url` is
    derived and folded into `props` the moment a FetchOperation is
    built (see `__post_init__`), so a record built via
    `create('fetch', {...})` (or `.record()` on the instance) already
    carries its resolved `url` — usable by anything that wants it (e.g. a
    client component rendering an image) without ever calling `run()`.
    `run()`/`execute()` is the separate step that actually performs the
    GET — synchronous, since `Operation.execute()` has no async support.

    `props['authScheme']` controls how the request is authenticated:
    - unset / `'none'` — a plain GET, no extra headers.
    - `'bearer'` — `props['tokenEnvVar']` names an environment variable
      resolved via `os.environ` and sent as `Authorization: Bearer <token>`.
      Only the identifier lives on the record/props — never the token value
      itself, so it stays safe to store in a git-tracked `records.json`.
      Unlike the JS port, this reads `os.environ` directly rather than
      taking an injected resolver: Python has no browser/client-bundle
      boundary to guard against, so there's no equivalent risk of this code
      ending up somewhere it could leak a real secret.
    - any other value — `execute()` returns an error result rather than
      silently sending an unauthenticated request.

    Usage:
        from ab_manifesto.get_collection import get_collection
        record = get_collection().create('fetch', {
            'items': ['foo'],
            'props': {'baseUrl': 'https://myapi.com', 'width': 32, 'height': 32},
        }).record()
        # the record's url prop is now 'https://myapi.com/foo'

        # Later, from that same record — construct again and actually fetch:
        result = FetchOperation(**record).run()

        # A record requiring a bearer token (SANITY_TOKEN_READ must be set in
        # the environment this runs in):
        authed = FetchOperation(
            factory='fetch', items=['assets'],
            props={'baseUrl': 'https://api.sanity.io', 'authScheme': 'bearer', 'tokenEnvVar': 'SANITY_TOKEN_READ'},
        )
        authed.run()

    Note: `arg_specs` is empty and CLI args can't set `baseUrl`/`items`
    (those are constructor-time only, not run()-time) — so
    `python -m manifesto.fetch` will always report "no url to fetch"; the
    CLI entry point is kept for parity with every other Operation, not
    because it's a useful way to configure this one.
    """

    description: ClassVar[str] = 'Fetch the resource at a url derived from baseUrl + items.'
    arg_specs: ClassVar[list[ArgSpec]] = []

    def __post_init__(self) -> None:
        self.props = dict(self.props)
        base_url = self.props.get('baseUrl')
        if isinstance(base_url, str) and self.items:
            base = base_url.rstrip('/')
            path = '/'.join(str(item) for item in self.items)
            self.props['url'] = f'{base}/{path}'

    def execute(self, args: dict[str, Any]) -> OperationResult:
        """Fetch the `url` prop derived at construction time (see class docstring).

        Args:
            args: Unused; FetchOperation has no run-time arguments of its
                own, everything relevant was already resolved into `props`
                at construction.

        Returns:
            An OperationResult whose `.payload` is the parsed JSON body (or
            raw text, if the body isn't valid JSON) — an error result if
            `url` is missing, `authScheme` can't be satisfied, or the
            request fails.
        """
        url = self.props.get('url')
        if not url:
            return OperationResult.error(
                f"'{self.factory}' has no url to fetch — "
                "set props['baseUrl'] and items before calling run()."
            )

        headers: dict[str, str] = {}
        auth_scheme = self.props.get('authScheme')
        if auth_scheme == 'bearer':
            token_env_var = self.props.get('tokenEnvVar')
            if not token_env_var:
                return OperationResult.error(
                    f"'{self.factory}' has authScheme 'bearer' but no props['tokenEnvVar'] set."
                )
            token = os.environ.get(token_env_var)
            if not token:
                return OperationResult.error(
                    f"'{self.factory}' could not resolve secret '{token_env_var}' — "
                    "is the environment variable set?"
                )
            headers['Authorization'] = f'Bearer {token}'
        elif auth_scheme not in (None, 'none'):
            return OperationResult.error(f"'{self.factory}' has unsupported authScheme '{auth_scheme}'.")

        try:
            response = httpx.get(url, headers=headers or None)
        except httpx.HTTPError as err:
            return OperationResult.error(f"Fetch of '{url}' failed: {err}", payload={'url': url})

        if response.status_code >= 400:
            return OperationResult.error(
                f"Fetch of '{url}' failed: {response.status_code} {response.reason_phrase}",
                payload={'url': url, 'status': response.status_code},
            )

        try:
            data = response.json()
        except ValueError:
            data = response.text
        text = data if isinstance(data, str) else json.dumps(data)
        return OperationResult.ok(text, payload={'url': url, 'data': data})


def run(args: Any = None) -> str:
    """Import entry point. Unlike hello_world.py's run() — whose args are
    run-time — FetchOperation's meaningful input (items/props['baseUrl'])
    is constructor-time, so this builds a fresh FetchOperation from `args`
    (treated as {'items': ..., 'props': ...}) and runs it immediately.
    """
    config = args if isinstance(args, dict) else {}
    return FetchOperation(
        factory='fetch',
        items=list(config.get('items', [])),
        props=dict(config.get('props', {})),
    ).run()


if __name__ == '__main__':
    sys.exit(FetchOperation(factory='fetch').main())
