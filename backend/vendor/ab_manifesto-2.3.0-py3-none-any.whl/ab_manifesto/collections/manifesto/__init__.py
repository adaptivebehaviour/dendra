import json
from pathlib import Path

from ab_manifesto.create import RegistryTarget
from ab_manifesto.schemas import validate_records

from .factories.component_factory import ComponentFactory
from .fetch import FetchOperation
from .generic_component import GenericComponent
from .hello_world import HelloWorldOperation
from .factories.image_factory import ImageFactory
from .root_component import RootComponent
from .sanity_fetch import SanityFetchOperation

_RECORDS_PATH = Path(__file__).resolve().parent / 'records.json'


def register_manifesto_collection(target: RegistryTarget) -> None:
    """Register this collection's records, components, and operations into
    the RegistryTarget it's handed.

    The base collection every application starts with — the `root` and
    `component` factories (component_registry), plus `hello-world`/`fetch`/
    `sanity-fetch`/`component`/`image` (instance_registry — the last two
    Factory-capable classes, the rest Runnables; see Nomenclature's
    "Runnable objects"/"Factory objects" — both are registered the same way
    as any other Instance-satisfying factory, not through a separate
    registry). More content will be added here over time.

    `component` (`ComponentFactory`) and `image` (`ImageFactory`) both have
    custom `instance_registry` entries rather than going through the
    generic `Factory` default — each needs to resolve an `items` element
    into a component/props respectively, which the generic default can't
    provide (see each class's own docstring). `image` is also the first
    purely-declarative factory in this collection to need one — its own
    defaults live in `records.json` below like any other record — see
    `root.py`'s "Record registry & ancestor resolution" section.

    Writes into `target` rather than create.py's module-level registries
    directly — get_collection.py calls this against a fresh, empty target to
    capture exactly what this collection declares (for
    get_collection('manifesto')'s own-scope resolution) before merging it
    into the shared global registries — see get_collection.py's own module
    docstring for the full mechanism.

    Unlike an app-owned collection (e.g. the Streamlit package's `ui`/`test`
    collections, added via register_collection()), this one lives in the
    shared library itself and is registered by get_collection() by default —
    see get_collection.py's own comment on why its components must stay
    framework-free.
    """
    with open(_RECORDS_PATH, encoding='utf-8') as f:
        records = validate_records('manifesto/records.json', json.load(f))
    for record in records:
        target.record_registry[record['id']] = record
    target.component_registry['root'] = RootComponent
    target.component_registry['component'] = GenericComponent
    target.instance_registry['hello-world'] = lambda record: HelloWorldOperation(**record)
    target.instance_registry['fetch'] = lambda record: FetchOperation(**record)
    target.instance_registry['sanity-fetch'] = lambda record: SanityFetchOperation(**record)
    target.instance_registry['component'] = lambda record: ComponentFactory(**record)
    target.instance_registry['image'] = lambda record: ImageFactory(**record)
