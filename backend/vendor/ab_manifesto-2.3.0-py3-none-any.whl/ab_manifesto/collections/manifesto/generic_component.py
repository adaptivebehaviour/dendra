from ab_manifesto.root import RootRecord


class GenericComponent:
    """Factory 'component' — a generic, unstyled record wrapper.

    Framework-free placeholder — see root_component.py's own docstring for
    why. More content will be added here over time.

    Args:
        record: The record to render.
    """

    def __init__(self, record: RootRecord):
        self.record = record

    def render(self) -> None:
        pass
