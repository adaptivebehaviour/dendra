from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from typing import Any, ClassVar

import httpx

from ab_manifesto.runnable import ArgSpec, Operation, OperationResult


@dataclass
class SanityFetchOperation(Operation):
    """Factory `sanity-fetch` — fetches a single Sanity document by its
    document-defined `id` field.

    Uses the GROQ query endpoint (`/data/query/`), not the `/data/doc/`
    doc-fetch endpoint — that endpoint looks documents up by Sanity's own
    system `_id`, but the identifier this operation is handed (e.g.
    `'apple-whole'`) is the document's own `id` field, a separate,
    schema-defined property. The query is `*[id == $id][0]`, so the result
    is either a single matching document or `null`.

    `props` configure the project the document is fetched from (constructor
    time, same convention as `FetchOperation`'s `baseUrl`/`authScheme`):
    - `projectId` (required) — the Sanity project id.
    - `dataset` — defaults to `'production'`.
    - `apiVersion` — defaults to `'2024-01-01'`; any dated version accepted
      by Sanity's `/data/query/` endpoint works.
    - `tokenEnvVar` — defaults to `'SANITY_TOKEN_READ'`; the environment variable
      (resolved via `os.environ`) sent as `Authorization: Bearer <token>`.
      Only the identifier lives on the record/props — never the token value
      itself, so it stays safe to store in a git-tracked `records.json`.

    `id` (the document to fetch, matched against the document's own `id`
    field) is the one run-time argument — see `arg_specs` — so the same
    configured operation can fetch different documents across calls.

    Usage:
        from ab_manifesto.get_collection import get_collection
        record = get_collection().create('sanity-fetch', {
            'props': {'projectId': 'myprojectid'},
        }).record()

        # Later, from that same record — construct again and fetch a document:
        result = SanityFetchOperation(**record).run({'id': 'abc123'})

    Or directly:
        SanityFetchOperation(
            factory='sanity-fetch',
            props={'projectId': 'myprojectid', 'dataset': 'production'},
        ).run({'id': 'abc123'})
    """

    description: ClassVar[str] = 'Fetch a single Sanity document by id.'
    arg_specs: ClassVar[list[ArgSpec]] = [
        ArgSpec('id', 'string', help='Id of the Sanity document to fetch', required=True),
    ]

    def execute(self, args: dict[str, Any]) -> OperationResult:
        """Fetch the Sanity document identified by `args['id']`.

        Args:
            args: Coerced arguments, per `arg_specs` — just `id`.

        Returns:
            An OperationResult whose `.payload['document']` is the fetched
            document — an error result if `props['projectId']` is missing,
            the token can't be resolved, the request fails, or no document
            with that id exists.
        """
        document_id = args.get('id')
        if not document_id:
            return OperationResult.error(f"'{self.factory}' requires an 'id' argument.")

        project_id = self.props.get('projectId')
        if not project_id:
            return OperationResult.error(f"'{self.factory}' has no props['projectId'] set.")

        dataset = self.props.get('dataset', 'production')
        api_version = self.props.get('apiVersion', '2024-01-01')

        token_env_var = self.props.get('tokenEnvVar', 'SANITY_TOKEN_READ')
        token = os.environ.get(token_env_var)
        if not token:
            return OperationResult.error(
                f"'{self.factory}' could not resolve secret '{token_env_var}' — "
                "is the environment variable set?"
            )

        url = f'https://{project_id}.api.sanity.io/v{api_version}/data/query/{dataset}'
        headers = {'Authorization': f'Bearer {token}'}
        params = {'query': '*[id == $id][0]', '$id': json.dumps(document_id)}

        try:
            response = httpx.get(url, headers=headers, params=params)
        except httpx.HTTPError as err:
            return OperationResult.error(
                f"Fetch of Sanity document with id '{document_id}' failed: {err}", payload={'id': document_id}
            )

        if response.status_code >= 400:
            return OperationResult.error(
                f"Fetch of Sanity document with id '{document_id}' failed: "
                f'{response.status_code} {response.reason_phrase}',
                payload={'id': document_id, 'status': response.status_code},
            )

        document = response.json().get('result')
        if not document:
            return OperationResult.error(
                f"Sanity document with id '{document_id}' was not found.", payload={'id': document_id}
            )

        return OperationResult.ok(json.dumps(document), payload={'id': document_id, 'document': document})


def run(args: Any = None) -> str:
    """Import entry point. `args` is treated as `{'props': {...}, 'id': ...}`
    — `props` configures the operation (`projectId`/`dataset`/...) at
    construction time, same split as `fetch.py`'s own module-level `run()`;
    everything else is passed through as the run-time argument.
    """
    config = args if isinstance(args, dict) else {}
    props = dict(config.get('props', {}))
    run_args = {key: value for key, value in config.items() if key != 'props'}
    return SanityFetchOperation(factory='sanity-fetch', props=props).run(run_args)


if __name__ == '__main__':
    sys.exit(SanityFetchOperation(factory='sanity-fetch').main())
