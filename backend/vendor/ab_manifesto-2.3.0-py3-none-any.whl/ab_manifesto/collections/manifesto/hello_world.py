from __future__ import annotations

import sys
from typing import Any, ClassVar

from ab_manifesto.runnable import ArgSpec, Operation, OperationResult


class HelloWorldOperation(Operation):
    """Factory `hello-world` — greets by name.

    Ported from AB/projects/operations/hello_world.py as the worked example
    of a Runnable object in manifesto.

    Usage:
        python -m manifesto.hello_world [name] [--shout]

    Import:
        from ab_manifesto.get_collection import get_collection
        get_collection().create_operation('hello-world', {'name': 'Drew', 'shout': True})
    """

    description: ClassVar[str] = 'Print a greeting.'
    arg_specs: ClassVar[list[ArgSpec]] = [
        ArgSpec('name', 'string', help='Name to greet', default='world', nargs='?'),
        ArgSpec('--shout', 'boolean', help='Print the greeting in upper case'),
    ]

    def execute(self, args: dict[str, Any]) -> OperationResult:
        """Build the greeting.

        Args:
            args: Coerced arguments — `name` (str, defaults to `'world'`)
                and `shout` (bool).

        Returns:
            An OperationResult whose `.text` is the greeting and whose
            `.payload` carries the resolved `name`/`shout` values.
        """
        name = args.get('name', 'world')
        message = f'Hello, {name}!'
        if args.get('shout'):
            message = message.upper()
        return OperationResult.ok(message, payload={'name': name, 'shout': bool(args.get('shout'))})


def run(args: Any = None) -> str:
    """Import entry point; creates a HelloWorldOperation and calls its run()."""
    return HelloWorldOperation(factory='hello-world').run(args)


if __name__ == '__main__':
    sys.exit(HelloWorldOperation(factory='hello-world').main())
