from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ab_manifesto.root import Root, RootRecord
from ab_manifesto.factory import Factory
from ab_manifesto.create import record_registry, resolve_factory_record
from ab_manifesto.item_factory import resolve_only_item


@dataclass
class ImageFactory(Root):
    """Factory `'image'` — resolves an optional single `items[0]` element
    into this image's own `props`, on top of the ordinary two-phase
    resolution (this factory's own declared `records.json` defaults merged
    with a real `kind` ancestor's props) the generic `Factory` default
    previously provided for `'image'` on its own. Registered in
    `instance_registry` (see `__init__.py`), replacing that generic default.

    Conceptually an `ItemFactory` (see `item_factory.py`) — but doesn't
    literally extend it, for consistency with the JS port (`ImageFactory.ts`),
    where `ItemFactory` can't be a base class here for a TypeScript-specific
    reason (return-type covariance between a conditionally-sync/async
    override and an unconditionally-async base method). That constraint
    doesn't exist in Python — this class *could* extend `ItemFactory`
    directly — but composing with `resolve_only_item()` the same way keeps
    both ports structurally identical rather than diverging for an
    accident of language difference.

    Why composing with a fresh `Factory` instance (via `resolve_factory_record()`)
    rather than just using `self.record()` (the way `ContainerFactory`/
    `ComponentFactory` do): `self.record()` only correctly carries `'image'`'s
    own declared defaults when the caller's `kind` is left unspecified (via
    `create_record()`'s "bare string as registered id" rule). When `kind`
    *is* given explicitly — e.g. positioning an image under `'profile-card'`,
    merging that ancestor's own props too — that rule doesn't apply, and
    `self.record()` would be missing `'image'`'s own declared
    `url`/`width`/`height`/`alt` defaults entirely. Re-resolving `'image'`'s
    own identity via `resolve_factory_record()` and handing it to a plain
    `Factory` instance replicates the *exact* two-phase merge the generic
    default always provided, regardless of whether `kind` was given.

    Usage:
        from ab_manifesto.get_collection import get_collection
        collection = get_collection()
        collection.create('image', {'props': {'url': 'avatar.jpg'}})  # unchanged
        collection.create('image', {'items': ['hello-world']})  # new — resolves items[0] into props
    """

    def produce(
        self,
        options: dict[str, Any] | None = None,
        cache: dict[str, dict[str, Any]] | None = None,
        records: dict[str, RootRecord] | None = None,
    ) -> RootRecord:
        target = records if records is not None else record_registry
        opts = options or {}
        raw_items = list(opts.get('items') or [])

        factory_record = resolve_factory_record(self.factory, target, cache)
        factory_instance = Factory(**factory_record)

        if len(raw_items) == 0:
            return factory_instance.produce(opts, cache, target)

        resolved_item = resolve_only_item(raw_items, self.factory, cache)
        merged_props = {
            **(resolved_item['props'] if resolved_item is not None else {}),
            **opts.get('props', {}),
        }
        base = factory_instance.produce({**opts, 'props': merged_props}, cache, target)
        return {**base, 'items': []}
