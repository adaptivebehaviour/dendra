from __future__ import annotations

from ab_manifesto.container_factory import ContainerFactory


class ComponentFactory(ContainerFactory):
    """Factory `'component'` — resolves each element of a passed `items`
    list into its own resolved child record, so a consuming application's
    own component classes (registered into `component_registry`, e.g. the
    Streamlit package's `ui`/`test` collections) can render each one as a
    child. Registered in `instance_registry` (see `__init__.py`), replacing
    the generic `Factory` default `'component'` previously used.

    A thin subclass of `ContainerFactory` — `'component'` has no declared
    defaults of its own and no record-assembly needs beyond resolving every
    `items` element, so `ContainerFactory`'s own `produce()` covers
    everything this factory needs. See `container_factory.py`'s own
    docstring for the full behaviour: how the two-phase `kind`-ancestor/
    own-defaults merge is preserved, and how each `items` element is
    resolved (including the `[arg, options]` pair form).

    Usage:
        from ab_manifesto.get_collection import get_collection
        record = get_collection().create('component', {
            'items': ['hello-world', ['image', {'props': {'url': 'apple.jpg', 'width': 32}}]],
        })
    """
