from ab_manifesto.root import RootRecord


class RootComponent:
    """Factory 'root' — a record's top-level container.

    Framework-free placeholder: this collection lives in the shared library,
    which also serves UI-free apps (the CLI app, the FastAPI backend), so
    it cannot render via a specific UI library the way an app-owned
    collection can. More content will be added here over time.

    Args:
        record: The record to render.
    """

    def __init__(self, record: RootRecord):
        self.record = record

    def render(self) -> None:
        pass
