"""Collections that ship with the core package."""
