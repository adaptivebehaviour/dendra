from __future__ import annotations

from typing import Any


def to_items(value: Any) -> list[Any]:
    """Normalizes a value that may arrive as a single item, a list of items,
    or None into one canonical shape: always a list, never a bare item and
    never None. None collapses to [] — there is no separate "no result"
    state, only "zero items".

    Meant to run exactly once, at the boundary where a value crosses in from
    outside this codebase's own always-list `items` convention (see
    RootRecord['items'] in root.py) — e.g. a Sanity GROQ result (`*[id in
    $ids]` yields a list, `*[id == $id][0]` yields a single document or
    None) or a parsed directive argument (`_resolve_args()` in parse.py).
    Once a value has been normalized here, nothing downstream should
    re-check `isinstance(value, list)` on it.

    A list input is returned as-is, not defensively copied — a caller that
    needs isolation from the source should copy it itself.

    Args:
        value: A single item, a list of items, or None.

    Returns:
        `[]` if `value` was None, `value` itself if it was already a list,
        or `[value]` otherwise.
    """
    if value is None:
        return []
    return value if isinstance(value, list) else [value]
