from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from typing import Any, ClassVar

from ab_manifesto.root import Root

# Declarative argument types shared by ArgSpec's `type` field — the Python
# analogue of AB/projects/operations/args.py's ARG_TYPES.
ARG_TYPES = frozenset({'string', 'boolean', 'json', 'int', 'float'})


@dataclass
class ArgSpec:
    """Declarative description of one operation argument.

    Ported from AB/projects/operations/args.py — shared by CLI (argparse) and
    programmatic (dict) calling conventions, so a single declaration on an
    Operation subclass covers both.
    """

    id: str
    type: str
    help: str = ''
    default: Any = None
    nargs: str | int | None = None
    required: bool = False

    @property
    def key(self) -> str:
        """Normalised dict key (without leading dashes)."""
        return self.id.lstrip('-')


def _add_arg_to_parser(parser: argparse.ArgumentParser, spec: ArgSpec) -> None:
    if spec.type not in ARG_TYPES:
        raise ValueError(f'Unsupported argument type: {spec.type!r}')

    kwargs: dict[str, Any] = {'help': spec.help}
    if spec.type == 'boolean':
        kwargs['action'] = 'store_true'
    elif spec.type == 'json':
        kwargs['type'] = str
        kwargs['default'] = spec.default if spec.default is not None else '{}'
    elif spec.type == 'int':
        kwargs['type'] = int
        if spec.default is not None:
            kwargs['default'] = spec.default
    elif spec.type == 'float':
        kwargs['type'] = float
        if spec.default is not None:
            kwargs['default'] = spec.default
    else:
        kwargs['type'] = str
        if spec.default is not None:
            kwargs['default'] = spec.default

    if spec.nargs is not None:
        kwargs['nargs'] = spec.nargs
    if spec.required and spec.id.startswith('-'):
        kwargs['required'] = True

    parser.add_argument(spec.id, **kwargs)


def _coerce_value(spec: ArgSpec, value: Any) -> Any:
    if spec.type == 'boolean':
        return bool(value)
    if spec.type == 'json':
        if isinstance(value, (dict, list)):
            return value
        if value is None:
            return {}
        if isinstance(value, str):
            return json.loads(value) if value else {}
        return value
    if spec.type == 'int':
        return int(value)
    if spec.type == 'float':
        return float(value)
    return str(value) if value is not None else value


def coerce_args(specs: list[ArgSpec], raw: dict[str, Any]) -> dict[str, Any]:
    """Normalise and coerce a raw argument mapping against an operation's ArgSpecs.

    Ported from AB/projects/operations/args.py. Unrecognised keys pass
    through unchanged; a spec's `default` fills in when its key is absent
    from `raw` (booleans are never defaulted here — an absent boolean flag
    is simply absent, matching argparse's own `store_true` behaviour).
    """
    by_key = {spec.key: spec for spec in specs}
    coerced: dict[str, Any] = {}

    for key, value in raw.items():
        normalised = key.lstrip('-')
        spec = by_key.get(normalised)
        coerced[normalised] = _coerce_value(spec, value) if spec else value

    for spec in specs:
        if spec.key not in coerced and spec.default is not None and spec.type != 'boolean':
            coerced[spec.key] = _coerce_value(spec, spec.default)

    return coerced


@dataclass
class OperationResult:
    """The outcome of an Operation.execute() call.

    Ported from AB/projects/operations/result.py.

    * ``text`` — primary string output; what ``Operation.run()`` returns.
    * ``payload`` — optional structured data for programmatic callers.
    * ``exit_code`` — process exit code (CLI only; ``0`` = success).
    """

    text: str
    payload: dict[str, Any] | None = None
    exit_code: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {'text': self.text, 'payload': self.payload, 'exit_code': self.exit_code}

    def serialize(self, as_json: bool = False) -> str:
        if as_json:
            return json.dumps(self.as_dict(), indent=2)
        return self.text

    @classmethod
    def ok(cls, text: str, *, payload: dict[str, Any] | None = None) -> OperationResult:
        return cls(text=text, payload=payload, exit_code=0)

    @classmethod
    def error(cls, text: str, *, exit_code: int = 1, payload: dict[str, Any] | None = None) -> OperationResult:
        return cls(text=text, payload=payload, exit_code=exit_code)


@dataclass
class Operation(Root):
    """Concrete base for Runnable objects.

    Extends Root — so an Operation is a normal object in the kind/factory
    hierarchy (registers into instance_registry exactly like Root itself,
    inherits id/kind/factory/props/items/refs/record()) — and adds the
    run()/main() contract shared by every calling convention this class
    supports: import, instance method, and CLI. Ported from
    AB/projects/operations/base.py's BaseOperation, minus the
    module-level `args` constructor parameter (an Operation's `args` are
    always passed explicitly to run()/main(), not stored on the instance).

    Subclasses set `description`/`arg_specs` and implement `execute()`,
    returning an OperationResult; all business logic belongs there. `run()`
    unwraps the result's `.text`; a caller that needs the full result (e.g.
    `payload`) should call `execute()` directly rather than `run()`. `main()`
    uses `.serialize()`/`.exit_code`. Never store a run() result on the
    record — a record describes how to run something, not what happened
    when it ran.

    `Operation` is a sibling of `Factory` (`factory.py`), not a base or
    subclass of it — both extend `Root` independently and add their own
    orthogonal capability (Runnable vs. Factory-capable). `Operation` does
    not need `Factory`'s two-phase `produce()`: an Operation's own
    configuration (e.g. `SanityFetchOperation`'s `projectId`/`dataset`) is
    intrinsic to every use of that operation, unlike a declarative factory
    which legitimately wants both its own defaults *and* an unrelated
    structural parent's cascading props at once. See `factory.py`'s own
    module docstring for the full rationale. Do not give `Operation.execute()`
    a second, incompatible meaning by also implementing `produce()` on the
    same class unless a concrete need actually arises — `execute()`'s
    contract (an `OperationResult`) and `produce()`'s contract (a plain
    `RootRecord`) are deliberately kept as two distinctly-named methods for
    exactly this reason.
    """

    description: ClassVar[str] = ''
    arg_specs: ClassVar[list[ArgSpec]] = []

    def build_parser(self) -> argparse.ArgumentParser:
        """Build an argparse.ArgumentParser from `arg_specs`, plus a `--json` flag.

        Used by `parse_args()`'s CLI-parsing branch (list/None source) and by
        `main()` indirectly through it. Not used by `run()`'s dict/None
        handling, which coerces directly against `arg_specs` instead — see
        `run()`'s own docstring for why.
        """
        parser = argparse.ArgumentParser(prog=self.factory, description=self.description)
        for spec in self.arg_specs:
            _add_arg_to_parser(parser, spec)
        parser.add_argument('--json', action='store_true', help='Print the full result as JSON')
        return parser

    def parse_args(self, source: Any = None) -> Any:
        """Normalise `source` into a coerced args dict, dispatching on its type.

        A `dict` is coerced directly against `arg_specs` via `coerce_args()`.
        A `list` (explicit argv-style call) or `None` (real CLI invocation —
        `main()`'s use case) is parsed via `build_parser()`'s
        `argparse.ArgumentParser`, which reads `sys.argv` when `source` is
        `None`. Anything else is passed through unchanged. The returned dict
        carries an internal `_json_output` key (from `--json`) when built via
        the argparse branch; callers pop it off before using the rest.
        """
        if isinstance(source, dict):
            return coerce_args(self.arg_specs, source)

        if isinstance(source, list) or source is None:
            parser = self.build_parser()
            namespace = parser.parse_args(source)
            raw = vars(namespace)
            json_output = raw.pop('json', False)
            args = coerce_args(self.arg_specs, raw)
            args['_json_output'] = json_output
            return args

        return source

    def execute(self, args: dict[str, Any]) -> OperationResult:
        """Run operation logic. All business logic belongs here.

        Subclasses override this; the base implementation always raises,
        since there is no default behaviour to fall back to.

        Args:
            args: Coerced arguments, per `arg_specs` — the output of
                `parse_args()`/`coerce_args()`, never a raw/unvalidated dict.

        Returns:
            An OperationResult describing the outcome.

        Raises:
            NotImplementedError: Always, unless overridden by a subclass.
        """
        raise NotImplementedError(f'{type(self).__name__} must implement execute()')

    def run(self, args: Any = None) -> str:
        """Entry point for import and instance-method use; returns the primary text response.

        `None` and `dict` are coerced directly against `arg_specs` — never
        falling back to `sys.argv` the way `parse_args()`'s `None` branch
        does for `main()` — so `run()` with no arguments simply applies
        `arg_specs` defaults. A `list` is still accepted as an explicit
        argv-style call for parity with the CLI parsing path. A caller that
        needs the full OperationResult (e.g. `payload`) should call
        `execute()` directly instead.
        """
        if isinstance(args, list):
            parsed = self.parse_args(args)
        else:
            parsed = coerce_args(self.arg_specs, args or {})
        if isinstance(parsed, dict):
            parsed.pop('_json_output', None)
        return self.execute(parsed).text

    def main(self, argv: list[str] | None = None) -> int:
        """CLI entry point; prints the result and returns an exit code.

        `argv` defaults to `None`, which makes `parse_args()` read real
        `sys.argv` via `build_parser()` — the standard
        `if __name__ == '__main__': sys.exit(op.main())` invocation.
        `OperationResult.serialize()` decides the printed output (`.text`,
        or full JSON when `--json` was passed); `OperationResult.exit_code`
        becomes the process exit code, so `execute()` can signal failure via
        `OperationResult.error(..., exit_code=...)`.
        """
        args = self.parse_args(argv)
        json_output = bool(args.pop('_json_output', False)) if isinstance(args, dict) else False
        result = self.execute(args)
        print(result.serialize(as_json=json_output))
        return result.exit_code

    def tool_schema(self) -> dict[str, Any]:
        """JSON-schema-like description for AI agent tool registration."""
        type_map = {'string': 'string', 'boolean': 'boolean', 'json': 'object', 'int': 'integer', 'float': 'number'}
        properties: dict[str, Any] = {}
        required: list[str] = []

        for spec in self.arg_specs:
            prop: dict[str, Any] = {'type': type_map.get(spec.type, 'string'), 'description': spec.help}
            if spec.default is not None and spec.type != 'boolean':
                prop['default'] = spec.default
            properties[spec.key] = prop
            if spec.required:
                required.append(spec.key)

        return {
            'name': self.factory,
            'description': self.description,
            'parameters': {
                'type': 'object',
                'properties': properties,
                'required': required,
            },
        }


def run(args: Any = None) -> str:
    """Import entry point for the base Operation.

    The Python analogue of AB/projects/operations/base.py's module-level
    run(). Always raises NotImplementedError, since the base Operation has
    no execute() implementation of its own; kept for parity with the JS port
    and as a template for a concrete Operation's own module-level run()
    export (see manifesto/hello_world.py).
    """
    return Operation().run(args)
