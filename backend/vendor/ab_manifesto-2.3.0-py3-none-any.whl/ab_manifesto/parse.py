import json
import re
from typing import Any, NamedTuple

from ab_manifesto.get_collection import get_collection
from ab_manifesto.items import to_items

# ── Directive matching ────────────────────────────────────────────────────────
# Both directive forms share the same body shape — factory:args — and differ
# only in what they create:
#   • ${factory:args} — creates a record via get_collection().create_record().
#   • @{factory:args} — creates an instance via get_collection().create_instance()
#                        and resolves to instance.record().
# args may itself contain nested directives or a JSON object literal (both
# introduce their own '{'/'}' pairs), so finding the closing brace means
# tracking depth rather than just searching for the next '}'.


class _DirectiveMatch(NamedTuple):
    sigil: str
    factory: str
    raw_args: str
    end: int  # index immediately after the directive's closing '}'


def _parse_directive_at(value: str, start: int) -> _DirectiveMatch | None:
    """Attempt to parse a directive starting at value[start].

    Recognises both ${factory:args} and @{factory:args}.

    Tracks brace depth from the opening '{' so a nested ${...}/@{...} or a
    JSON object literal inside args doesn't terminate the match early.
    raw_args is returned unresolved — the caller is responsible for
    recursively resolving it.

    Returns None if `start` isn't the start of a well-formed directive (no
    factory: prefix, or no matching closing brace).
    """
    n = len(value)
    if start >= n:
        return None

    sigil = value[start]
    if sigil not in ('$', '@') or start + 1 >= n or value[start + 1] != '{':
        return None

    factory_match = re.match(r'^([a-z]+):', value[start + 2:])
    if not factory_match:
        return None
    factory = factory_match.group(1)
    args_start = start + 2 + len(factory_match.group(0))

    # Depth tracks every '{'/'}' pair, not just directive-prefixed ones —
    # args may itself be a JSON object literal with its own braces (e.g.
    # '{"items":["Hi!"]}'), and those must balance the same way nested
    # directives do.
    depth = 1
    i = args_start
    while i < n and depth > 0:
        if value[i] == '{':
            depth += 1
            i += 1
        elif value[i] == '}':
            depth -= 1
            i += 1
        else:
            i += 1
    if depth != 0:
        return None

    return _DirectiveMatch(sigil=sigil, factory=factory, raw_args=value[args_start:i - 1], end=i)


# ── Resolution ─────────────────────────────────────────────────────────────────

def _resolve_args(raw_args: str) -> dict[str, Any]:
    """Resolve a directive's raw args substring into the options dict passed
    to create_record()/create_instance().

    - If `args`, taken as a whole, is itself a well-formed ${...}/@{...}
      directive, it's parsed recursively (via parse_string) and the object it
      creates becomes this directive's content (items) — not a raw options
      merge, since the created object always carries its own kind, which
      would otherwise misfire create_record()/create_instance()'s
      inheritance mode.
    - Otherwise, any directives embedded inside args are resolved and
      spliced into a string first. If that string is valid JSON and parses
      to a plain dict, it's used directly as options (so directive authors
      can write e.g. ${text:{"items":["Hi"]}}). Any other JSON value (list,
      string, number, boolean, null), or a string that isn't valid JSON at
      all, becomes this directive's content (items) instead — via
      to_items(), so a bare null (e.g. ${text:null}) collapses to
      items: [] rather than items: [None].
    """
    resolved = parse_string(raw_args)
    if not isinstance(resolved, str):
        return {'items': [resolved]}
    try:
        parsed = json.loads(resolved)
    except ValueError:
        return {'items': [resolved]}
    if isinstance(parsed, dict):
        return parsed
    return {'items': to_items(parsed)}


def _create_from_directive(match: _DirectiveMatch) -> Any:
    """Create the object a directive describes, per its sigil (see parse_string)."""
    args = _resolve_args(match.raw_args)
    collection = get_collection()
    if match.sigil == '$':
        return collection.create_record(match.factory, args)
    return collection.create_instance(match.factory, args).record()


# _resolve_to_string recurses into a directive's *written* args before
# creating its object, so nested directives resolve innermost-first. It only
# ever recurses into that original substring — never into a value just
# created — so a created record can never be re-interpreted as a directive.

def _resolve_to_string(value: str) -> str:
    result: list[str] = []
    i = 0
    n = len(value)
    while i < n:
        if value[i] == '$' and i + 1 < n and value[i + 1] == '$':
            result.append('$')
            i += 2
            continue
        if value[i] == '@' and i + 1 < n and value[i + 1] == '@':
            result.append('@')
            i += 2
            continue
        if value[i] in ('$', '@') and i + 1 < n and value[i + 1] == '{':
            match = _parse_directive_at(value, i)
            if match is None:
                result.append(value[i])
                i += 1
                continue
            result.append(str(_create_from_directive(match)))
            i = match.end
            continue
        result.append(value[i])
        i += 1
    return ''.join(result)


def parse_string(value: str) -> Any:
    """Parse a string for ${factory:args} and @{factory:args} directives.

    Both forms create an object via get_collection(), using `factory` (the
    text before the first ':') and `args` (everything up to the matching
    '}', resolved per _resolve_args()):

    - ${factory:args} creates a record only — via create_record — and the
      directive is replaced with that record.
    - @{factory:args} creates an instance — via create_instance — calls
      .record() on it, and the directive is replaced with the resulting
      record.

    - If the *entire* string is exactly one well-formed directive, returns
      that directive's raw result (a RootRecord).
    - Otherwise, returns a string: each directive's result is stringified
      and spliced back into the surrounding text; plain text with no
      directives round-trips unchanged.
    - A malformed directive (no factory: prefix, or no closing brace) is
      left as literal text — this function never raises.
    - $$ escapes a literal $ immediately before {; @@ escapes a literal @
      immediately before {.
    - Directives may nest and mix forms, e.g. ${text:@{test:}} — the
      innermost directive resolves first.

    Args:
        value: The string to parse.
    """
    whole_match = _parse_directive_at(value, 0)
    if whole_match is not None and whole_match.end == len(value):
        return _create_from_directive(whole_match)
    return _resolve_to_string(value)
