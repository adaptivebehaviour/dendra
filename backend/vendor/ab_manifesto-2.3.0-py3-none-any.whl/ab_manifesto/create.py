from ab_manifesto.schemas import validate_product
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from ab_manifesto.root import (
    Instance, Root, RootRecord, generate_id, root_instance,
    record_registry, resolve_inherited_record_props,
)
from ab_manifesto.factory import Factory

# ── Registries ────────────────────────────────────────────────────────────────
# Every object created via the public factory functions is stored here, keyed
# by id. The root objects are pre-registered so they are always available as
# parents without any setup call.
#
# record_registry (root.py) is the *global, merged* view — every
# collection's records.json entries end up here, later collections
# overwriting earlier ones under the same id (see get_collection.py).
# instance_registry and component_registry below are the equivalent global,
# merged views for factory dispatch. A RegistryTarget bundles all three so a
# collection-scoped Collection (via get_collection(collection_id)) can
# resolve against one specific collection's own, un-overridden entries
# instead — see get_collection.py's own module docstring for the full
# mechanism. Every function below defaults to the global registries when no
# target/records override is supplied, so ordinary (non-scoped) callers are
# unaffected.

instances_by_id: dict[str, Root] = {root_instance.id: root_instance}


@dataclass
class RegistryTarget:
    """A bundle of the three factory-dispatch registries a Collection
    resolves against. get_collection() (no id) uses the global, merged
    registries by default; get_collection(collection_id) instead passes one
    specific collection's own scoped bundle, built fresh by get_collection.py
    on every call — see that file's module docstring.
    """

    record_registry: dict[str, RootRecord] = field(default_factory=dict)
    instance_registry: dict[str, Callable[[RootRecord], Instance]] = field(default_factory=dict)
    component_registry: dict[str, type] = field(default_factory=dict)


# ── Private inheritance helper (instances) ────────────────────────────────────
# Used by create_instance() in inheritance mode only. instances_by_id holds
# only Root instances, which are always complete — nothing here is ever
# partial the way a collection's records.json entries can be, so a flat walk
# of each ancestor's already-complete `.props` is sufficient. Not
# collection-scoped — instances_by_id tracks actually-created instances,
# not collection-declared configuration.
#
# A parent's own props is merged, then its parent's, and so on up the `kind`
# chain until an instance with id 'root' is reached (or the chain runs out).
# Root-most ancestor is merged first, nearest parent last, so nearer
# ancestors' props take precedence over farther ones — matching how the
# caller's own opts['props'] is merged on top of this function's result.
#
# `cache`, when supplied, is keyed by parent id: a hit skips the walk
# entirely, a miss walks once and stores the result. get_collection() hands
# each Collection its own fresh cache (see get_collection.py), so repeated
# creations against the same parent through that Collection only pay the
# walk once; calling this without a cache (e.g. via the module-level
# create_instance() export directly) always walks fresh.

def _resolve_inherited_instance_props(
    parent: Root,
    cache: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """The props a child created with `extends=parent` inherits.

    instances_by_id holds only Root instances, which are always complete (an
    instance built with `extends` already merged its parent's defaults in when it
    was created), so the parent's own props are the entire inherited set — there is
    no chain to walk.

    Args:
        parent: The parent instance.
        cache: Optional, keyed by parent id.
    """
    if cache is not None and parent.id in cache:
        return cache[parent.id]
    result = dict(parent.props)
    if cache is not None:
        cache[parent.id] = result
    return result


# ── Private colon-shorthand helper ────────────────────────────────────────────
# A string factory arg may take the form 'foo:bar', where everything after
# the first colon is shorthand for a single-element items list — e.g.
# 'crm:apple-whole' means {'factory': 'crm', 'items': ['apple-whole']}. Splits
# on the first colon only, so a value that itself contains a colon (a URL, a
# timestamp) round-trips unchanged. This makes ':' a reserved character in
# every factory key from here on — no existing key uses it.
#
# This is a blind, generic transform: it always targets items, regardless of
# which factory 'foo' is. A factory that reads its primary input from
# somewhere else simply won't be affected by the shorthand — items would be
# set but never read, the same as passing an explicit, unread items list
# today. Not an error, just a no-op beyond the ordinary dict form.

def _parse_factory_arg(arg: str) -> dict[str, Any]:
    if ':' not in arg:
        return {'factory': arg}
    factory, _, rest = arg.partition(':')
    return {'factory': factory, 'items': [rest]}


# ── Private normalisation helper ──────────────────────────────────────────────
# Resolves the two calling conventions into a single options dict.
#
#   String first arg → parsed via _parse_factory_arg() and merged into
#                       options as {'factory': ..., 'items': ...?} —
#                       overriding any factory (and, if the shorthand
#                       supplied one, any items) already present in options,
#                       the same override rule already applied to factory
#                       alone.
#   Dict first arg   → used as-is.
#
# Used as-is by create_instance() — instances_by_id has no notion of "does
# this string name an existing instance", so a bare string there always
# means "build fresh with this factory" (now also carrying any colon-
# shorthand items). create_record() below does not call this directly for
# its bare, non-colon string case — see its own id-lookup check — since
# record_registry can answer exactly that question for records.

def _normalise(
    arg: str | dict[str, Any],
    options: dict[str, Any] | None,
) -> dict[str, Any]:
    if isinstance(arg, str):
        return {**(options or {}), **_parse_factory_arg(arg)}
    return arg


def create_instance(
    arg: str | dict[str, Any],
    options: dict[str, Any] | None = None,
    props_cache: dict[str, dict[str, Any]] | None = None,
) -> Root:
    """Build a Root class instance.

    Direct mode      `create_instance('text')`,
                     `create_instance('text', {'id': ..., 'props': ..., ...})`

    Inheritance mode `create_instance('text', {'kind': 'parent-id', ...})`,
                     `create_instance({'kind': 'parent-id', ...})`

    In inheritance mode, `props` is merged from every ancestor up to 'root'
    (see `_resolve_inherited_instance_props()`), not just the immediate
    parent. Direct mode's `kind` (via Root's own dataclass default) is
    'root' — a real, resolvable child of root, not an inheritance opt-out.

    A string `arg` of the form `'factory:bar'` is shorthand for
    `{'factory': 'factory', 'items': ['bar']}` — see `_parse_factory_arg()`'s
    own comment for the exact rule (first colon only, items-only, no
    per-factory meaning).

    Args:
        arg: A factory string (optionally `'factory:bar'` shorthand for
            `items: ['bar']`), or an options dict.
        options: Additional options when `arg` is a string.
        props_cache: Optional, keyed by ancestor id — a hit skips re-walking
            that ancestor's `kind` chain. `get_collection()` supplies each
            Collection its own cache; omit it for a fresh resolution every call.

    Returns:
        The new Root instance, already registered in `instances_by_id` under
        its resolved id.

    Raises:
        KeyError: If `options['kind']` is given but no instance with that id
            exists in `instances_by_id`.
        ValueError: If the resolved id equals the parent's id.
    """
    opts = _normalise(arg, options)

    if opts.get('extends') is not None:
        # ── Inheritance mode: defaults come from the instance named by `extends` ──
        parent = instances_by_id.get(opts['extends'])
        if parent is None:
            raise KeyError(f"No instance with id '{opts['extends']}' found in the registry.")
        factory = opts['factory'] if opts.get('factory') is not None else parent.factory
        id_: str = opts['id'] if opts.get('id') is not None else generate_id(factory)
        if id_ == parent.id:
            raise ValueError(
                f"Child id '{id_}' must differ from parent id '{parent.id}'."
            )
        child = Root(
            id=id_,
            kind=opts.get('kind') or 'root',
            factory=factory,
            props={
                **_resolve_inherited_instance_props(parent, props_cache),
                **opts.get('props', {}),
            },
            items=list(opts['items']) if 'items' in opts else [],
            refs=list(opts['refs'])   if 'refs'  in opts else list(parent.refs),
        )
        instances_by_id[child.id] = child
        return child

    # ── Direct mode ───────────────────────────────────────────────────────────
    factory = opts.get('factory', 'object')
    id_ = opts['id'] if opts.get('id') is not None else generate_id(factory)
    instance = Root(
        id=id_,
        kind=opts.get('kind') or 'root',
        factory=factory,
        props=dict(opts['props'])  if 'props'  in opts else {},
        items=list(opts['items'])  if 'items'  in opts else [],
        refs=list(opts['refs'])    if 'refs'   in opts else [],
    )
    instances_by_id[instance.id] = instance
    return instance


def create_record(
    arg: str | dict[str, Any],
    options: dict[str, Any] | None = None,
    props_cache: dict[str, dict[str, Any]] | None = None,
    records: dict[str, RootRecord] | None = None,
) -> RootRecord:
    """Build a complete RootRecord plain-data record.

    Accepts the same calling conventions as `create_instance()`, plus one
    more: a bare string that names an id already in `records` is treated as
    inheritance mode against that id, so `create_record('sanity-fetch')`
    inherits that record's stored `props` the same as
    `create_record({'kind': 'sanity-fetch'})` would — this is what lets a
    collection's `records.json` entry (e.g. `sanity-fetch`'s `projectId`/
    `dataset`) reach a call site through nothing more than its factory name.
    Only when the string doesn't match any registered id does it fall back
    to direct mode, exactly as before (`{'factory': arg}`, empty `props`).
    This lookup is skipped — falling through to the plain string-to-factory
    rule — when `options['kind']` is already given explicitly, so the
    documented `create_record('text', {'kind': 'parent-id'})` form (a
    different string factory grafted onto an unrelated parent) is
    unaffected. Also skipped whenever `arg` contains a colon — see below —
    since a colon form is never a registered-id lookup, regardless of
    whether the literal string happens to match one.

    `arg` may also take the `'factory:bar'` shorthand form — everything
    after the first colon becomes a single-element `items` list (see
    `_parse_factory_arg()`), so `create_record('crm:apple-whole')` is
    `create_record('crm', {'items': ['apple-whole']})`. This is resolved by
    `_normalise()` before direct mode's plain string-to-factory rule ever runs.

    In inheritance mode, `props` is merged from every ancestor up to 'root'
    (see `resolve_inherited_record_props()` in `root.py`), not just the
    immediate parent. Direct mode's `kind` defaults to 'root' — always a
    resolvable ancestor — so a record built this way can later be passed
    back in as `arg` (e.g. to `create_operation()`) without raising.

    Args:
        arg: A factory string (resolved against `records` first — see
            above; optionally `'factory:bar'` shorthand for
            `items: ['bar']`), or an options dict.
        options: Additional options when `arg` is a string.
        props_cache: Optional, keyed by ancestor id — a hit skips re-walking
            that ancestor's `kind` chain. `get_collection()` supplies each
            Collection its own cache; omit it for a fresh resolution every call.
        records: Which registry to resolve against — defaults to the global
            `record_registry`. `get_collection(collection_id)` passes that
            collection's own scoped registry instead, so `arg`'s
            bare-string lookup and `options['kind']`'s ancestry both resolve
            against that collection's un-overridden view — see
            `get_collection.py`'s module docstring.

    Returns:
        The new RootRecord, registered under its resolved id in `records`
        (and, if `records` is a collection-scoped registry distinct from the
        global one, in `record_registry` too, so it stays generally
        discoverable).

    Raises:
        KeyError: If `options['kind']` is given (explicitly, or implicitly
            via a matching string `arg`) but no record with that id exists
            in `records`.
        ValueError: If the resolved id equals the parent's id.
    """
    target = records if records is not None else record_registry
    # A bare string naming a registered record means "start from that record's defaults".
    if isinstance(arg, str) and ':' not in arg and (options or {}).get('extends') is None and arg in target:
        opts = {**(options or {}), 'extends': arg}
    else:
        opts = _normalise(arg, options)

    if opts.get('extends') is not None:
        # ── Inheritance mode: defaults come from the record named by `extends` ────
        parent = target.get(opts['extends'])
        if parent is None:
            raise KeyError(f"No record with id '{opts['extends']}' found in the registry.")
        factory = opts['factory'] if opts.get('factory') is not None else parent['factory']
        id_: str = opts['id'] if opts.get('id') is not None else generate_id(factory)
        if id_ == parent['id']:
            raise ValueError(
                f"Child id '{id_}' must differ from parent id '{parent['id']}'."
            )
        record: RootRecord = {
            'id':      id_,
            'kind':    opts.get('kind') or 'root',
            'factory': factory,
            'props':   {
                **resolve_inherited_record_props(parent, target, props_cache),
                **opts.get('props', {}),
            },
            'items':   list(opts['items']) if 'items' in opts else [],
            'refs':    list(opts['refs'])  if 'refs'  in opts else list(parent['refs']),
        }
        validate_product(record)
        target[record['id']] = record
        if target is not record_registry:
            record_registry[record['id']] = record
        return record

    # ── Direct mode ───────────────────────────────────────────────────────────
    factory = opts.get('factory', 'object')
    id_ = opts['id'] if opts.get('id') is not None else generate_id(factory)
    record: RootRecord = {
        'id':      id_,
        'kind':    opts.get('kind') or 'root',
        'factory': factory,
        'props':   dict(opts['props'])  if 'props'  in opts else {},
        'items':   list(opts['items'])  if 'items'  in opts else [],
        'refs':    list(opts['refs'])   if 'refs'   in opts else [],
    }
    validate_product(record)
    target[record['id']] = record
    if target is not record_registry:
        record_registry[record['id']] = record
    return record


# ── A factory's own resolved identity ─────────────────────────────────────────
# Resolves `factory_key` against `records` via inheritance, exactly like any
# other record resolves its own ancestry. A factory key with no
# records.json-style entry there (most of them — only a factory with real
# defaults to declare needs one) simply gets the ordinary root-level
# default, matching Root's own dataclass defaults — this is what makes
# registering a factory's own config entry optional, not required, for
# every factory.
#
# Exported (not just used internally by the generic Factory-default path
# above) so a custom instance_registry-registered class can replicate the
# same two-phase merge Factory.produce() provides, when it needs its own
# identity's declared defaults *and* something extra — see
# `manifesto/factories/image_factory.py`'s own comment for why.

def resolve_factory_record(
    factory_key: str,
    records: dict[str, RootRecord],
    cache: dict[str, dict[str, Any]] | None = None,
) -> RootRecord:
    if factory_key != 'root' and factory_key not in records:
        return {'id': factory_key, 'kind': 'root', 'factory': factory_key, 'props': {}, 'items': [], 'refs': []}
    entry = records[factory_key]
    return {
        'id': entry['id'],
        'kind': entry['kind'],
        'factory': entry['factory'],
        'props': resolve_inherited_record_props(entry, records, cache),
        'items': list(entry['items']),
        'refs': list(entry['refs']),
    }


# ── Instance registry ─────────────────────────────────────────────────────────
# Maps a record's `factory` to the constructor responsible for building its
# instance form — add additional entries here as new instance types are
# added. 'object' is registered against the base Root class as the default.
# Any constructor added here must return something satisfying the Instance
# ABC (see root.py) — a record() method is not optional.
#
# A factory key registered here always uses create()'s "existing path" (see
# create()'s own docstring) — factory.py's two-phase produce() flow only
# applies to factory keys with *no* entry here.

def _object_instance(record: RootRecord) -> Root:
    return Root(**record)


# Maps a record's `factory` to the callable responsible for building it.
# 'object' is registered against the base Root class as the default. This is
# the global, merged view — see this module's own RegistryTarget docstring.
instance_registry: dict[str, Callable[[RootRecord], Instance]] = {
    'object': _object_instance,
}


# ── Component registry ────────────────────────────────────────────────────────
# Maps a record's `factory` to the component class responsible for rendering
# it. Deliberately empty here — this module has no UI dependency of its own.
# A consuming application (e.g. the Streamlit package) registers its own
# component classes into this dict at startup. Each class must accept a
# RootRecord as its sole constructor argument and expose a render() method.
# This is the global, merged view — see this module's own RegistryTarget
# docstring.

component_registry: dict[str, type] = {}


def create_component(record: RootRecord, components: dict[str, type] | None = None) -> Any:
    """Render a record as a UI component instance.

    Looks up the component class registered in `components` (defaults to
    the global component_registry) for record['factory'], instantiates it
    with the record, calls its render() method, and returns the instance.

    Args:
        record: The record to render. Its `factory` selects the component.
        components: Which registry to look the component up in — defaults
            to the global `component_registry`. `get_collection(collection_id)`
            passes that collection's own scoped registry instead.

    Raises:
        KeyError: If no component is registered for record['factory'].
    """
    target = components if components is not None else component_registry
    component_class = target.get(record['factory'])
    if component_class is None:
        raise KeyError(f"No component registered for factory '{record['factory']}'.")
    component = component_class(record)
    component.render()
    return component


# Resolves a string arg into create()'s dispatch factory key and produce()
# options, honouring the 'factory:bar' shorthand (see _parse_factory_arg()).
# Deliberately not just _normalise(arg, options) — that would also fold
# 'factory' itself into produce_options, which Factory.produce() would then
# prefer over the factory instance's own resolved self.factory. That resolved
# value can legitimately differ from the raw dispatch key when a
# records.json entry declares a 'factory' other than its own 'id' (an
# aliasing case nothing currently uses, but the type allows); injecting the
# dispatch key back in as an override would silently clobber it. Folding in
# only the shorthand's own 'items' (never 'factory') keeps that resolution
# path exactly as it was before this shorthand existed.
def _resolve_string_arg(arg: str, options: dict[str, Any] | None) -> tuple[str, dict[str, Any]]:
    parsed = _parse_factory_arg(arg)
    produce_options = {**(options or {}), 'items': parsed['items']} if 'items' in parsed else (options or {})
    return parsed['factory'], produce_options


# True when a constructed instance also implements the Factory-capable duck
# type (has a callable produce()) — used by resolve_product() to decide
# whether the "existing path" (a custom instance_registry entry) should
# render the instance as-is (the pre-existing Operation behaviour:
# HelloWorldOperation/FetchOperation/SanityFetchOperation) or call produce()
# to build a distinct product record first (a custom Factory-capable class,
# e.g. one that needs to resolve its own items). Mirrors the JS port's
# isFactoryCapable() in create.ts — this check was missing here entirely
# until ComponentFactory/ImageFactory needed it: previously every
# instance_registry entry in this collection was a plain Operation, so the
# "existing path" never had a produce()-implementing class to call.
def _is_factory_capable(instance: Instance) -> bool:
    return callable(getattr(instance, 'produce', None))


def resolve_product(
    arg: str | dict[str, Any] | list[Any],
    options: dict[str, Any] | list[Any] | None = None,
    props_cache: dict[str, dict[str, Any]] | None = None,
    target: RegistryTarget | None = None,
) -> RootRecord | Instance:
    """Core shared by `create()` — resolves `arg` to a product (a RootRecord
    or Instance) via the same two-path dispatch, but stops short of the
    final "render if a component is registered" step. `create()` is a thin
    wrapper: it calls this, then renders the result if a component is
    registered for the resolved factory.

    Exists as its own export for a caller that specifically needs the
    unrendered product itself — e.g. a Factory-capable class resolving its
    own nested `items` into plain child records rather than pre-rendered
    components, so those records stay renderable later (by whatever
    eventually calls `create_component()` on them) instead of being
    collapsed into UI at resolution time. `manifesto/factories/component_factory.py`
    is the first such caller.

    Args:
        arg: Same as `create()`'s own `arg` parameter.
        options: Same as `create()`'s own `options` parameter.
        props_cache: Same as `create()`'s own `props_cache` parameter.
        target: Same as `create()`'s own `target` parameter.

    Returns:
        The resolved RootRecord or Instance, never rendered.
    """
    if isinstance(arg, list):
        arg = {'items': arg}
    if isinstance(options, list):
        options = {'items': options}

    records = target.record_registry if target is not None else record_registry
    instances = target.instance_registry if target is not None else instance_registry

    if isinstance(arg, str):
        factory_key, produce_options = _resolve_string_arg(arg, options)
    else:
        factory_key, produce_options = arg.get('factory', 'object'), arg

    build_instance = instances.get(factory_key)
    if build_instance is not None:
        # ── Existing path ────────────────────────────────────────────────────
        record = create_record(arg, options, props_cache, records)
        instance = build_instance(record)
        if _is_factory_capable(instance):
            return instance.produce(produce_options, props_cache, records)
        return instance

    # ── New path — generic Factory default ────────────────────────────────────
    factory_record = resolve_factory_record(factory_key, records, props_cache)
    factory_instance = Factory(**factory_record)
    return factory_instance.produce(produce_options, props_cache, records)


def create(
    arg: str | dict[str, Any] | list[Any],
    options: dict[str, Any] | list[Any] | None = None,
    props_cache: dict[str, dict[str, Any]] | None = None,
    target: RegistryTarget | None = None,
) -> RootRecord | Instance | Any:
    """General-purpose factory. Resolves `arg` to a factory key (a string
    `arg` is the key directly — optionally `'factory:bar'` shorthand for
    `items: ['bar']`, see `_parse_factory_arg()`; a dict `arg` uses
    `arg.get('factory', 'object')`), then dispatches down one of two paths:

    1. **Existing path** — a custom constructor is registered in
       `target.instance_registry` (defaults to the global `instance_registry`)
       for this factory key (an `Operation` like `HelloWorldOperation`/
       `FetchOperation`/`SanityFetchOperation`, or any future custom
       Factory-capable class). Builds the record via `create_record()`
       exactly as before — including its bare-string-as-registered-id
       inheritance lookup — then constructs the instance. If that instance
       is also Factory-capable (has a callable `produce()`), calls it to
       build the product record instead of using the instance as-is — see
       `resolve_product()`'s own `_is_factory_capable()`. Otherwise (the
       pre-existing behaviour, unchanged: `HelloWorldOperation`/
       `FetchOperation`/`SanityFetchOperation`), renders the instance via
       `target.component_registry` if a component is registered for its
       factory, otherwise returns the instance itself.
    2. **New path** — no custom constructor is registered. Resolves the
       factory's own identity from `target.record_registry` (its own
       default `props`, if any were declared), constructs a generic
       `Factory` instance from it, and calls
       `produce(options, props_cache, target.record_registry)` to build the
       product record — see `factory.py`'s own module docstring for the
       two-phase resolution model this implements. Renders the product via
       `target.component_registry` if registered for its factory, otherwise
       returns the plain record.

    `arg` and `options` each also accept a bare list as shorthand for
    `{'items': list}` — e.g. `create(['bar'])` is `create({'items': ['bar']})`
    (factory defaults to `'object'`, same as any other factory-less dict
    `arg`), and `create('foo', ['bar'])` is `create('foo', {'items': ['bar']})`.
    Resolved to a plain options dict before anything else in this function
    runs (see `resolve_product()`), so every step below (including
    `create_record()` and `produce()`) sees the same `str | dict` shape it
    always has.

    Args:
        arg: A factory string (optionally `'factory:bar'` shorthand for
            `items: ['bar']`), an options dict, or a bare list — shorthand
            for `{'items': list}`.
        options: Additional options when `arg` is a string — also accepts a
            bare list, shorthand for `{'items': list}`.
        props_cache: Forwarded to whichever path is taken — see
            `create_record()`'s and `Factory.produce()`'s own
            `props_cache`/`cache` parameters.
        target: Which registries to resolve against — defaults to the
            global `record_registry`/`instance_registry`/`component_registry`.
            `get_collection(collection_id)` passes that collection's own
            scoped bundle instead — see `get_collection.py`'s module
            docstring.

    Returns:
        A record, an Instance, or a rendered component instance, per the
        steps above.
    """
    components = target.component_registry if target is not None else component_registry
    product = resolve_product(arg, options, props_cache, target)

    is_instance = hasattr(product, 'record') and callable(product.record)
    factory = product.factory if is_instance else product['factory']
    if factory not in components:
        return product
    record = product.record() if is_instance else product
    return create_component(record, components)


def create_operation(
    arg: str | dict[str, Any],
    args: dict[str, Any] | None = None,
    props_cache: dict[str, dict[str, Any]] | None = None,
    target: RegistryTarget | None = None,
) -> str:
    """Build a Runnable via `create()` and immediately run() it.

    Uses `create()`, not `create_instance()` — only `create()` consults
    `instance_registry` to dispatch a record's `factory` to its registered
    constructor (e.g. `HelloWorldOperation`); `create_instance()` always
    builds a plain Root, regardless of `factory`.

    Args:
        arg: A factory string (optionally `'factory:bar'` shorthand for
            `items: ['bar']`), or an options dict.
        args: Forwarded to the resolved instance's `run()`.
        props_cache: Forwarded to `create()` — see its own `props_cache` parameter.
        target: Forwarded to `create()` — see its own `target` parameter.

    Returns:
        Whatever the resolved instance's `run()` returns.

    Raises:
        TypeError: If the resolved value has no `run()` method (i.e. its
            factory is not registered against a Runnable).
    """
    result = create(arg, {}, props_cache, target)
    run = getattr(result, 'run', None)
    if not callable(run):
        factory = _parse_factory_arg(arg)['factory'] if isinstance(arg, str) else arg.get('factory')
        raise TypeError(f"'{factory}' is not Runnable.")
    return run(args)
