"""Manifesto core library: objects, factories, registries and the base `manifesto` collection."""
