from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ab_manifesto.root import Root, RootRecord
from ab_manifesto.container_factory import resolve_item_record
from ab_manifesto.warn import warn


def resolve_only_item(
    raw_items: list[Any],
    factory: str,
    props_cache: dict[str, dict[str, Any]] | None = None,
) -> RootRecord | None:
    """Resolves `raw_items` down to at most one record — `raw_items[0]`, if
    present — warning via `warn()` when the caller supplied more than one.
    Returns `None` when no items were given at all (nothing to resolve, not
    an "extra items" situation).

    A plain function, not a method on `ItemFactory`, so a factory with its
    own record-assembly needs can still reuse this exact resolution and
    warning logic via composition instead of inheritance — see
    `manifesto/factories/image_factory.py`, which folds the resolved item's data into
    its own two-phase-resolved `props` instead of nesting it under `items`.
    Mirrors the JS port's `resolveOnlyItem()` in `ItemFactory.ts`.
    """
    if len(raw_items) > 1:
        warn(f"'{factory}' has {len(raw_items) - 1} item(s) beyond items[0] — only items[0] is used.")
    if len(raw_items) == 0:
        return None
    return resolve_item_record(raw_items[0], props_cache)


@dataclass
class ItemFactory(Root):
    """Factory-capable base class for "always exactly one item" — the
    sibling of `ContainerFactory` ("always every item"): both resolve
    `items` via the same `resolve_item_record()` per-item logic, differing
    only in how many elements they keep.

    `items` beyond the first are silently dropped rather than rejected — a
    caller mistake here doesn't need to be a hard error (unlike, say,
    `create()` rejecting a missing `props['projectId']`, or
    `SanityFetchOperation` requiring a non-empty `id`) — but it does go
    through `warn()` (via `resolve_only_item()`), a single, swappable seam
    for "something unexpected happened, but execution should continue"
    signals, so a caller who passed more than one item by mistake has *some*
    way to notice.

    Nests the (at most one) resolved item under `items`, mirroring
    `ContainerFactory`'s own shape but capped to one element — suitable for
    a factory with no declared defaults of its own to preserve. A factory
    that needs to fold the resolved item's data into its own `props` instead
    should call `resolve_only_item()` directly rather than extending this
    class — see `manifesto/factories/image_factory.py`.
    """

    def produce(
        self,
        options: dict[str, Any] | None = None,
        cache: dict[str, dict[str, Any]] | None = None,
        records: dict[str, RootRecord] | None = None,
    ) -> RootRecord:
        base = self.record()
        resolved = resolve_only_item(base['items'], self.factory, cache)
        return {**base, 'items': [resolved] if resolved is not None else []}
