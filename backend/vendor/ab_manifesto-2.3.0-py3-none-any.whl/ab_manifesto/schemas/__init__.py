"""Validation of boundary data with the Pydantic models generated from the shared JSON Schemas.

The models in `_generated.py` are produced by `scripts/generate_contracts.py` from
`contracts/schemas/bundle.schema.json`, which the TypeScript side (`js/workshop/lib/scripts/export-schemas.ts`)
exports from its Zod schemas — one source of truth for both languages. Do not edit `_generated.py`.

Error messages name the offending path the same way the TypeScript side does:
`<source>[<index>].props.url: <message>`.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ValidationError

from ._generated import (
    FetchProps, HelloWorldProps, ImageProps, RecordConfig, RootProps, SanityProps, StyledProps,
)

__all__ = ['FACTORY_PROPS', 'SchemaError', 'format_issues', 'validate_product', 'validate_records']

# The props model of each factory that has a schema (factories not listed are untyped and always pass).
FACTORY_PROPS: dict[str, type[BaseModel]] = {
    'root': RootProps,
    'component': StyledProps,
    'item-component': StyledProps,
    'text': StyledProps,
    'image': ImageProps,
    'hello-world': HelloWorldProps,
    'fetch': FetchProps,
    'sanity-fetch': SanityProps,
    'sanity-fetch-many': SanityProps,
}


class SchemaError(ValueError):
    """A validation failure whose message names the offending path, e.g. `records.json[2].props.url: ...`."""

    def __init__(self, message: str, issues: list[str]) -> None:
        super().__init__(message)
        self.issues = issues


def format_issues(prefix: str, error: ValidationError) -> list[str]:
    """One `<path>: <message>` line per Pydantic error, the path starting at `prefix`."""
    lines = []
    for issue in error.errors():
        path = prefix
        for segment in issue['loc']:
            path += f'[{segment}]' if isinstance(segment, int) else f'.{segment}'
        lines.append(f"{path}: {issue['msg']}")
    return lines


def validate_product(record: dict[str, Any]) -> None:
    """Validate a built record's props against its factory's model, if it has one.

    Raises:
        SchemaError: naming the factory, the record id and every offending path.
    """
    model = FACTORY_PROPS.get(record['factory'])
    if model is None:
        return
    try:
        model.model_validate(record['props'])
    except ValidationError as error:
        issues = format_issues('props', error)
        raise SchemaError(
            f"Invalid record '{record['id']}' for factory '{record['factory']}':\n  " + '\n  '.join(issues), issues
        ) from None


def validate_records(source: str, entries: Any) -> list[dict[str, Any]]:
    """Validate the entries of a collection's records.json as it is loaded at registrar time: each must match
    the RecordConfig model and, when its factory has a model, its props must match that too.

    Args:
        source: How the file is named in errors, e.g. `'manifesto/records.json'`.

    Raises:
        SchemaError: listing every problem with its `source[index].path`.
    """
    if not isinstance(entries, list):
        raise SchemaError(f'{source}: expected an array of records.', [f'{source}: expected an array of records.'])
    issues: list[str] = []
    for index, entry in enumerate(entries):
        at = f'{source}[{index}]'
        try:
            config = RecordConfig.model_validate(entry)
        except ValidationError as error:
            issues.extend(format_issues(at, error))
            continue
        model = FACTORY_PROPS.get(config.factory or config.id or '')
        if model is not None and config.props:
            try:
                model.model_validate(config.props)
            except ValidationError as error:
                issues.extend(format_issues(f'{at}.props', error))
    if issues:
        raise SchemaError(f'Invalid records in {source}:\n  ' + '\n  '.join(issues), issues)
    return entries
