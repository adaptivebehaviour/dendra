from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal, Sequence

from ab_manifesto.create import (
    RegistryTarget, create, create_component, create_instance, create_operation, create_record,
    record_registry, instance_registry, component_registry,
)
from ab_manifesto.root import root_record
from ab_manifesto.warn import warn

CollisionMode = Literal['warn', 'throw', 'ignore']

_OBJECT_INSTANCE = instance_registry['object']


@dataclass(frozen=True)
class CollectionDefinition:
    """A collection's declaration: its `id`, the collections it may import
    (`depends_on` — each must be registered before it), the ids it deliberately
    overrides (`overrides` — a collision on any other id is reported; `'*'`
    means "may override anything", which the legacy register_collection() path
    uses), and its `register` function, which writes the collection's own
    records/components/instances into the RegistryTarget it is handed.
    """

    id: str
    register: Callable[[RegistryTarget], None]
    depends_on: tuple[str, ...] = ()
    overrides: tuple[str, ...] | Literal['*'] = ()


def define_collection(
    id: str,
    register: Callable[[RegistryTarget], None],
    depends_on: Sequence[str] = (),
    overrides: Sequence[str] | Literal['*'] = (),
) -> CollectionDefinition:
    """Declare a collection. Mirrors the TypeScript defineCollection()."""
    return CollectionDefinition(
        id=id,
        register=register,
        depends_on=tuple(depends_on),
        overrides=overrides if overrides == '*' else tuple(overrides),
    )


@dataclass(frozen=True)
class Collection:
    """The shared creation surface returned by Registry.get_collection()."""

    create: Callable
    create_instance: Callable
    create_record: Callable
    create_component: Callable
    create_operation: Callable


def _empty_target() -> RegistryTarget:
    """A fresh RegistryTarget — every collection's own scope starts from this,
    pre-seeded with the same 'root'/'object' baseline entries create.py's global
    registries carry."""
    return RegistryTarget(
        record_registry={root_record['id']: root_record},
        instance_registry={'object': _OBJECT_INSTANCE},
    )


def _validate(collections: Sequence[CollectionDefinition]) -> None:
    seen: set[str] = set()
    for collection in collections:
        if collection.id in seen:
            raise ValueError(f"Duplicate collection id '{collection.id}'.")
        for dependency in collection.depends_on:
            if dependency not in seen:
                registered = any(c.id == dependency for c in collections)
                if registered:
                    raise ValueError(
                        f"Collection '{collection.id}' depends on '{dependency}', which must be registered before it."
                    )
                raise ValueError(
                    f"Collection '{collection.id}' depends on '{dependency}', which is not registered."
                )
        seen.add(collection.id)


class Registry:
    """A composed set of collections: validated once, each collection's own
    scope captured once. Mirrors the TypeScript Registry."""

    def __init__(self, collections: Sequence[CollectionDefinition], on_collision: CollisionMode = 'warn') -> None:
        _validate(collections)
        self.ids: tuple[str, ...] = tuple(c.id for c in collections)
        self._scopes: dict[str, RegistryTarget] = {}
        owners: dict[str, str] = {}
        seeds = {
            ('record_registry', 'root'): root_record,
            ('instance_registry', 'object'): _OBJECT_INSTANCE,
        }
        for collection in collections:
            scope = _empty_target()
            collection.register(scope)
            self._scopes[collection.id] = scope
            for registry_name in ('record_registry', 'instance_registry', 'component_registry'):
                for key, value in getattr(scope, registry_name).items():
                    if seeds.get((registry_name, key)) is value:
                        continue
                    owner_key = f'{registry_name}:{key}'
                    previous = owners.get(owner_key)
                    declared = collection.overrides == '*' or key in collection.overrides
                    if previous is not None and not declared and on_collision != 'ignore':
                        message = (
                            f"Collection '{collection.id}' overrides '{key}' ({registry_name}) already registered "
                            f"by '{previous}'; list it in the collection's overrides to declare this on purpose."
                        )
                        if on_collision == 'throw':
                            raise ValueError(message)
                        warn(message)
                    owners[owner_key] = collection.id

    def get_collection(self, collection_id: str | None = None) -> Collection:
        """The merged view across every collection (no id), or one collection's
        own scope, bypassing whatever overrides it in the merged view. The
        scopes are merged into the shared create.py registries on every call.

        Raises:
            KeyError: If `collection_id` is given but no collection has that id.
        """
        for scope in self._scopes.values():
            record_registry.update(scope.record_registry)
            instance_registry.update(scope.instance_registry)
            component_registry.update(scope.component_registry)

        target: RegistryTarget | None = None
        if collection_id is not None:
            target = self._scopes.get(collection_id)
            if target is None:
                raise KeyError(f"No collection registered with id '{collection_id}'.")

        record_props_cache: dict[str, dict[str, Any]] = {}
        instance_props_cache: dict[str, dict[str, Any]] = {}

        return Collection(
            create=lambda arg, options=None: create(arg, options, record_props_cache, target),
            create_instance=lambda arg, options=None: create_instance(arg, options, instance_props_cache),
            create_record=lambda arg, options=None: create_record(
                arg, options, record_props_cache, target.record_registry if target else None
            ),
            create_component=lambda record: create_component(record, target.component_registry if target else None),
            create_operation=lambda arg, args=None: create_operation(arg, args, record_props_cache, target),
        )


def create_registry(collections: Sequence[CollectionDefinition], on_collision: CollisionMode = 'warn') -> Registry:
    """Compose `collections` — in order, which is the load order — into a Registry.
    Mirrors the TypeScript createRegistry(): validates declared dependencies,
    runs each collection's register once into a private scope, and reports every
    id a collection overwrites without listing it in `overrides`."""
    return Registry(collections, on_collision)
