from __future__ import annotations

from ab_manifesto.schemas import validate_product

from dataclasses import dataclass
from typing import Any

from ab_manifesto.root import Root, RootRecord, generate_id, record_registry, resolve_inherited_record_props


@dataclass
class Factory(Root):
    """Generic default factory-capable object.

    `get_collection()`/`create()` (see `create.py`) constructs this
    automatically for any factory key with no custom class registered in
    `instance_registry` — which covers every currently-existing
    purely-declarative factory in this collection (`root`, `component`). A
    custom class is only needed for a factory with real, non-generic
    production logic; none exist yet, but the door stays open by registering
    a `produce()`-implementing constructor into `instance_registry` under
    that factory's key, exactly like a custom Instance constructor is
    registered today.

    ## Why this exists — the two-phase resolution model

    Object creation splits into two independent passes, so a single record's
    `kind` is never asked to mean two different things at once (see
    `projects/manifesto/CLAUDE.md`'s Nomenclature section, "Factory objects",
    for the full rationale and worked example):

    1. **Resolve the factory's own identity** — `create()` resolves the
       factory key (e.g. `'image'` on the JS side; this Python collection has
       no declarative factory needing its own defaults yet, but the
       mechanism is symmetric) against `record_registry` (`root.py`) via
       inheritance, exactly as any other record resolves its own ancestry,
       and constructs a `Factory` instance from the result. This instance's
       own `self.props` now holds the factory's resolved defaults.
    2. **The factory instance builds the product** — `produce(options)`
       builds the actual output record. `options['kind']`, if given, is
       resolved against `records` (defaults to `record_registry` — see the
       `produce()` `records` parameter) — real structural ancestry — and the
       factory's own resolved defaults (`self.props`) are merged in
       separately, never via `kind`. Merge precedence (lowest to highest):
       factory's own generic defaults < product's real inherited ancestor
       props < the caller's own explicit `options['props']` overrides — a
       deliberate placement under a specific `kind` is more specific than a
       generic factory fallback, so it wins on overlapping keys.

    Both steps resolve against `record_registry` — there is no longer a
    separate registry for a factory's own configuration. `record_registry`
    is shared globally across every collection (see `get_collection.py`'s
    registry's collection list), and a later-registered collection's entry silently
    overwrites an earlier one's under the same id, by design (see
    `get_collection.py`'s own docstring) — `get_collection(collection_id)`
    is the way to deliberately resolve a factory's identity (or any
    record's ancestry) against one specific collection's own scope,
    bypassing whatever currently shadows it globally.

    This is why `Operation` (`HelloWorldOperation`/`FetchOperation`/
    `SanityFetchOperation`) doesn't need to be Factory-capable: an
    Operation's own configuration (e.g. `SanityFetchOperation`'s
    `projectId`/`dataset`) is intrinsic to every use of that operation —
    there's no legitimate case for wanting a `sanity-fetch` instance
    *without* its configured project, the way a declarative factory
    legitimately wants both its own visual/structural defaults *and* an
    unrelated structural parent's cascading props at once. Operations aren't
    positioned in a rendered hierarchy the way UI components are, so the
    two-phase split this class exists for isn't needed there; their existing
    construction path (`create.py`'s pre-existing `create_record()` +
    `instance_registry` dispatch) is unchanged by this class's existence.
    """

    def produce(
        self,
        options: dict[str, Any] | None = None,
        cache: dict[str, dict[str, Any]] | None = None,
        records: dict[str, RootRecord] | None = None,
    ) -> RootRecord:
        """Build a product record from this factory instance's own resolved
        defaults (`self.props`) plus the caller's `options`.

        Args:
            options: `kind` positions the product in the real hierarchy
                (defaults to `'root'` — a real, resolvable position, not an
                inheritance opt-out); `props`/`items`/`refs`/`id`/`factory`
                override the product's own fields, per this class's own
                docstring for merge precedence.
            cache: Optional, keyed by id — forwarded to
                `resolve_inherited_record_props()`; `get_collection()`
                supplies each Collection its own cache the same way it does
                for `create()`'s own record cache. Omit it for a fresh
                resolution every call.
            records: Which registry to resolve `options['kind']`'s ancestry
                against — defaults to the global `record_registry`. Pass a
                specific collection's own scoped registry (as
                `get_collection(collection_id)` does internally) to resolve
                `kind` against that collection's un-overridden view rather
                than the globally merged one.

        Returns:
            The new product RootRecord, already registered in `records`
            (and, if `records` is a collection-scoped registry distinct from
            the global one, in `record_registry` too, so it stays generally
            discoverable).

        Raises:
            KeyError: If `options['kind']` is given but no record with that
                id exists in `records`.
            ValueError: If the resolved product id equals its `kind`
                ancestor's id.
        """
        target = records if records is not None else record_registry
        opts = options or {}
        # `kind` is the product's structural parent only. Its defaults come from
        # `extends` (an optional record id), resolved transitively.
        kind = opts.get('kind') or 'root'
        ancestor = None
        if opts.get('extends') is not None:
            ancestor = target.get(opts['extends'])
            if ancestor is None:
                raise KeyError(f"No record with id '{opts['extends']}' found in the registry.")

        factory = opts['factory'] if opts.get('factory') is not None else self.factory
        id_ = opts['id'] if opts.get('id') is not None else generate_id(factory)
        if ancestor is not None and id_ == ancestor['id']:
            raise ValueError(
                f"Product id '{id_}' must differ from the id of the record it extends ('{ancestor['id']}')."
            )

        # Merge precedence, lowest to highest: this factory's own generic
        # defaults < the `extends` chain's props < the caller's own explicit
        # overrides. `kind` takes no part in it.
        refs = list(opts['refs']) if 'refs' in opts else (list(ancestor['refs']) if ancestor is not None else [])
        props = {
            **self.props,
            **(resolve_inherited_record_props(ancestor, target, cache) if ancestor is not None else {}),
            **opts.get('props', {}),
        }

        record: RootRecord = {
            'id': id_,
            'kind': kind,
            'factory': factory,
            'props': props,
            'items': list(opts['items']) if 'items' in opts else [],
            'refs': refs,
        }
        validate_product(record)
        target[record['id']] = record
        if target is not record_registry:
            record_registry[record['id']] = record
        return record
